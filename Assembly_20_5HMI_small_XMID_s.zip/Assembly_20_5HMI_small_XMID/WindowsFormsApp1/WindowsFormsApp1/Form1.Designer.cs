﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.lblscan6 = new System.Windows.Forms.Label();
            this.sca6 = new System.Windows.Forms.Label();
            this.lblscan5 = new System.Windows.Forms.Label();
            this.sca5 = new System.Windows.Forms.Label();
            this.lblscan4 = new System.Windows.Forms.Label();
            this.sca4 = new System.Windows.Forms.Label();
            this.lblscan3 = new System.Windows.Forms.Label();
            this.sca3 = new System.Windows.Forms.Label();
            this.lblscan2 = new System.Windows.Forms.Label();
            this.sca2 = new System.Windows.Forms.Label();
            this.lblscan1 = new System.Windows.Forms.Label();
            this.sca1 = new System.Windows.Forms.Label();
            this.lblOper = new System.Windows.Forms.TextBox();
            this.txtOper = new System.Windows.Forms.TextBox();
            this.lbServer = new System.Windows.Forms.Label();
            this.lbDate = new System.Windows.Forms.Label();
            this.lblNode = new System.Windows.Forms.Label();
            this.lblServer = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lbNode = new System.Windows.Forms.Label();
            this.lbVer = new System.Windows.Forms.Label();
            this.lblScanType = new System.Windows.Forms.Label();
            this.lblVer = new System.Windows.Forms.Label();
            this.lbModelInfo = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.M1 = new System.Windows.Forms.Label();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.txtBarcodeScan = new System.Windows.Forms.TextBox();
            this.txtscan2 = new System.Windows.Forms.TextBox();
            this.s6 = new System.Windows.Forms.Label();
            this.txtscan6 = new System.Windows.Forms.TextBox();
            this.s5 = new System.Windows.Forms.Label();
            this.txtscan5 = new System.Windows.Forms.TextBox();
            this.s4 = new System.Windows.Forms.Label();
            this.txtscan4 = new System.Windows.Forms.TextBox();
            this.s3 = new System.Windows.Forms.Label();
            this.txtscan3 = new System.Windows.Forms.TextBox();
            this.s2 = new System.Windows.Forms.Label();
            this.s1 = new System.Windows.Forms.Label();
            this.txtscan1 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cbModel = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.TimerErr = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.Product_OK_Count = new System.Windows.Forms.Label();
            this.Product_NG_Count = new System.Windows.Forms.Label();
            this.txt_Plan_Qty = new System.Windows.Forms.TextBox();
            this.TmStart = new System.Windows.Forms.Label();
            this.lbl_plan_Qty = new System.Windows.Forms.Label();
            this.lbl_product_Qty = new System.Windows.Forms.Label();
            this.lbl_NG_Qty = new System.Windows.Forms.Label();
            this.Btn_Reset1 = new System.Windows.Forms.Button();
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.SetupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setINIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scanSetupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grpStatus = new System.Windows.Forms.GroupBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.Panel7 = new System.Windows.Forms.Panel();
            this.Panel8 = new System.Windows.Forms.Panel();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.group_scan_setup = new System.Windows.Forms.GroupBox();
            this.save1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.sp1 = new System.Windows.Forms.ComboBox();
            this.sp2 = new System.Windows.Forms.ComboBox();
            this.sp3 = new System.Windows.Forms.ComboBox();
            this.sp4 = new System.Windows.Forms.ComboBox();
            this.sp5 = new System.Windows.Forms.ComboBox();
            this.sp6 = new System.Windows.Forms.ComboBox();
            this.GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.GroupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.MenuStrip1.SuspendLayout();
            this.grpStatus.SuspendLayout();
            this.Panel7.SuspendLayout();
            this.Panel8.SuspendLayout();
            this.group_scan_setup.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            // 
            // GroupBox2
            // 
            this.GroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.GroupBox2.Controls.Add(this.lblscan6);
            this.GroupBox2.Controls.Add(this.sca6);
            this.GroupBox2.Controls.Add(this.lblscan5);
            this.GroupBox2.Controls.Add(this.sca5);
            this.GroupBox2.Controls.Add(this.lblscan4);
            this.GroupBox2.Controls.Add(this.sca4);
            this.GroupBox2.Controls.Add(this.lblscan3);
            this.GroupBox2.Controls.Add(this.sca3);
            this.GroupBox2.Controls.Add(this.lblscan2);
            this.GroupBox2.Controls.Add(this.sca2);
            this.GroupBox2.Controls.Add(this.lblscan1);
            this.GroupBox2.Controls.Add(this.sca1);
            this.GroupBox2.Controls.Add(this.lblOper);
            this.GroupBox2.Controls.Add(this.txtOper);
            this.GroupBox2.Controls.Add(this.lbServer);
            this.GroupBox2.Controls.Add(this.lbDate);
            this.GroupBox2.Controls.Add(this.lblNode);
            this.GroupBox2.Controls.Add(this.lblServer);
            this.GroupBox2.Controls.Add(this.lblDate);
            this.GroupBox2.Controls.Add(this.lblType);
            this.GroupBox2.Controls.Add(this.lbNode);
            this.GroupBox2.Controls.Add(this.lbVer);
            this.GroupBox2.Controls.Add(this.lblScanType);
            this.GroupBox2.Controls.Add(this.lblVer);
            this.GroupBox2.Controls.Add(this.lbModelInfo);
            this.GroupBox2.Controls.Add(this.lblModel);
            this.GroupBox2.Controls.Add(this.PictureBox1);
            this.GroupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox2.ForeColor = System.Drawing.Color.YellowGreen;
            this.GroupBox2.Location = new System.Drawing.Point(341, 114);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(336, 291);
            this.GroupBox2.TabIndex = 58;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Detail";
            // 
            // lblscan6
            // 
            this.lblscan6.BackColor = System.Drawing.Color.Transparent;
            this.lblscan6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscan6.ForeColor = System.Drawing.Color.White;
            this.lblscan6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblscan6.Location = new System.Drawing.Point(92, 247);
            this.lblscan6.Name = "lblscan6";
            this.lblscan6.Size = new System.Drawing.Size(224, 24);
            this.lblscan6.TabIndex = 53;
            this.lblscan6.Text = "lblscan6";
            this.lblscan6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sca6
            // 
            this.sca6.BackColor = System.Drawing.Color.Transparent;
            this.sca6.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sca6.ForeColor = System.Drawing.Color.Gold;
            this.sca6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sca6.Location = new System.Drawing.Point(5, 247);
            this.sca6.Name = "sca6";
            this.sca6.Size = new System.Drawing.Size(101, 23);
            this.sca6.TabIndex = 52;
            this.sca6.Text = "Scan6";
            this.sca6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblscan5
            // 
            this.lblscan5.BackColor = System.Drawing.Color.Transparent;
            this.lblscan5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscan5.ForeColor = System.Drawing.Color.White;
            this.lblscan5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblscan5.Location = new System.Drawing.Point(92, 228);
            this.lblscan5.Name = "lblscan5";
            this.lblscan5.Size = new System.Drawing.Size(224, 24);
            this.lblscan5.TabIndex = 51;
            this.lblscan5.Text = "lblscan5";
            this.lblscan5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sca5
            // 
            this.sca5.BackColor = System.Drawing.Color.Transparent;
            this.sca5.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sca5.ForeColor = System.Drawing.Color.Gold;
            this.sca5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sca5.Location = new System.Drawing.Point(5, 228);
            this.sca5.Name = "sca5";
            this.sca5.Size = new System.Drawing.Size(101, 23);
            this.sca5.TabIndex = 50;
            this.sca5.Text = "Scan5";
            this.sca5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblscan4
            // 
            this.lblscan4.BackColor = System.Drawing.Color.Transparent;
            this.lblscan4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscan4.ForeColor = System.Drawing.Color.White;
            this.lblscan4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblscan4.Location = new System.Drawing.Point(92, 208);
            this.lblscan4.Name = "lblscan4";
            this.lblscan4.Size = new System.Drawing.Size(224, 24);
            this.lblscan4.TabIndex = 49;
            this.lblscan4.Text = "lblscan4";
            this.lblscan4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sca4
            // 
            this.sca4.BackColor = System.Drawing.Color.Transparent;
            this.sca4.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sca4.ForeColor = System.Drawing.Color.Gold;
            this.sca4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sca4.Location = new System.Drawing.Point(5, 208);
            this.sca4.Name = "sca4";
            this.sca4.Size = new System.Drawing.Size(109, 23);
            this.sca4.TabIndex = 48;
            this.sca4.Text = "Scan4";
            this.sca4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblscan3
            // 
            this.lblscan3.BackColor = System.Drawing.Color.Transparent;
            this.lblscan3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscan3.ForeColor = System.Drawing.Color.White;
            this.lblscan3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblscan3.Location = new System.Drawing.Point(92, 190);
            this.lblscan3.Name = "lblscan3";
            this.lblscan3.Size = new System.Drawing.Size(224, 24);
            this.lblscan3.TabIndex = 47;
            this.lblscan3.Text = "lblscan3";
            this.lblscan3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sca3
            // 
            this.sca3.BackColor = System.Drawing.Color.Transparent;
            this.sca3.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sca3.ForeColor = System.Drawing.Color.Gold;
            this.sca3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sca3.Location = new System.Drawing.Point(5, 190);
            this.sca3.Name = "sca3";
            this.sca3.Size = new System.Drawing.Size(100, 23);
            this.sca3.TabIndex = 46;
            this.sca3.Text = "Scan3";
            this.sca3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblscan2
            // 
            this.lblscan2.BackColor = System.Drawing.Color.Transparent;
            this.lblscan2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscan2.ForeColor = System.Drawing.Color.White;
            this.lblscan2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblscan2.Location = new System.Drawing.Point(91, 171);
            this.lblscan2.Name = "lblscan2";
            this.lblscan2.Size = new System.Drawing.Size(225, 24);
            this.lblscan2.TabIndex = 45;
            this.lblscan2.Text = "lblscan2";
            this.lblscan2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sca2
            // 
            this.sca2.BackColor = System.Drawing.Color.Transparent;
            this.sca2.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sca2.ForeColor = System.Drawing.Color.Gold;
            this.sca2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sca2.Location = new System.Drawing.Point(4, 172);
            this.sca2.Name = "sca2";
            this.sca2.Size = new System.Drawing.Size(101, 23);
            this.sca2.TabIndex = 44;
            this.sca2.Text = "Scan2";
            this.sca2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblscan1
            // 
            this.lblscan1.BackColor = System.Drawing.Color.Transparent;
            this.lblscan1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscan1.ForeColor = System.Drawing.Color.White;
            this.lblscan1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblscan1.Location = new System.Drawing.Point(92, 153);
            this.lblscan1.Name = "lblscan1";
            this.lblscan1.Size = new System.Drawing.Size(224, 24);
            this.lblscan1.TabIndex = 43;
            this.lblscan1.Text = "Main PCB Final";
            this.lblscan1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sca1
            // 
            this.sca1.BackColor = System.Drawing.Color.Transparent;
            this.sca1.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sca1.ForeColor = System.Drawing.Color.Gold;
            this.sca1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sca1.Location = new System.Drawing.Point(5, 154);
            this.sca1.Name = "sca1";
            this.sca1.Size = new System.Drawing.Size(100, 23);
            this.sca1.TabIndex = 42;
            this.sca1.Text = "Scan1";
            this.sca1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblOper
            // 
            this.lblOper.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lblOper.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblOper.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOper.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblOper.Location = new System.Drawing.Point(113, 271);
            this.lblOper.Name = "lblOper";
            this.lblOper.Size = new System.Drawing.Size(189, 13);
            this.lblOper.TabIndex = 40;
            // 
            // txtOper
            // 
            this.txtOper.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtOper.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOper.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOper.ForeColor = System.Drawing.Color.MediumBlue;
            this.txtOper.Location = new System.Drawing.Point(45, 271);
            this.txtOper.Name = "txtOper";
            this.txtOper.Size = new System.Drawing.Size(69, 13);
            this.txtOper.TabIndex = 39;
            this.txtOper.DoubleClick += new System.EventHandler(this.txtOper_DoubleClick);
            this.txtOper.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOper_KeyDown);
            // 
            // lbServer
            // 
            this.lbServer.BackColor = System.Drawing.Color.Transparent;
            this.lbServer.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbServer.ForeColor = System.Drawing.Color.Gold;
            this.lbServer.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbServer.Location = new System.Drawing.Point(5, 13);
            this.lbServer.Name = "lbServer";
            this.lbServer.Size = new System.Drawing.Size(64, 23);
            this.lbServer.TabIndex = 6;
            this.lbServer.Text = "Server";
            this.lbServer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbDate
            // 
            this.lbDate.BackColor = System.Drawing.Color.Transparent;
            this.lbDate.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDate.ForeColor = System.Drawing.Color.Gold;
            this.lbDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbDate.Location = new System.Drawing.Point(5, 47);
            this.lbDate.Name = "lbDate";
            this.lbDate.Size = new System.Drawing.Size(64, 23);
            this.lbDate.TabIndex = 5;
            this.lbDate.Text = "Date";
            this.lbDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNode
            // 
            this.lblNode.BackColor = System.Drawing.Color.Transparent;
            this.lblNode.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNode.ForeColor = System.Drawing.Color.White;
            this.lblNode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblNode.Location = new System.Drawing.Point(94, 31);
            this.lblNode.Name = "lblNode";
            this.lblNode.Size = new System.Drawing.Size(222, 24);
            this.lblNode.TabIndex = 10;
            this.lblNode.Text = "lblNode";
            this.lblNode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblServer
            // 
            this.lblServer.BackColor = System.Drawing.Color.Transparent;
            this.lblServer.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServer.ForeColor = System.Drawing.Color.White;
            this.lblServer.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblServer.Location = new System.Drawing.Point(94, 13);
            this.lblServer.Name = "lblServer";
            this.lblServer.Size = new System.Drawing.Size(222, 24);
            this.lblServer.TabIndex = 4;
            this.lblServer.Text = "lblServer";
            this.lblServer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDate
            // 
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblDate.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.White;
            this.lblDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDate.Location = new System.Drawing.Point(94, 47);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(222, 24);
            this.lblDate.TabIndex = 3;
            this.lblDate.Text = "lblDate";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblType
            // 
            this.lblType.BackColor = System.Drawing.Color.Transparent;
            this.lblType.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblType.ForeColor = System.Drawing.Color.Gold;
            this.lblType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblType.Location = new System.Drawing.Point(4, 136);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(65, 23);
            this.lblType.TabIndex = 17;
            this.lblType.Text = "Type";
            this.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbNode
            // 
            this.lbNode.BackColor = System.Drawing.Color.Transparent;
            this.lbNode.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNode.ForeColor = System.Drawing.Color.Gold;
            this.lbNode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbNode.Location = new System.Drawing.Point(5, 31);
            this.lbNode.Name = "lbNode";
            this.lbNode.Size = new System.Drawing.Size(64, 23);
            this.lbNode.TabIndex = 9;
            this.lbNode.Text = "Node";
            this.lbNode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbVer
            // 
            this.lbVer.BackColor = System.Drawing.Color.Transparent;
            this.lbVer.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbVer.ForeColor = System.Drawing.Color.Gold;
            this.lbVer.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbVer.Location = new System.Drawing.Point(5, 63);
            this.lbVer.Name = "lbVer";
            this.lbVer.Size = new System.Drawing.Size(77, 23);
            this.lbVer.TabIndex = 11;
            this.lbVer.Text = "Version";
            this.lbVer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblScanType
            // 
            this.lblScanType.BackColor = System.Drawing.Color.Transparent;
            this.lblScanType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblScanType.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScanType.ForeColor = System.Drawing.Color.White;
            this.lblScanType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblScanType.Location = new System.Drawing.Point(94, 136);
            this.lblScanType.Name = "lblScanType";
            this.lblScanType.Size = new System.Drawing.Size(186, 24);
            this.lblScanType.TabIndex = 16;
            this.lblScanType.Text = "assy";
            this.lblScanType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblVer
            // 
            this.lblVer.BackColor = System.Drawing.Color.Transparent;
            this.lblVer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblVer.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVer.ForeColor = System.Drawing.Color.White;
            this.lblVer.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblVer.Location = new System.Drawing.Point(94, 63);
            this.lblVer.Name = "lblVer";
            this.lblVer.Size = new System.Drawing.Size(209, 24);
            this.lblVer.TabIndex = 12;
            this.lblVer.Text = "lblVer";
            this.lblVer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbModelInfo
            // 
            this.lbModelInfo.BackColor = System.Drawing.Color.Transparent;
            this.lbModelInfo.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbModelInfo.ForeColor = System.Drawing.Color.Gold;
            this.lbModelInfo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbModelInfo.Location = new System.Drawing.Point(5, 94);
            this.lbModelInfo.Name = "lbModelInfo";
            this.lbModelInfo.Size = new System.Drawing.Size(64, 23);
            this.lbModelInfo.TabIndex = 13;
            this.lbModelInfo.Text = "Model";
            this.lbModelInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblModel
            // 
            this.lblModel.BackColor = System.Drawing.Color.Transparent;
            this.lblModel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblModel.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModel.ForeColor = System.Drawing.Color.White;
            this.lblModel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblModel.Location = new System.Drawing.Point(97, 83);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(228, 47);
            this.lblModel.TabIndex = 14;
            this.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PictureBox1
            // 
            this.PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox1.Image")));
            this.PictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PictureBox1.Location = new System.Drawing.Point(10, 268);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(29, 19);
            this.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBox1.TabIndex = 0;
            this.PictureBox1.TabStop = false;
            // 
            // M1
            // 
            this.M1.BackColor = System.Drawing.Color.Transparent;
            this.M1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M1.ForeColor = System.Drawing.SystemColors.Info;
            this.M1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.M1.Location = new System.Drawing.Point(8, 11);
            this.M1.Name = "M1";
            this.M1.Size = new System.Drawing.Size(95, 23);
            this.M1.TabIndex = 19;
            this.M1.Text = "MainSeal";
            this.M1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GroupBox5
            // 
            this.GroupBox5.BackColor = System.Drawing.Color.Transparent;
            this.GroupBox5.Controls.Add(this.txtBarcodeScan);
            this.GroupBox5.Controls.Add(this.txtscan2);
            this.GroupBox5.Controls.Add(this.s6);
            this.GroupBox5.Controls.Add(this.txtscan6);
            this.GroupBox5.Controls.Add(this.s5);
            this.GroupBox5.Controls.Add(this.txtscan5);
            this.GroupBox5.Controls.Add(this.s4);
            this.GroupBox5.Controls.Add(this.txtscan4);
            this.GroupBox5.Controls.Add(this.s3);
            this.GroupBox5.Controls.Add(this.txtscan3);
            this.GroupBox5.Controls.Add(this.s2);
            this.GroupBox5.Controls.Add(this.s1);
            this.GroupBox5.Controls.Add(this.txtscan1);
            this.GroupBox5.Controls.Add(this.M1);
            this.GroupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox5.ForeColor = System.Drawing.Color.YellowGreen;
            this.GroupBox5.Location = new System.Drawing.Point(6, 73);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(327, 192);
            this.GroupBox5.TabIndex = 59;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "PCB SCAN";
            // 
            // txtBarcodeScan
            // 
            this.txtBarcodeScan.BackColor = System.Drawing.SystemColors.Window;
            this.txtBarcodeScan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarcodeScan.Location = new System.Drawing.Point(104, 13);
            this.txtBarcodeScan.Name = "txtBarcodeScan";
            this.txtBarcodeScan.Size = new System.Drawing.Size(194, 20);
            this.txtBarcodeScan.TabIndex = 85;
            this.txtBarcodeScan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBarcodeScan_KeyPress_1);
            // 
            // txtscan2
            // 
            this.txtscan2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtscan2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscan2.Location = new System.Drawing.Point(104, 64);
            this.txtscan2.Name = "txtscan2";
            this.txtscan2.Size = new System.Drawing.Size(194, 20);
            this.txtscan2.TabIndex = 74;
            this.txtscan2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtscan2_KeyPress);
            // 
            // s6
            // 
            this.s6.BackColor = System.Drawing.Color.Transparent;
            this.s6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s6.ForeColor = System.Drawing.SystemColors.Info;
            this.s6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.s6.Location = new System.Drawing.Point(4, 166);
            this.s6.Name = "s6";
            this.s6.Size = new System.Drawing.Size(99, 23);
            this.s6.TabIndex = 84;
            this.s6.Text = "Scan6";
            this.s6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtscan6
            // 
            this.txtscan6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtscan6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscan6.Location = new System.Drawing.Point(104, 167);
            this.txtscan6.Name = "txtscan6";
            this.txtscan6.Size = new System.Drawing.Size(194, 20);
            this.txtscan6.TabIndex = 83;
            this.txtscan6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtscan6_KeyPress);
            // 
            // s5
            // 
            this.s5.BackColor = System.Drawing.Color.Transparent;
            this.s5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s5.ForeColor = System.Drawing.SystemColors.Info;
            this.s5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.s5.Location = new System.Drawing.Point(3, 142);
            this.s5.Name = "s5";
            this.s5.Size = new System.Drawing.Size(100, 23);
            this.s5.TabIndex = 82;
            this.s5.Text = "Scan5";
            this.s5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtscan5
            // 
            this.txtscan5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtscan5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscan5.Location = new System.Drawing.Point(104, 142);
            this.txtscan5.Name = "txtscan5";
            this.txtscan5.Size = new System.Drawing.Size(194, 20);
            this.txtscan5.TabIndex = 81;
            this.txtscan5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtscan5_KeyPress);
            // 
            // s4
            // 
            this.s4.BackColor = System.Drawing.Color.Transparent;
            this.s4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s4.ForeColor = System.Drawing.SystemColors.Info;
            this.s4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.s4.Location = new System.Drawing.Point(3, 113);
            this.s4.Name = "s4";
            this.s4.Size = new System.Drawing.Size(100, 23);
            this.s4.TabIndex = 80;
            this.s4.Text = "Scan4";
            this.s4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtscan4
            // 
            this.txtscan4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtscan4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscan4.Location = new System.Drawing.Point(104, 115);
            this.txtscan4.Name = "txtscan4";
            this.txtscan4.Size = new System.Drawing.Size(194, 20);
            this.txtscan4.TabIndex = 79;
            this.txtscan4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtscan4_KeyPress);
            // 
            // s3
            // 
            this.s3.BackColor = System.Drawing.Color.Transparent;
            this.s3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s3.ForeColor = System.Drawing.SystemColors.Info;
            this.s3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.s3.Location = new System.Drawing.Point(3, 89);
            this.s3.Name = "s3";
            this.s3.Size = new System.Drawing.Size(100, 23);
            this.s3.TabIndex = 78;
            this.s3.Text = "Scan3";
            this.s3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtscan3
            // 
            this.txtscan3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtscan3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscan3.Location = new System.Drawing.Point(104, 89);
            this.txtscan3.Name = "txtscan3";
            this.txtscan3.Size = new System.Drawing.Size(194, 20);
            this.txtscan3.TabIndex = 77;
            this.txtscan3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtscan3_KeyPress);
            // 
            // s2
            // 
            this.s2.BackColor = System.Drawing.Color.Transparent;
            this.s2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s2.ForeColor = System.Drawing.SystemColors.Info;
            this.s2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.s2.Location = new System.Drawing.Point(3, 62);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(100, 23);
            this.s2.TabIndex = 76;
            this.s2.Text = "Scan2";
            this.s2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // s1
            // 
            this.s1.BackColor = System.Drawing.Color.Transparent;
            this.s1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s1.ForeColor = System.Drawing.SystemColors.Info;
            this.s1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.s1.Location = new System.Drawing.Point(3, 36);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(100, 23);
            this.s1.TabIndex = 75;
            this.s1.Text = "Scan1";
            this.s1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtscan1
            // 
            this.txtscan1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtscan1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscan1.Location = new System.Drawing.Point(104, 38);
            this.txtscan1.Name = "txtscan1";
            this.txtscan1.Size = new System.Drawing.Size(194, 20);
            this.txtscan1.TabIndex = 73;
            this.txtscan1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtscan1_KeyPress);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.cbModel);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.YellowGreen;
            this.groupBox4.Location = new System.Drawing.Point(341, 74);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(336, 38);
            this.groupBox4.TabIndex = 61;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "MODEL SELECT";
            // 
            // cbModel
            // 
            this.cbModel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbModel.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbModel.BackColor = System.Drawing.Color.White;
            this.cbModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.cbModel.ForeColor = System.Drawing.Color.Blue;
            this.cbModel.FormattingEnabled = true;
            this.cbModel.Location = new System.Drawing.Point(48, 10);
            this.cbModel.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.cbModel.Name = "cbModel";
            this.cbModel.Size = new System.Drawing.Size(254, 21);
            this.cbModel.TabIndex = 161;
            this.cbModel.SelectedIndexChanged += new System.EventHandler(this.cbModel_SelectedIndexChanged);
            this.cbModel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cbModel_MouseClick);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.Info;
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(6, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 23);
            this.label13.TabIndex = 19;
            this.label13.Text = "MODEL";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TimerErr
            // 
            this.TimerErr.Interval = 10;
            // 
            // timer3
            // 
            this.timer3.Interval = 10;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.GroupBox1.Controls.Add(this.Product_OK_Count);
            this.GroupBox1.Controls.Add(this.Product_NG_Count);
            this.GroupBox1.Controls.Add(this.txt_Plan_Qty);
            this.GroupBox1.Controls.Add(this.TmStart);
            this.GroupBox1.Controls.Add(this.lbl_plan_Qty);
            this.GroupBox1.Controls.Add(this.lbl_product_Qty);
            this.GroupBox1.Controls.Add(this.lbl_NG_Qty);
            this.GroupBox1.Controls.Add(this.Btn_Reset1);
            this.GroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.GroupBox1.ForeColor = System.Drawing.Color.YellowGreen;
            this.GroupBox1.Location = new System.Drawing.Point(6, 26);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(1362, 46);
            this.GroupBox1.TabIndex = 63;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Information";
            // 
            // Product_OK_Count
            // 
            this.Product_OK_Count.BackColor = System.Drawing.Color.White;
            this.Product_OK_Count.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Product_OK_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_OK_Count.ForeColor = System.Drawing.Color.Blue;
            this.Product_OK_Count.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Product_OK_Count.Location = new System.Drawing.Point(224, 17);
            this.Product_OK_Count.Margin = new System.Windows.Forms.Padding(0);
            this.Product_OK_Count.Name = "Product_OK_Count";
            this.Product_OK_Count.Size = new System.Drawing.Size(80, 20);
            this.Product_OK_Count.TabIndex = 36;
            this.Product_OK_Count.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Product_NG_Count
            // 
            this.Product_NG_Count.BackColor = System.Drawing.Color.NavajoWhite;
            this.Product_NG_Count.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Product_NG_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_NG_Count.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Product_NG_Count.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Product_NG_Count.Location = new System.Drawing.Point(367, 17);
            this.Product_NG_Count.Margin = new System.Windows.Forms.Padding(0);
            this.Product_NG_Count.Name = "Product_NG_Count";
            this.Product_NG_Count.Size = new System.Drawing.Size(80, 20);
            this.Product_NG_Count.TabIndex = 37;
            this.Product_NG_Count.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_Plan_Qty
            // 
            this.txt_Plan_Qty.AcceptsReturn = true;
            this.txt_Plan_Qty.BackColor = System.Drawing.Color.White;
            this.txt_Plan_Qty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Plan_Qty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Plan_Qty.ForeColor = System.Drawing.Color.Blue;
            this.txt_Plan_Qty.Location = new System.Drawing.Point(63, 17);
            this.txt_Plan_Qty.MaxLength = 5;
            this.txt_Plan_Qty.Multiline = true;
            this.txt_Plan_Qty.Name = "txt_Plan_Qty";
            this.txt_Plan_Qty.Size = new System.Drawing.Size(80, 20);
            this.txt_Plan_Qty.TabIndex = 38;
            this.txt_Plan_Qty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TmStart
            // 
            this.TmStart.AutoSize = true;
            this.TmStart.BackColor = System.Drawing.Color.White;
            this.TmStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TmStart.ForeColor = System.Drawing.Color.Black;
            this.TmStart.Location = new System.Drawing.Point(458, 18);
            this.TmStart.Margin = new System.Windows.Forms.Padding(3);
            this.TmStart.Name = "TmStart";
            this.TmStart.Padding = new System.Windows.Forms.Padding(3);
            this.TmStart.Size = new System.Drawing.Size(129, 19);
            this.TmStart.TabIndex = 35;
            this.TmStart.Text = "03/14/2018 7:00:00 AM";
            // 
            // lbl_plan_Qty
            // 
            this.lbl_plan_Qty.BackColor = System.Drawing.Color.Transparent;
            this.lbl_plan_Qty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_plan_Qty.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbl_plan_Qty.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_plan_Qty.Location = new System.Drawing.Point(-9, 5);
            this.lbl_plan_Qty.Name = "lbl_plan_Qty";
            this.lbl_plan_Qty.Size = new System.Drawing.Size(83, 40);
            this.lbl_plan_Qty.TabIndex = 24;
            this.lbl_plan_Qty.Text = "Plan Qty";
            this.lbl_plan_Qty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_product_Qty
            // 
            this.lbl_product_Qty.BackColor = System.Drawing.Color.Transparent;
            this.lbl_product_Qty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_product_Qty.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbl_product_Qty.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_product_Qty.Location = new System.Drawing.Point(129, 3);
            this.lbl_product_Qty.Name = "lbl_product_Qty";
            this.lbl_product_Qty.Size = new System.Drawing.Size(112, 49);
            this.lbl_product_Qty.TabIndex = 21;
            this.lbl_product_Qty.Text = "Product Qty";
            this.lbl_product_Qty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_NG_Qty
            // 
            this.lbl_NG_Qty.BackColor = System.Drawing.Color.Transparent;
            this.lbl_NG_Qty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NG_Qty.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbl_NG_Qty.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_NG_Qty.Location = new System.Drawing.Point(300, 12);
            this.lbl_NG_Qty.Name = "lbl_NG_Qty";
            this.lbl_NG_Qty.Size = new System.Drawing.Size(72, 29);
            this.lbl_NG_Qty.TabIndex = 22;
            this.lbl_NG_Qty.Text = "NG Q\'ty";
            this.lbl_NG_Qty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Btn_Reset1
            // 
            this.Btn_Reset1.BackColor = System.Drawing.Color.DimGray;
            this.Btn_Reset1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Reset1.ForeColor = System.Drawing.Color.White;
            this.Btn_Reset1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Btn_Reset1.Location = new System.Drawing.Point(593, 17);
            this.Btn_Reset1.Margin = new System.Windows.Forms.Padding(0);
            this.Btn_Reset1.Name = "Btn_Reset1";
            this.Btn_Reset1.Size = new System.Drawing.Size(50, 22);
            this.Btn_Reset1.TabIndex = 28;
            this.Btn_Reset1.Text = "Reset";
            this.Btn_Reset1.UseVisualStyleBackColor = false;
            this.Btn_Reset1.Click += new System.EventHandler(this.Btn_Reset1_Click);
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.BackColor = System.Drawing.Color.DarkOrange;
            this.MenuStrip1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SetupToolStripMenuItem,
            this.setINIToolStripMenuItem,
            this.scanSetupToolStripMenuItem});
            this.MenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.MenuStrip1.Size = new System.Drawing.Size(1370, 24);
            this.MenuStrip1.TabIndex = 64;
            this.MenuStrip1.Text = "MenuStrip1";
            // 
            // SetupToolStripMenuItem
            // 
            this.SetupToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.SetupToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.SetupToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.SetupToolStripMenuItem.Name = "SetupToolStripMenuItem";
            this.SetupToolStripMenuItem.Size = new System.Drawing.Size(37, 24);
            this.SetupToolStripMenuItem.Text = "File";
            this.SetupToolStripMenuItem.Click += new System.EventHandler(this.SetupToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click_1);
            // 
            // setINIToolStripMenuItem
            // 
            this.setINIToolStripMenuItem.Name = "setINIToolStripMenuItem";
            this.setINIToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
            this.setINIToolStripMenuItem.Text = "Set INI";
            this.setINIToolStripMenuItem.Click += new System.EventHandler(this.setINIToolStripMenuItem_Click);
            // 
            // scanSetupToolStripMenuItem
            // 
            this.scanSetupToolStripMenuItem.Name = "scanSetupToolStripMenuItem";
            this.scanSetupToolStripMenuItem.Size = new System.Drawing.Size(76, 24);
            this.scanSetupToolStripMenuItem.Text = "Scan Setup";
            this.scanSetupToolStripMenuItem.Click += new System.EventHandler(this.scanSetupToolStripMenuItem_Click);
            // 
            // grpStatus
            // 
            this.grpStatus.BackColor = System.Drawing.Color.Transparent;
            this.grpStatus.Controls.Add(this.lblResult);
            this.grpStatus.Controls.Add(this.Panel7);
            this.grpStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.grpStatus.ForeColor = System.Drawing.Color.YellowGreen;
            this.grpStatus.Location = new System.Drawing.Point(6, 266);
            this.grpStatus.Name = "grpStatus";
            this.grpStatus.Size = new System.Drawing.Size(328, 139);
            this.grpStatus.TabIndex = 68;
            this.grpStatus.TabStop = false;
            this.grpStatus.Text = "Status";
            // 
            // lblResult
            // 
            this.lblResult.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.Black;
            this.lblResult.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblResult.Location = new System.Drawing.Point(13, 16);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(307, 52);
            this.lblResult.TabIndex = 13;
            this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel7
            // 
            this.Panel7.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.Panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Panel7.BackgroundImage")));
            this.Panel7.Controls.Add(this.Panel8);
            this.Panel7.Location = new System.Drawing.Point(10, 74);
            this.Panel7.Name = "Panel7";
            this.Panel7.Size = new System.Drawing.Size(310, 60);
            this.Panel7.TabIndex = 9;
            // 
            // Panel8
            // 
            this.Panel8.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Panel8.Controls.Add(this.txtResult);
            this.Panel8.Location = new System.Drawing.Point(6, 6);
            this.Panel8.Name = "Panel8";
            this.Panel8.Size = new System.Drawing.Size(300, 49);
            this.Panel8.TabIndex = 0;
            // 
            // txtResult
            // 
            this.txtResult.BackColor = System.Drawing.Color.White;
            this.txtResult.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResult.ForeColor = System.Drawing.Color.Black;
            this.txtResult.Location = new System.Drawing.Point(7, 4);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResult.Size = new System.Drawing.Size(292, 39);
            this.txtResult.TabIndex = 9;
            // 
            // group_scan_setup
            // 
            this.group_scan_setup.BackColor = System.Drawing.Color.Transparent;
            this.group_scan_setup.Controls.Add(this.sp1);
            this.group_scan_setup.Controls.Add(this.sp6);
            this.group_scan_setup.Controls.Add(this.sp5);
            this.group_scan_setup.Controls.Add(this.sp4);
            this.group_scan_setup.Controls.Add(this.sp3);
            this.group_scan_setup.Controls.Add(this.sp2);
            this.group_scan_setup.Controls.Add(this.label18);
            this.group_scan_setup.Controls.Add(this.label17);
            this.group_scan_setup.Controls.Add(this.label16);
            this.group_scan_setup.Controls.Add(this.label14);
            this.group_scan_setup.Controls.Add(this.label11);
            this.group_scan_setup.Controls.Add(this.label2);
            this.group_scan_setup.Controls.Add(this.save1);
            this.group_scan_setup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.group_scan_setup.ForeColor = System.Drawing.Color.YellowGreen;
            this.group_scan_setup.Location = new System.Drawing.Point(740, 101);
            this.group_scan_setup.Name = "group_scan_setup";
            this.group_scan_setup.Size = new System.Drawing.Size(306, 190);
            this.group_scan_setup.TabIndex = 71;
            this.group_scan_setup.TabStop = false;
            this.group_scan_setup.Text = "ScanSetup";
            // 
            // save1
            // 
            this.save1.BackColor = System.Drawing.Color.DimGray;
            this.save1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save1.ForeColor = System.Drawing.Color.White;
            this.save1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.save1.Location = new System.Drawing.Point(115, 154);
            this.save1.Margin = new System.Windows.Forms.Padding(0);
            this.save1.Name = "save1";
            this.save1.Size = new System.Drawing.Size(77, 23);
            this.save1.TabIndex = 29;
            this.save1.Text = "Save";
            this.save1.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(6, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 23);
            this.label2.TabIndex = 43;
            this.label2.Text = "SC1";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gold;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(6, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 23);
            this.label11.TabIndex = 44;
            this.label11.Text = "SC2";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gold;
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(6, 62);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 23);
            this.label14.TabIndex = 45;
            this.label14.Text = "SC3";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Gold;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(5, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 23);
            this.label16.TabIndex = 46;
            this.label16.Text = "SC4";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Gold;
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(5, 106);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 23);
            this.label17.TabIndex = 70;
            this.label17.Text = "SC5";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Gold;
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(5, 127);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(38, 23);
            this.label18.TabIndex = 70;
            this.label18.Text = "SC6";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sp1
            // 
            this.sp1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.sp1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.sp1.BackColor = System.Drawing.Color.White;
            this.sp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.sp1.ForeColor = System.Drawing.Color.Blue;
            this.sp1.FormattingEnabled = true;
            this.sp1.Location = new System.Drawing.Point(40, 18);
            this.sp1.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.sp1.Name = "sp1";
            this.sp1.Size = new System.Drawing.Size(253, 20);
            this.sp1.TabIndex = 162;
            // 
            // sp2
            // 
            this.sp2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.sp2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.sp2.BackColor = System.Drawing.Color.White;
            this.sp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.sp2.ForeColor = System.Drawing.Color.Blue;
            this.sp2.FormattingEnabled = true;
            this.sp2.Location = new System.Drawing.Point(40, 40);
            this.sp2.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.sp2.Name = "sp2";
            this.sp2.Size = new System.Drawing.Size(253, 20);
            this.sp2.TabIndex = 163;
            // 
            // sp3
            // 
            this.sp3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.sp3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.sp3.BackColor = System.Drawing.Color.White;
            this.sp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.sp3.ForeColor = System.Drawing.Color.Blue;
            this.sp3.FormattingEnabled = true;
            this.sp3.Location = new System.Drawing.Point(40, 62);
            this.sp3.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.sp3.Name = "sp3";
            this.sp3.Size = new System.Drawing.Size(253, 20);
            this.sp3.TabIndex = 164;
            // 
            // sp4
            // 
            this.sp4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.sp4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.sp4.BackColor = System.Drawing.Color.White;
            this.sp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.sp4.ForeColor = System.Drawing.Color.Blue;
            this.sp4.FormattingEnabled = true;
            this.sp4.Location = new System.Drawing.Point(39, 84);
            this.sp4.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.sp4.Name = "sp4";
            this.sp4.Size = new System.Drawing.Size(254, 20);
            this.sp4.TabIndex = 165;
            // 
            // sp5
            // 
            this.sp5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.sp5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.sp5.BackColor = System.Drawing.Color.White;
            this.sp5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.sp5.ForeColor = System.Drawing.Color.Blue;
            this.sp5.FormattingEnabled = true;
            this.sp5.Location = new System.Drawing.Point(40, 106);
            this.sp5.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.sp5.Name = "sp5";
            this.sp5.Size = new System.Drawing.Size(254, 20);
            this.sp5.TabIndex = 166;
            // 
            // sp6
            // 
            this.sp6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.sp6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.sp6.BackColor = System.Drawing.Color.White;
            this.sp6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.sp6.ForeColor = System.Drawing.Color.Blue;
            this.sp6.FormattingEnabled = true;
            this.sp6.Location = new System.Drawing.Point(40, 129);
            this.sp6.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.sp6.Name = "sp6";
            this.sp6.Size = new System.Drawing.Size(254, 20);
            this.sp6.TabIndex = 167;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Magenta;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1370, 445);
            this.Controls.Add(this.group_scan_setup);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.grpStatus);
            this.Controls.Add(this.MenuStrip1);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.GroupBox5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Application Assembly Process";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            this.grpStatus.ResumeLayout(false);
            this.Panel7.ResumeLayout(false);
            this.Panel8.ResumeLayout(false);
            this.Panel8.PerformLayout();
            this.group_scan_setup.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Label lbServer;
        internal System.Windows.Forms.Label lbDate;
        internal System.Windows.Forms.Label lblNode;
        internal System.Windows.Forms.Label lblServer;
        internal System.Windows.Forms.Label lblDate;
        internal System.Windows.Forms.Label lblType;
        internal System.Windows.Forms.Label lbNode;
        internal System.Windows.Forms.Label lbVer;
        internal System.Windows.Forms.Label lblScanType;
        internal System.Windows.Forms.Label lblVer;
        internal System.Windows.Forms.Label lbModelInfo;
        internal System.Windows.Forms.Label lblModel;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.Label M1;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.GroupBox groupBox4;
        internal System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox lblOper;
        private System.Windows.Forms.TextBox txtOper;
        internal System.Windows.Forms.ComboBox cbModel;
        internal System.Windows.Forms.Label s2;
        internal System.Windows.Forms.Label s1;
        private System.Windows.Forms.TextBox txtscan2;
        private System.Windows.Forms.TextBox txtscan1;
        private System.Windows.Forms.Timer TimerErr;
        private System.Windows.Forms.Timer timer3;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Label Product_OK_Count;
        internal System.Windows.Forms.Label Product_NG_Count;
        internal System.Windows.Forms.TextBox txt_Plan_Qty;
        private System.Windows.Forms.Label TmStart;
        internal System.Windows.Forms.Label lbl_plan_Qty;
        internal System.Windows.Forms.Label lbl_product_Qty;
        internal System.Windows.Forms.Label lbl_NG_Qty;
        internal System.Windows.Forms.Button Btn_Reset1;
        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem SetupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        internal System.Windows.Forms.GroupBox grpStatus;
        internal System.Windows.Forms.Label lblResult;
        internal System.Windows.Forms.Panel Panel7;
        internal System.Windows.Forms.Panel Panel8;
        internal System.Windows.Forms.TextBox txtResult;
        internal System.Windows.Forms.Timer timer2;
        internal System.Windows.Forms.Label lblscan6;
        internal System.Windows.Forms.Label sca6;
        internal System.Windows.Forms.Label lblscan5;
        internal System.Windows.Forms.Label sca5;
        internal System.Windows.Forms.Label lblscan4;
        internal System.Windows.Forms.Label sca4;
        internal System.Windows.Forms.Label lblscan3;
        internal System.Windows.Forms.Label sca3;
        internal System.Windows.Forms.Label lblscan2;
        internal System.Windows.Forms.Label sca2;
        internal System.Windows.Forms.Label lblscan1;
        internal System.Windows.Forms.Label sca1;
        internal System.Windows.Forms.Label s6;
        private System.Windows.Forms.TextBox txtscan6;
        internal System.Windows.Forms.Label s5;
        private System.Windows.Forms.TextBox txtscan5;
        internal System.Windows.Forms.Label s4;
        private System.Windows.Forms.TextBox txtscan4;
        internal System.Windows.Forms.Label s3;
        private System.Windows.Forms.TextBox txtscan3;
        private System.Windows.Forms.ToolStripMenuItem setINIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scanSetupToolStripMenuItem;
        private System.Windows.Forms.TextBox txtBarcodeScan;
        internal System.Windows.Forms.GroupBox group_scan_setup;
        internal System.Windows.Forms.ComboBox sp6;
        internal System.Windows.Forms.ComboBox sp5;
        internal System.Windows.Forms.ComboBox sp4;
        internal System.Windows.Forms.ComboBox sp3;
        internal System.Windows.Forms.ComboBox sp2;
        internal System.Windows.Forms.ComboBox sp1;
        internal System.Windows.Forms.Label label18;
        internal System.Windows.Forms.Label label17;
        internal System.Windows.Forms.Label label16;
        internal System.Windows.Forms.Label label14;
        internal System.Windows.Forms.Label label11;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Button save1;
    }
}

