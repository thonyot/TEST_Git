﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApp1
{
    class Function
    {
        public static void setStrXMTuner(string XMTunbarCode)
        {

        //    mdlGlobal.XMTunBarCode = XMTunbarCode;
        //    mdlGlobal.XMTunSub = mdlGlobal.XMTunBarCode.Substring(0, mdlGlobal.XMTunBarCode.IndexOf(" ,")).Trim();

        //    string temp_XMTunBarScan = XMTunbarCode;
        //    int i = 0;
        //    while (temp_XMTunBarScan.IndexOf(",") > 0)
        //    {
        //        mdlGlobal.XMTunBarCodeArray[i] = temp_XMTunBarScan.Substring(0, temp_XMTunBarScan.IndexOf(",")).Trim();
        //        temp_XMTunBarScan = temp_XMTunBarScan.Substring(temp_XMTunBarScan.IndexOf(",") + 1);
        //        i++;
        //        if (temp_XMTunBarScan.IndexOf(",") == 0) mdlGlobal.XMTunBarCodeArray[i] = temp_XMTunBarScan.Trim();

        //    }

        //    //foreach(var a in mdlGlobal.XMTunBarCodeArray)
        //    //{
        //    //    Console.WriteLine(a);
        //    //}
        //    mdlGlobal.XMTunKey = mdlGlobal.XMTunBarCodeArray[2].Substring(0, 8).Trim();
        //    //Console.WriteLine(mdlGlobal.XMTunKey);
        }
    }
}
