﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    class mdlGlobal
    {
        //////For Run in Pi3
        //public static string path = @"/home/pi/Setup_XM.txt";
        //public static string pathD = @"/home/pi/tmpTime.txt";
        //public static string path_store = @"/home/pi/Stored_Procedure.txt";
        //public static string path_scan = @"/home/pi/ScanSetup_XM.txt";

        //////public static SoundPlayer Player = new SoundPlayer(@"/home/pi/SOUND108.wav");
        //////public static SoundPlayer Player1 = new SoundPlayer(@"/home/pi/chimes.wav");

        //For Test
        public static string path = @"C:/Setup_XM.txt";
        public static string pathD = @"C:/tmpTime.txt";
        public static string path_store = @"C:/Stored_Procedure.txt";
        public static string path_scan = @"C:/ScanSetup_XM.txt";

        public static string dbconnection = "Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;";

        //////public static SoundPlayer Player = new SoundPlayer(@"C:/SOUND108.wav");
        //////public static SoundPlayer Player1 = new SoundPlayer(@"C:/chimes.wav");

        //SqlConnection sqlconnection = new SqlConnection();
        //SqlConnection conn = new SqlConnection(@"Data Source=10.84.57.108;database=CDataDB;uid=sa;password=@sysmanager;");

        public static string node;
        public static string server;
        public static string username;
        public static string password;
        public static string test_type;
        public static string ModelSelection;
        public static string Execute_SP;       
        public static string Stored_Procedure;
        public static string SP1;
        public static string SP2;
        public static string SP3;
        public static string SP4;
        public static string SP5;
        public static string SP6;


        public static int a;
        public static string datetime1;
        public static string datetime2;
        public static string EmpName;
        public static string PCBsn;
        public static string pcbContent;
        public static string pcbModel;
        public static int time_count;
        public static int count_model;
        public static DateTime DataNow_DB;
        public static DateTime NowDB;
        public static String Tm_Start;
        public static String n;
        public static String m;
        public static int dcnt;
        public static int dcnt1;
        public static string SerialOK;
        public static string SerialNG;
        public static DateTime now = DateTime.Now;
        public static int Input_timeout;
        public static String PackingCode;
        public static String txt_result_message;
        public static string MsgNode;
        public static string msgCommentFinal;
        public static string nComment;
        public static string CurrentModelDescription;
        public static string CurrentModel;
        public static string model_check;
        public static string version1;
        public static string version2;
        public static string version3;
        public static int icokMain = 0;
        public static int icok_new = 0;
        public static Boolean play = false;
        public static string txtBarcodeScanIC1;
        public static string txtBarcodeScanIC2;
        public static string txtBarcodeScanIC3;
        public static int icok;
        public static string ProdEndScreenMsg;
        public static int txtPlanQty;
        public static int ProductOKCount;
        public static string txt_Plan_Qty_new;
        public static string XPass;
        public static string CurrentModelA = "";
        public static string IC_no;
        public static string subIC1;
        public static string subIC2;
        public static string subIC3;
        public static string scan_setup1;
        public static string scan_setup2;
        public static string scan_setup3;
        public static string scan_setup4;
        public static string scan_setup5;
        public static string scan_setup6;
        public static string setup_scan1;
        public static string setup_scan2;
        public static string setup_scan3;
        public static string setup_scan4;
        public static string setup_scan5;
        public static string setup_scan6;
        public static string return_flag;
        public static string pcb_type;
        public static int start1;
        public static int length1;
        public static string Content1;
        public static string pcb_type2;
        public static string pcb_type3;
        public static string pcb_type4;
        public static string pcb_type5;
        public static string pcb_type6;
        public static string xm_num;
        public static string sxm_num;
        public static string hw_num;
        public static string sn_num;
        public static string XM_ID;

        //----------------variable----------------------------
        public static string DB_XMTunerFull = "";
        public static string DB_XMKey = "";
        public static string DB_SubPCB = "";




        public static string SoundLocation { get; set; }

    }
}
