﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using Mono.Posix;
using Mono.Unix;
using Mono.Remoting.Channels.Unix;
using System.Windows.Forms;
using System.IO;
using Microsoft.Win32.SafeHandles;


namespace WindowsFormsApp1
{
    public class IniFile
    {

        //[StructLayout(LayoutKind.Sequential)]
        //internal struct SYSTEM_INFO
        //{
        //    public ushort wProcessorArchitecture;
        //    public ushort wReserved;
        //    public uint dwPageSize;
        //    public IntPtr lpMinimumApplicationAddress;
        //    public IntPtr lpMaximumApplicationAddress;
        //    public UIntPtr dwActiveProcessorMask;
        //    public uint dwNumberOfProcessors;
        //    public uint dwProcessorType;
        //    public uint dwAllocationGranularity;
        //    public ushort wProcessorLevel;
        //    public ushort wProcessorRevision;
        //}

        //[DllImport("kernel32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        //internal static extern void GetNativeSystemInfo(ref SYSTEM_INFO lpSystemInfo);



        public string path;
        // string Path = System.Environment.CurrentDirectory+"\\"+"ConfigFile.ini";       

        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section,
            string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section,
                 string key, string def, StringBuilder retVal,
            int size, string filePath);
        public IniFile(string Path)
        {
            path = Path;
        }

        public void IniWriteValue(string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, this.path);
        }

        public string IniReadValue(string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(255);
            int i = GetPrivateProfileString(Section, Key, "", temp,
                                            255, this.path);
            return temp.ToString();
            
        }

    }


}
