﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ProdEndScreen : Form
    {
        public ProdEndScreen()
        {
            InitializeComponent();
        }    
    

        private void ProdEndScreen_Load_1(object sender, EventArgs e)
        {
            Label1.Text = "";
            Label1.Text = mdlGlobal.ProdEndScreenMsg;
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    Close();
        //}

        private void button1_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
