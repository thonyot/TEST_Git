﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1.DialogFrm
{
    public partial class ScanSetup : Form
    {
        public ScanSetup()
        {
            InitializeComponent();
        }

        private void save1_Click(object sender, EventArgs e)
        {

        }
    }
}
