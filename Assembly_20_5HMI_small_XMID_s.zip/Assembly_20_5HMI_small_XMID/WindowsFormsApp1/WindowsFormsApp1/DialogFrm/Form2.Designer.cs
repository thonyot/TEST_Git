﻿namespace WindowsFormsApp1
{
    partial class FrmScan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.M1 = new System.Windows.Forms.Label();
            this.txtxm = new System.Windows.Forms.TextBox();
            this.txtsxm = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblResult1 = new System.Windows.Forms.Label();
            this.txthwid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // M1
            // 
            this.M1.BackColor = System.Drawing.Color.Transparent;
            this.M1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.M1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.M1.Location = new System.Drawing.Point(12, 23);
            this.M1.Name = "M1";
            this.M1.Size = new System.Drawing.Size(95, 23);
            this.M1.TabIndex = 86;
            this.M1.Text = "XM MODEL";
            this.M1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtxm
            // 
            this.txtxm.BackColor = System.Drawing.SystemColors.Window;
            this.txtxm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtxm.Location = new System.Drawing.Point(108, 26);
            this.txtxm.Name = "txtxm";
            this.txtxm.Size = new System.Drawing.Size(275, 20);
            this.txtxm.TabIndex = 87;
            this.txtxm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtxm_KeyPress);
            // 
            // txtsxm
            // 
            this.txtsxm.BackColor = System.Drawing.SystemColors.Window;
            this.txtsxm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsxm.Location = new System.Drawing.Point(108, 75);
            this.txtsxm.Name = "txtsxm";
            this.txtsxm.Size = new System.Drawing.Size(275, 20);
            this.txtsxm.TabIndex = 89;
            this.txtsxm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsxm_KeyPress);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(12, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 23);
            this.label1.TabIndex = 88;
            this.label1.Text = "SXM MARK";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblResult1
            // 
            this.lblResult1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult1.ForeColor = System.Drawing.Color.Black;
            this.lblResult1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblResult1.Location = new System.Drawing.Point(35, 153);
            this.lblResult1.Name = "lblResult1";
            this.lblResult1.Size = new System.Drawing.Size(332, 80);
            this.lblResult1.TabIndex = 90;
            this.lblResult1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txthwid
            // 
            this.txthwid.BackColor = System.Drawing.SystemColors.Window;
            this.txthwid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthwid.Location = new System.Drawing.Point(108, 122);
            this.txthwid.Name = "txthwid";
            this.txthwid.Size = new System.Drawing.Size(275, 20);
            this.txthwid.TabIndex = 92;
            this.txthwid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txthwid_KeyPress);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(12, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 23);
            this.label2.TabIndex = 91;
            this.label2.Text = "HWID 2D PCB";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FrmScan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(408, 242);
            this.ControlBox = false;
            this.Controls.Add(this.txthwid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblResult1);
            this.Controls.Add(this.txtsxm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtxm);
            this.Controls.Add(this.M1);
            this.Name = "FrmScan";
            this.Text = "FrmScan";
            this.Load += new System.EventHandler(this.FrmScan_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label M1;
        private System.Windows.Forms.TextBox txtxm;
        private System.Windows.Forms.TextBox txtsxm;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label lblResult1;
        private System.Windows.Forms.TextBox txthwid;
        internal System.Windows.Forms.Label label2;
    }
}