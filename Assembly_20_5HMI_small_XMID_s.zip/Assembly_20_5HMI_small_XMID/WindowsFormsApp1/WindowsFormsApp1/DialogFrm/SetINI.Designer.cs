﻿namespace WindowsFormsApp1
{
    partial class SetINI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.group_setup_ini = new System.Windows.Forms.GroupBox();
            this.model_select = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.combo_sp6_ini = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.combo_sp5_ini = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.combo_sp4_ini = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.combo_sp3_ini = new System.Windows.Forms.ComboBox();
            this.sp3_ini = new System.Windows.Forms.Label();
            this.combo_sp2_ini = new System.Windows.Forms.ComboBox();
            this.sp2_ini = new System.Windows.Forms.Label();
            this.combo_sp1_ini = new System.Windows.Forms.ComboBox();
            this.sp1_ini = new System.Windows.Forms.Label();
            this.store_ini = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.exp_ini = new System.Windows.Forms.ComboBox();
            this.type_ini = new System.Windows.Forms.TextBox();
            this.pass_ini = new System.Windows.Forms.TextBox();
            this.user_ini = new System.Windows.Forms.TextBox();
            this.server_ini = new System.Windows.Forms.TextBox();
            this.node_ini = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Save2 = new System.Windows.Forms.Button();
            this.group_setup_ini.SuspendLayout();
            this.SuspendLayout();
            // 
            // group_setup_ini
            // 
            this.group_setup_ini.BackColor = System.Drawing.Color.Transparent;
            this.group_setup_ini.Controls.Add(this.model_select);
            this.group_setup_ini.Controls.Add(this.label21);
            this.group_setup_ini.Controls.Add(this.combo_sp6_ini);
            this.group_setup_ini.Controls.Add(this.label19);
            this.group_setup_ini.Controls.Add(this.combo_sp5_ini);
            this.group_setup_ini.Controls.Add(this.label20);
            this.group_setup_ini.Controls.Add(this.combo_sp4_ini);
            this.group_setup_ini.Controls.Add(this.label12);
            this.group_setup_ini.Controls.Add(this.combo_sp3_ini);
            this.group_setup_ini.Controls.Add(this.sp3_ini);
            this.group_setup_ini.Controls.Add(this.combo_sp2_ini);
            this.group_setup_ini.Controls.Add(this.sp2_ini);
            this.group_setup_ini.Controls.Add(this.combo_sp1_ini);
            this.group_setup_ini.Controls.Add(this.sp1_ini);
            this.group_setup_ini.Controls.Add(this.store_ini);
            this.group_setup_ini.Controls.Add(this.label8);
            this.group_setup_ini.Controls.Add(this.exp_ini);
            this.group_setup_ini.Controls.Add(this.type_ini);
            this.group_setup_ini.Controls.Add(this.pass_ini);
            this.group_setup_ini.Controls.Add(this.user_ini);
            this.group_setup_ini.Controls.Add(this.server_ini);
            this.group_setup_ini.Controls.Add(this.node_ini);
            this.group_setup_ini.Controls.Add(this.label1);
            this.group_setup_ini.Controls.Add(this.label3);
            this.group_setup_ini.Controls.Add(this.label4);
            this.group_setup_ini.Controls.Add(this.label5);
            this.group_setup_ini.Controls.Add(this.label6);
            this.group_setup_ini.Controls.Add(this.label7);
            this.group_setup_ini.Controls.Add(this.Save2);
            this.group_setup_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.group_setup_ini.ForeColor = System.Drawing.Color.YellowGreen;
            this.group_setup_ini.Location = new System.Drawing.Point(62, 26);
            this.group_setup_ini.Name = "group_setup_ini";
            this.group_setup_ini.Size = new System.Drawing.Size(295, 272);
            this.group_setup_ini.TabIndex = 71;
            this.group_setup_ini.TabStop = false;
            this.group_setup_ini.Text = "INI Setup";
            // 
            // model_select
            // 
            this.model_select.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.model_select.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.model_select.BackColor = System.Drawing.Color.White;
            this.model_select.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.model_select.ForeColor = System.Drawing.Color.Blue;
            this.model_select.FormattingEnabled = true;
            this.model_select.Location = new System.Drawing.Point(89, 234);
            this.model_select.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.model_select.Name = "model_select";
            this.model_select.Size = new System.Drawing.Size(188, 17);
            this.model_select.TabIndex = 188;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Gold;
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(2, 233);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(81, 23);
            this.label21.TabIndex = 189;
            this.label21.Text = "Model_select";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // combo_sp6_ini
            // 
            this.combo_sp6_ini.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_sp6_ini.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_sp6_ini.BackColor = System.Drawing.Color.White;
            this.combo_sp6_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_sp6_ini.ForeColor = System.Drawing.Color.Blue;
            this.combo_sp6_ini.FormattingEnabled = true;
            this.combo_sp6_ini.Location = new System.Drawing.Point(37, 217);
            this.combo_sp6_ini.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.combo_sp6_ini.Name = "combo_sp6_ini";
            this.combo_sp6_ini.Size = new System.Drawing.Size(240, 17);
            this.combo_sp6_ini.TabIndex = 186;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Gold;
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(3, 216);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 23);
            this.label19.TabIndex = 187;
            this.label19.Text = "SP6";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // combo_sp5_ini
            // 
            this.combo_sp5_ini.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_sp5_ini.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_sp5_ini.BackColor = System.Drawing.Color.White;
            this.combo_sp5_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_sp5_ini.ForeColor = System.Drawing.Color.Blue;
            this.combo_sp5_ini.FormattingEnabled = true;
            this.combo_sp5_ini.Location = new System.Drawing.Point(37, 200);
            this.combo_sp5_ini.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.combo_sp5_ini.Name = "combo_sp5_ini";
            this.combo_sp5_ini.Size = new System.Drawing.Size(240, 17);
            this.combo_sp5_ini.TabIndex = 184;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Gold;
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(3, 199);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 23);
            this.label20.TabIndex = 185;
            this.label20.Text = "SP5";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // combo_sp4_ini
            // 
            this.combo_sp4_ini.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_sp4_ini.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_sp4_ini.BackColor = System.Drawing.Color.White;
            this.combo_sp4_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_sp4_ini.ForeColor = System.Drawing.Color.Blue;
            this.combo_sp4_ini.FormattingEnabled = true;
            this.combo_sp4_ini.Location = new System.Drawing.Point(37, 183);
            this.combo_sp4_ini.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.combo_sp4_ini.Name = "combo_sp4_ini";
            this.combo_sp4_ini.Size = new System.Drawing.Size(240, 17);
            this.combo_sp4_ini.TabIndex = 182;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gold;
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(3, 182);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 23);
            this.label12.TabIndex = 183;
            this.label12.Text = "SP4";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // combo_sp3_ini
            // 
            this.combo_sp3_ini.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_sp3_ini.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_sp3_ini.BackColor = System.Drawing.Color.White;
            this.combo_sp3_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_sp3_ini.ForeColor = System.Drawing.Color.Blue;
            this.combo_sp3_ini.FormattingEnabled = true;
            this.combo_sp3_ini.Location = new System.Drawing.Point(37, 166);
            this.combo_sp3_ini.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.combo_sp3_ini.Name = "combo_sp3_ini";
            this.combo_sp3_ini.Size = new System.Drawing.Size(240, 17);
            this.combo_sp3_ini.TabIndex = 180;
            // 
            // sp3_ini
            // 
            this.sp3_ini.BackColor = System.Drawing.Color.Transparent;
            this.sp3_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sp3_ini.ForeColor = System.Drawing.Color.Gold;
            this.sp3_ini.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sp3_ini.Location = new System.Drawing.Point(3, 163);
            this.sp3_ini.Name = "sp3_ini";
            this.sp3_ini.Size = new System.Drawing.Size(35, 23);
            this.sp3_ini.TabIndex = 181;
            this.sp3_ini.Text = "SP3";
            this.sp3_ini.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // combo_sp2_ini
            // 
            this.combo_sp2_ini.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_sp2_ini.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_sp2_ini.BackColor = System.Drawing.Color.White;
            this.combo_sp2_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_sp2_ini.ForeColor = System.Drawing.Color.Blue;
            this.combo_sp2_ini.FormattingEnabled = true;
            this.combo_sp2_ini.Location = new System.Drawing.Point(37, 149);
            this.combo_sp2_ini.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.combo_sp2_ini.Name = "combo_sp2_ini";
            this.combo_sp2_ini.Size = new System.Drawing.Size(240, 17);
            this.combo_sp2_ini.TabIndex = 178;
            // 
            // sp2_ini
            // 
            this.sp2_ini.BackColor = System.Drawing.Color.Transparent;
            this.sp2_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sp2_ini.ForeColor = System.Drawing.Color.Gold;
            this.sp2_ini.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sp2_ini.Location = new System.Drawing.Point(3, 148);
            this.sp2_ini.Name = "sp2_ini";
            this.sp2_ini.Size = new System.Drawing.Size(29, 23);
            this.sp2_ini.TabIndex = 179;
            this.sp2_ini.Text = "SP2";
            this.sp2_ini.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // combo_sp1_ini
            // 
            this.combo_sp1_ini.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_sp1_ini.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_sp1_ini.BackColor = System.Drawing.Color.White;
            this.combo_sp1_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_sp1_ini.ForeColor = System.Drawing.Color.Blue;
            this.combo_sp1_ini.FormattingEnabled = true;
            this.combo_sp1_ini.Location = new System.Drawing.Point(37, 132);
            this.combo_sp1_ini.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.combo_sp1_ini.Name = "combo_sp1_ini";
            this.combo_sp1_ini.Size = new System.Drawing.Size(240, 17);
            this.combo_sp1_ini.TabIndex = 175;
            // 
            // sp1_ini
            // 
            this.sp1_ini.BackColor = System.Drawing.Color.Transparent;
            this.sp1_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sp1_ini.ForeColor = System.Drawing.Color.Gold;
            this.sp1_ini.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.sp1_ini.Location = new System.Drawing.Point(3, 132);
            this.sp1_ini.Name = "sp1_ini";
            this.sp1_ini.Size = new System.Drawing.Size(30, 23);
            this.sp1_ini.TabIndex = 177;
            this.sp1_ini.Text = "SP1";
            this.sp1_ini.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // store_ini
            // 
            this.store_ini.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.store_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.store_ini.Location = new System.Drawing.Point(38, 115);
            this.store_ini.Name = "store_ini";
            this.store_ini.Size = new System.Drawing.Size(239, 17);
            this.store_ini.TabIndex = 176;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gold;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(1, 114);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 23);
            this.label8.TabIndex = 174;
            this.label8.Text = "Store";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // exp_ini
            // 
            this.exp_ini.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.exp_ini.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.exp_ini.BackColor = System.Drawing.Color.White;
            this.exp_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exp_ini.ForeColor = System.Drawing.Color.Blue;
            this.exp_ini.FormattingEnabled = true;
            this.exp_ini.Location = new System.Drawing.Point(38, 98);
            this.exp_ini.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.exp_ini.Name = "exp_ini";
            this.exp_ini.Size = new System.Drawing.Size(240, 17);
            this.exp_ini.TabIndex = 173;
            // 
            // type_ini
            // 
            this.type_ini.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.type_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.type_ini.Location = new System.Drawing.Point(38, 81);
            this.type_ini.Name = "type_ini";
            this.type_ini.Size = new System.Drawing.Size(239, 17);
            this.type_ini.TabIndex = 172;
            // 
            // pass_ini
            // 
            this.pass_ini.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pass_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass_ini.Location = new System.Drawing.Point(38, 64);
            this.pass_ini.Name = "pass_ini";
            this.pass_ini.Size = new System.Drawing.Size(239, 17);
            this.pass_ini.TabIndex = 171;
            // 
            // user_ini
            // 
            this.user_ini.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.user_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_ini.Location = new System.Drawing.Point(38, 47);
            this.user_ini.Name = "user_ini";
            this.user_ini.Size = new System.Drawing.Size(239, 17);
            this.user_ini.TabIndex = 170;
            // 
            // server_ini
            // 
            this.server_ini.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.server_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.server_ini.Location = new System.Drawing.Point(38, 30);
            this.server_ini.Name = "server_ini";
            this.server_ini.Size = new System.Drawing.Size(239, 17);
            this.server_ini.TabIndex = 169;
            // 
            // node_ini
            // 
            this.node_ini.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.node_ini.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.node_ini.Location = new System.Drawing.Point(38, 13);
            this.node_ini.Name = "node_ini";
            this.node_ini.Size = new System.Drawing.Size(239, 17);
            this.node_ini.TabIndex = 168;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(0, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 23);
            this.label1.TabIndex = 70;
            this.label1.Text = "Exe_SP";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(1, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 23);
            this.label3.TabIndex = 70;
            this.label3.Text = "Type";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(2, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 23);
            this.label4.TabIndex = 46;
            this.label4.Text = "Pass";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(1, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 23);
            this.label5.TabIndex = 45;
            this.label5.Text = "User";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(2, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 23);
            this.label6.TabIndex = 44;
            this.label6.Text = "Server";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(3, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 23);
            this.label7.TabIndex = 43;
            this.label7.Text = "Node";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Save2
            // 
            this.Save2.BackColor = System.Drawing.Color.DimGray;
            this.Save2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Save2.ForeColor = System.Drawing.Color.White;
            this.Save2.Location = new System.Drawing.Point(109, 252);
            this.Save2.Name = "Save2";
            this.Save2.Size = new System.Drawing.Size(75, 17);
            this.Save2.TabIndex = 190;
            this.Save2.Text = "SAVE";
            this.Save2.UseVisualStyleBackColor = false;
            this.Save2.Click += new System.EventHandler(this.Save2_Click_1);
            // 
            // SetINI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 325);
            this.Controls.Add(this.group_setup_ini);
            this.Name = "SetINI";
            this.Text = "SetINI";
            this.Load += new System.EventHandler(this.SetINI_Load);
            this.group_setup_ini.ResumeLayout(false);
            this.group_setup_ini.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox group_setup_ini;
        internal System.Windows.Forms.ComboBox model_select;
        internal System.Windows.Forms.Label label21;
        internal System.Windows.Forms.ComboBox combo_sp6_ini;
        internal System.Windows.Forms.Label label19;
        internal System.Windows.Forms.ComboBox combo_sp5_ini;
        internal System.Windows.Forms.Label label20;
        internal System.Windows.Forms.ComboBox combo_sp4_ini;
        internal System.Windows.Forms.Label label12;
        internal System.Windows.Forms.ComboBox combo_sp3_ini;
        internal System.Windows.Forms.Label sp3_ini;
        internal System.Windows.Forms.ComboBox combo_sp2_ini;
        internal System.Windows.Forms.Label sp2_ini;
        internal System.Windows.Forms.ComboBox combo_sp1_ini;
        internal System.Windows.Forms.Label sp1_ini;
        private System.Windows.Forms.TextBox store_ini;
        internal System.Windows.Forms.Label label8;
        internal System.Windows.Forms.ComboBox exp_ini;
        private System.Windows.Forms.TextBox type_ini;
        private System.Windows.Forms.TextBox pass_ini;
        private System.Windows.Forms.TextBox user_ini;
        private System.Windows.Forms.TextBox server_ini;
        private System.Windows.Forms.TextBox node_ini;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Label label7;
        internal System.Windows.Forms.Button Save2;
    }
}