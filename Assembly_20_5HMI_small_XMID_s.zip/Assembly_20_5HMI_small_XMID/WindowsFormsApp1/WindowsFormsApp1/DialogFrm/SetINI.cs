﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class SetINI : Form
    {
        public SetINI()
        {
            InitializeComponent();
        }

        private void Save2_Click(object sender, EventArgs e)
        {

        }

        private void Save2_Click_1(object sender, EventArgs e)
        {
            //clear text              
            StreamWriter strm = File.CreateText(mdlGlobal.path);
            //StreamWriter strm = File.CreateText(@"/home/pi/Setup.txt");
            strm.Flush();
            strm.Close();

            // Create a string array with the additional lines of text
            string[] lines = { "Node = " + node_ini.Text, "Server = " + server_ini.Text, "Username = " + user_ini.Text, "Password = " + pass_ini.Text, "Test_Type = " + type_ini.Text, "Execute_SP = " + exp_ini.Text, "Stored_Procedure = " + store_ini.Text, "SP1 = " + combo_sp1_ini.Text, "SP2 = " + combo_sp2_ini.Text, "SP3 = " + combo_sp3_ini.Text, "SP4 = " + combo_sp4_ini.Text, "SP5 = " + combo_sp5_ini.Text, "SP6 = " + combo_sp6_ini.Text, "ModelSelection = " + model_select.Text };

            using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path))
            //using (StreamWriter outputFile = new StreamWriter(mdlGlobal.pathD))
            {
                foreach (string line in lines)
                    outputFile.WriteLine(line);
            }
            MessageBox.Show("Complete of Save");
            group_setup_ini.Visible = false;
        }
        void Get_Filestore()
        {

            if (!File.Exists(mdlGlobal.path_store))
            //if (!File.Exists(mdlGlobal.path_storeD))
            {
                // Create the file.
                using (FileStream fs = File.Create(mdlGlobal.path_store))
                //using (FileStream fs = File.Create(mdlGlobal.path_storeD))
                {
                    Byte[] info =
                        new UTF8Encoding(true).GetBytes("This is some text in the file.");

                    // Add some information to the file.
                    fs.Write(info, 0, info.Length);
                }
            }

            using (StreamReader sr = File.OpenText(mdlGlobal.path_store))
            //using (StreamReader sr = File.OpenText(mdlGlobal.path_storeD))
            {
                string s = "";
                var lines = "";
                while ((s = sr.ReadLine()) != null)
                {
                    lines = s;
                    string[] line = s.Split('=');
                    for (int i = 0; i < line.Length; i++)
                    {
                        combo_sp1_ini.Items.Add(line[i]);
                        combo_sp2_ini.Items.Add(line[i]);
                        combo_sp3_ini.Items.Add(line[i]);
                        combo_sp4_ini.Items.Add(line[i]);
                        combo_sp5_ini.Items.Add(line[i]);
                        combo_sp6_ini.Items.Add(line[i]);
                    }

                    combo_sp1_ini.Text = mdlGlobal.SP1;
                    combo_sp2_ini.Text = mdlGlobal.SP2;
                    combo_sp3_ini.Text = mdlGlobal.SP3;
                    combo_sp4_ini.Text = mdlGlobal.SP4;
                    combo_sp5_ini.Text = mdlGlobal.SP5;
                    combo_sp6_ini.Text = mdlGlobal.SP6;

                }
                System.Console.WriteLine();

            }
        }
        private void SetINI_Load(object sender, EventArgs e)
        {
            string[] exp = new string[2];
            string[] exp1 = new string[2];
            group_setup_ini.Visible = true;
            exp_ini.Items.Clear();
            combo_sp1_ini.Items.Clear();
            combo_sp2_ini.Items.Clear();
            combo_sp3_ini.Items.Clear();
            combo_sp4_ini.Items.Clear();
            combo_sp5_ini.Items.Clear();
            combo_sp6_ini.Items.Clear();
            node_ini.Text = mdlGlobal.node;
            server_ini.Text = mdlGlobal.server;
            user_ini.Text = mdlGlobal.username;
            pass_ini.Text = mdlGlobal.password;
            type_ini.Text = mdlGlobal.test_type;
            exp_ini.Text = mdlGlobal.Execute_SP;
            exp[0] = "True";
            exp[1] = "False";
            for (int i = 0; i < exp.Length; i++)
            {
                exp_ini.Items.Add(exp[i]);
            }

            store_ini.Text = mdlGlobal.Stored_Procedure;

            Get_Filestore();

            model_select.Text = mdlGlobal.ModelSelection;
            exp1[0] = "0";
            exp1[1] = "1";
            for (int i = 0; i < exp1.Length; i++)
            {
                model_select.Items.Add(exp1[i]);
            }
        }
    }
}
