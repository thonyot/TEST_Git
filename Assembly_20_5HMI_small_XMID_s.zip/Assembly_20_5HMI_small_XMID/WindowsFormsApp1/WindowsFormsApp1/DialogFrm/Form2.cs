﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class FrmScan : Form
    {
        StoreDataContext StoreConnect = new StoreDataContext(mdlGlobal.dbconnection);

        public FrmScan()
        {
            InitializeComponent();
        }

        private void txtxm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                //IT200QTTXD8E015500001
                if (txtxm.Text.Length == 21)
                {
                    mdlGlobal.xm_num = txtxm.Text.Substring(Math.Max(txtxm.Text.Length - 8, 0), Math.Min(8, txtxm.Text.Length));
                    mdlGlobal.sn_num = mdlGlobal.PCBsn.Substring(Math.Max(mdlGlobal.PCBsn.Length - 8, 0), Math.Min(8, mdlGlobal.PCBsn.Length));
                    if (mdlGlobal.xm_num == mdlGlobal.sn_num)
                    {
                        lblResult1.Visible = false;
                        lblResult1.BackColor = System.Drawing.Color.Transparent;
                        lblResult1.Text = "";
                        txtsxm.Text = "";
                        txtsxm.Focus();
                    }
                    else
                    {
                        lblResult1.Visible = true;
                        lblResult1.BackColor = System.Drawing.Color.Red;
                        lblResult1.Text = "Not correct XM ID With Serial No.";
                        txtxm.Text = "";
                        txtxm.Focus();
                        return;
                    }
                }
                else
                {
                    lblResult1.Visible = true;
                    lblResult1.BackColor = System.Drawing.Color.Red;
                    lblResult1.Text = " XM ID out of length scan";
                    txtxm.Text = "";
                    txtxm.Focus();
                    return;

                }

            }
        }

        private void txtsxm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                //0QTTXD8E
                if (txtsxm.Text.Length == 8)
                {
                    mdlGlobal.sxm_num = txtxm.Text.Substring(4, 8);                    
                    if (mdlGlobal.sxm_num == txtsxm.Text)
                    {
                        lblResult1.Visible = false;
                        lblResult1.BackColor = System.Drawing.Color.Transparent;
                        lblResult1.Text = "";
                        txthwid.Text = "";
                        txthwid.Focus();
                    }
                    else
                    {
                        lblResult1.Visible = true;
                        lblResult1.BackColor = System.Drawing.Color.Red;
                        lblResult1.Text = "Not correct SXM ID With XM ID";
                        txtsxm.Text = "";
                        txtsxm.Focus();
                        return;
                    }
                }
                else
                {
                    lblResult1.Visible = true;
                    lblResult1.BackColor = System.Drawing.Color.Red;
                    lblResult1.Text = " SXM out of length scan";
                    txtsxm.Text = "";
                    txtsxm.Focus();
                    return;

                }

            }

        }

        private void txthwid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                //0QTTXD8E
                if (txthwid.Text.Length > 45)
                {
                    mdlGlobal.hw_num = txthwid.Text.Substring(29, 8);
                    if (mdlGlobal.hw_num == txtsxm.Text)
                    {
                        lblResult1.Visible = false;
                        lblResult1.BackColor = System.Drawing.Color.Transparent;
                        lblResult1.Text = "";
                        mdlGlobal.XM_ID = txthwid.Text.Substring(0, 49);
                       txthwid.Text = "";                       
                        Close();
                    }
                    else
                    {
                        lblResult1.Visible = true;
                        lblResult1.BackColor = System.Drawing.Color.Red;
                        lblResult1.Text = "Not correct HWID Code With Mainseal";
                        txthwid.Text = "";
                        txthwid.Focus();
                        return;
                    }
                }
                else
                {
                    lblResult1.Visible = true;
                    lblResult1.BackColor = System.Drawing.Color.Red;
                    lblResult1.Text = " HWID Code out of length scan";
                    txthwid.Text = "";
                    txthwid.Focus();
                    return;

                }

            }

        }

        private void FrmScan_Load(object sender, EventArgs e)
        {

        }
    }
 }
