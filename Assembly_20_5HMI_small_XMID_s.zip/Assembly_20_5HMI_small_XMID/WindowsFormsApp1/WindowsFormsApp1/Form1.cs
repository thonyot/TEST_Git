﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
//using MySql.Data.MySqlClient;  //Its for MySQL  
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Configuration;
using Microsoft.VisualBasic;
using System.Media;
using System.Net;
using System.Diagnostics;
using System.Data.Common;
//using Mono.Data.TdsClient;
using Mono.Data.Sqlite;
using Mono.Data.Tds;
using System.Reflection;
using System.Runtime.InteropServices;
using Mono.Posix;
using Mono.Unix;
using Mono.Remoting.Channels.Unix;
using Microsoft.Win32.SafeHandles;
using Mono.Data.Tds.Protocol;





namespace WindowsFormsApp1
{

    public partial class Form1 : Form
    {

        StoreDataContext StoreConnect = new StoreDataContext(mdlGlobal.dbconnection);

        public Form1()
        {
            InitializeComponent();
            TextBox txtBarcodeScan = new TextBox();
            this.Controls.Add(txtBarcodeScan);

            txtBarcodeScan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(txtBarcodeScan_KeyPress_1);

        }
        SqlConnection sqlconnection = new SqlConnection();
        SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");



        static string datetime1;
        static string EmpName;
        static string PCBsn;
        static string pcbContent;
        static string pcbModel;
        static int icok_new = 0;
        static string MsgNode;
        static string msgCommentFinal;
        static string nComment;
        //static DateTime DataNow_DB;
        private void Form1_Load_1(object sender, EventArgs e)
        {


            this.ActiveControl = txtOper;
            //get model
            MsgNode = "Scanned at Node: ";
            msgCommentFinal = "Passed Process verification";

            Get_start_datetime();

            cbModel.Items.Clear();

            txt_Plan_Qty.Text = "0";

            ////count Prod update
            count_update();

            group_scan_setup.Visible = false;

            mdlGlobal.node = "";
            mdlGlobal.server = "";
            mdlGlobal.username = "";
            mdlGlobal.password = "";
            mdlGlobal.test_type = "";
            mdlGlobal.ModelSelection = "";

            sca1.Visible = false;
            sca2.Visible = false;
            sca3.Visible = false;
            sca4.Visible = false;
            sca5.Visible = false;
            sca6.Visible = false;
            lblscan1.Visible = false;
            lblscan2.Visible = false;
            lblscan3.Visible = false;
            lblscan4.Visible = false;
            lblscan5.Visible = false;
            lblscan6.Visible = false;
            txtscan1.Visible = false;
            txtscan2.Visible = false;
            txtscan3.Visible = false;
            txtscan4.Visible = false;
            txtscan5.Visible = false;
            txtscan6.Visible = false;
            s1.Visible = false;
            s2.Visible = false;
            s3.Visible = false;
            s4.Visible = false;
            s5.Visible = false;
            s6.Visible = false;

            //##Skip by nee
            //SqlConnection sqlconnection = new SqlConnection();
            //sqlconnection = new SqlConnection();
            //sqlconnection.ConnectionString = "server=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;";

            ////getdate
            //DataSet myDataset_d = new DataSet();
            //SqlDataAdapter da_d = new SqlDataAdapter();
            ////string sqlServerDate = "SELECT CONVERT(VARCHAR(10),GETDATE(),110) as date";
            //string sqlServerDate = "SELECT GETDATE() as date";
            //da_d = new SqlDataAdapter(sqlServerDate, sqlconnection);
            //da_d.Fill(myDataset_d);
            //datetime1 = myDataset_d.Tables[0].Rows[0]["date"].ToString();
            //lblDate.Text = datetime1;
             
            //myDataset_d.Clear();

            //sqlconnection.Close();

            //##Add by nee
            lblDate.Text = DateTime.Now.ToShortDateString();

            Get_FileSetup();

        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
        void Get_FileSetup()
        {

            if (!File.Exists(mdlGlobal.path))
            {
                // Create the file.
                using (FileStream fs = File.Create(mdlGlobal.path))
                {
                    Byte[] info =
                        new UTF8Encoding(true).GetBytes("This is some text in the file.");

                    // Add some information to the file.
                    fs.Write(info, 0, info.Length);
                }
            }

            using (StreamReader sr = File.OpenText(mdlGlobal.path))
            {
                string s = "";
                var lines = "";
                while ((s = sr.ReadLine()) != null)
                {
                    lines = s;
                    string[] line = s.Split('=');
                    if (Convert.ToString(line[0].Trim()) == "Node")
                    {
                        mdlGlobal.node = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "Server")
                    {
                        mdlGlobal.server = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "Username")
                    {
                        mdlGlobal.username = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "Password")
                    {
                        mdlGlobal.password = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "Test_Type")
                    {
                        mdlGlobal.test_type = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "ModelSelection")
                    {
                        mdlGlobal.ModelSelection = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "Execute_SP")
                    {
                        mdlGlobal.Execute_SP = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "Stored_Procedure")
                    {
                        mdlGlobal.Stored_Procedure = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "SP1")
                    {
                        mdlGlobal.SP1 = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "SP2")
                    {
                        mdlGlobal.SP2 = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "SP3")
                    {
                        mdlGlobal.SP3 = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "SP4")
                    {
                        mdlGlobal.SP4 = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "SP5")
                    {
                        mdlGlobal.SP5 = Convert.ToString(line[1]).Trim();
                    }
                    else if (Convert.ToString(line[0].Trim()) == "SP6")
                    {
                        mdlGlobal.SP6 = Convert.ToString(line[1]).Trim();
                    }


                    lblNode.Text = mdlGlobal.node;
                    lblServer.Text = mdlGlobal.server;
                    lblScanType.Text = mdlGlobal.test_type;
                    lblVer.Text = "Ras-pi3:H0_Rev1";



                    //var timer = new Timer();
                    //timer.Interval = 1000;
                    //timer.Tick += new EventHandler(timer2_Tick);
                    //timer.Start();
                }
                System.Console.WriteLine();
                Get_model();
            }
        }


        void Get_model()
        {
            if (mdlGlobal.ModelSelection == "1")
            {
                //string l = "";
                string line_no = "";
                string[] liness = mdlGlobal.node.Split('-');
                line_no = Convert.ToString(liness[0]).Trim();
                string conStr = @"Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;";
                SqlConnection conn = new SqlConnection(conStr);
                DataSet ds = new DataSet();
                string getEmpSQL = "select description from models where line in('" + line_no + "')";

                SqlDataAdapter sda = new SqlDataAdapter(getEmpSQL, conn);

                try
                {
                    conn.Open();
                    sda.Fill(ds);

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        cbModel.Items.Add(ds.Tables[0].Rows[i][0]);

                    }
                }
                catch (SqlException se)
                {
                    MessageBox.Show("An error occured while connecting to database" + se.ToString());
                }
                finally
                {
                    conn.Close();
                }

                lblModel.Visible = false;
            }
            else if (mdlGlobal.ModelSelection == "0")
            {
                string conStr = @"Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;";
                SqlConnection conn = new SqlConnection(conStr);
                DataSet ds = new DataSet();
                string getEmpSQL = "select description from models where line <> '' ";

                SqlDataAdapter sda = new SqlDataAdapter(getEmpSQL, conn);

                try
                {
                    conn.Open();
                    sda.Fill(ds);

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        cbModel.Items.Add(ds.Tables[0].Rows[i][0]);

                    }
                }
                catch (SqlException se)
                {
                    MessageBox.Show("An error occured while connecting to database" + se.ToString());
                }
                finally
                {
                    conn.Close();
                }

                lblModel.Visible = false;
            }
        }



        void Get_DateNow()
        {
            try
            {
                mdlGlobal.NowDB = default(DateTime);
                SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                SqlCommand cmd1 = new SqlCommand("Select GetDate() as Date_Now", con1);
                con1.Open();
                SqlDataReader rd1 = cmd1.ExecuteReader();
                while (rd1.Read())
                {
                    mdlGlobal.NowDB = rd1.GetDateTime(0);
                }
                rd1.Close();
                con1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void Btn_Reset1_Click(object sender, EventArgs e)
        {
            mdlGlobal.DataNow_DB = default(DateTime);
            TmStart.Text = "";
            mdlGlobal.Tm_Start = "";
            //dgShow.Rows.Clear();

            Get_DateNow();

            mdlGlobal.DataNow_DB = mdlGlobal.NowDB;
            //Tm_Start = String.Format("{0:d}" + " " + "{0:T}", DataNow_DB);
            //Tm_Start = String.Format("{0:G}", DataNow_DB);
            TmStart.Text = mdlGlobal.DataNow_DB.ToString("MM/dd/yyyy h:mm:ss tt");
            mdlGlobal.Tm_Start = TmStart.Text;
            count_start_datetime(mdlGlobal.Tm_Start);

            Product_OK_Count.Text = "0";         //GetOksQty()
            Product_OK_Count.Refresh();

            Product_NG_Count.Text = "0";         //GetNgsQty()
            Product_NG_Count.Refresh();
            txtBarcodeScan.Focus();
        }

        void count_start_datetime(string Tm)
        {
            try
            {
                File.WriteAllText(mdlGlobal.pathD, TmStart.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void count_update()
        {
            Product_OK_Count.Text = GetOksQty();
            Product_OK_Count.Refresh();

            Product_NG_Count.Text = GetNgsQty();
            Product_NG_Count.Refresh();
        }

        public String GetOksQty()
        {
            mdlGlobal.n = "";
            mdlGlobal.n = GetOKQTY(TmStart.Text);
            String GetOksQty = mdlGlobal.n;
            return GetOksQty;
        }

        public String GetNgsQty()
        {
            mdlGlobal.m = "";
            mdlGlobal.m = GetNGQTY(TmStart.Text);
            String GetNgsQty = mdlGlobal.m;
            return GetNgsQty;
        }

        public String GetOKQTY(String TmStart)
        {
            //Count OK Condition datetime > TmStart
            try
            {
                SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                SqlCommand command2 = new SqlCommand("SELECT distinct serial_num FROM serial_numbers WITH(NOLOCK) where node_name='" + lblNode.Text + "' and test_type in ('" + mdlGlobal.test_type + "') and pass_fail='True' and date_time > '" + TmStart + "'", con2);
                con2.Open();
                SqlDataReader read2 = command2.ExecuteReader();
                mdlGlobal.SerialOK = "";
                mdlGlobal.dcnt = 0;
                while (read2.Read())
                {
                    mdlGlobal.SerialOK = (read2["serial_num"].ToString());
                    mdlGlobal.dcnt = mdlGlobal.dcnt + 1;
                }
                read2.Close();
                con2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //int GetOKQTY = dcnt;
            return mdlGlobal.dcnt.ToString();
        }

        public String GetNGQTY(String TmStart)
        {
            //Count NG Condition datetime > TmStart
            try
            {
                SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                SqlCommand command3 = new SqlCommand("SELECT distinct serial_num FROM serial_numbers WITH(NOLOCK) where node_name='" + lblNode.Text + "' and test_type in ('" + mdlGlobal.test_type + "') and pass_fail='False' and date_time > '" + TmStart + "'", con3);
                con3.Open();
                SqlDataReader read3 = command3.ExecuteReader();
                mdlGlobal.SerialNG = "";
                mdlGlobal.dcnt1 = 0;
                while (read3.Read())
                {
                    mdlGlobal.SerialNG = (read3["serial_num"].ToString());
                    mdlGlobal.dcnt1 = mdlGlobal.dcnt1 + 1;
                }
                read3.Close();
                con3.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //int GetNGQTY = dcnt;
            return mdlGlobal.dcnt1.ToString();
        }

        //##Skip by nee
        //private void timer2_Tick(object sender, EventArgs e)
        //{
            ///Get DateNow in DB            
            //Get_DateNow();
            //mdlGlobal.datetime2 = mdlGlobal.NowDB.ToString();
            //lblDate.Text = mdlGlobal.datetime2;

            ///TimerErr.Start();
        //}

        private void txtOper_DoubleClick(object sender, EventArgs e)
        {
            txtOper.ReadOnly = false;
            txtOper.SelectAll();
            txtOper.Focus();
        }
        private void txtOper_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                EmpName = "";
                string operatorID = txtOper.Text;
                OperatorName(operatorID); //call a method that you have created.
                if (EmpName != "")
                {
                    lblOper.Text = EmpName;
                    //lblOper.Visible = true;

                    txtOper.ReadOnly = true;
                    //MessageBox.Show("ผ่าน.");
                    //cbModel.Focus();
                    txtBarcodeScan.Text = "";
                    txtBarcodeScan.Focus();
                }
                else
                {
                    MessageBox.Show("not find operator name!.");
                    txtOper.SelectAll();
                    txtOper.Focus();
                }
            }
        }

        private void OperatorName(string txtOpt)
        {
            using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
            {
                SqlCommand command =
                new SqlCommand("Select Emp_Name from operators WITH(NOLOCK) where Emp_ID = '" + txtOpt + "'", connection);
                connection.Open();

                SqlDataReader read = command.ExecuteReader();

                EmpName = "";
                while (read.Read())
                {
                    EmpName = (read["Emp_Name"].ToString());
                }
                read.Close();
            }
        }

        private void cbModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbModel.SelectedIndex > -1)
            {
                //Clear_JIG();
                lblModel.Visible = true;
                lblModel.Text = cbModel.Text;
                txtOper.Text = "";
                txtOper.Visible = true;
                txtOper.ReadOnly = false;
                txtOper.SelectAll();
                txtOper.Focus();
                lblOper.Text = "";

                //txtBarcodeScan.Focus();
                //txtBarcodeScan.Text = "";
            }

            try
            {
                SqlConnection con2n = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                //"select description from models where line in('99')";
                SqlCommand command2n = new SqlCommand("SELECT model FROM models WITH(NOLOCK) where description='" + lblModel.Text + "'", con2n);
                con2n.Open();
                SqlDataReader read2n = command2n.ExecuteReader();
                //mdlGlobal.SerialOK = "";
                //mdlGlobal.dcnt = 0;
                while (read2n.Read())
                {
                    mdlGlobal.CurrentModel = (read2n["model"].ToString());
                    //mdlGlobal.dcnt = mdlGlobal.dcnt + 1;
                }
                read2n.Close();
                con2n.Close();

                //read Text Scan_setup
                string[] lines = System.IO.File.ReadAllLines(mdlGlobal.path_scan);

                // Display the file contents by using a foreach loop.
                System.Console.WriteLine("Contents of ScanSetup.txt = ");
                foreach (string line in lines)
                {
                    if (lines.Count() == 6)
                    {
                        string[] sta1 = Convert.ToString(lines[0]).Trim().Split(',');
                        mdlGlobal.scan_setup1 = Convert.ToString(sta1[1]).Trim();
                        string[] sta2 = Convert.ToString(lines[1]).Trim().Split(',');
                        mdlGlobal.scan_setup2 = Convert.ToString(sta2[1]).Trim();
                        string[] sta3 = Convert.ToString(lines[2]).Trim().Split(',');
                        mdlGlobal.scan_setup3 = Convert.ToString(sta3[1]).Trim();
                        string[] sta4 = Convert.ToString(lines[3]).Trim().Split(',');
                        mdlGlobal.scan_setup4 = Convert.ToString(sta4[1]).Trim();
                        string[] sta5 = Convert.ToString(lines[4]).Trim().Split(',');
                        mdlGlobal.scan_setup5 = Convert.ToString(sta5[1]).Trim();
                        string[] sta6 = Convert.ToString(lines[5]).Trim().Split(',');
                        mdlGlobal.scan_setup6 = Convert.ToString(sta6[1]).Trim();

                        if (mdlGlobal.scan_setup1 == "Select" && mdlGlobal.scan_setup2 == "Select" && mdlGlobal.scan_setup3 == "Select" && mdlGlobal.scan_setup4 == "Select" && mdlGlobal.scan_setup5 == "Select" && mdlGlobal.scan_setup6 == "Select")
                        {
                            //MessageBox.Show("Check the Scansetup all 99,select");
                            //cbModel.Text = "";
                            //cbModel.Focus();
                            //lblOper.Text = "";
                            lblscan1.Visible = false;
                            lblscan2.Visible = false;
                            lblscan3.Visible = false;
                            lblscan4.Visible = false;
                            lblscan5.Visible = false;
                            lblscan6.Visible = false;
                            txtscan1.Visible = false;
                            txtscan2.Visible = false;
                            txtscan3.Visible = false;
                            txtscan4.Visible = false;
                            txtscan5.Visible = false;
                            txtscan6.Visible = false;
                            s1.Visible = false;
                            s2.Visible = false;
                            s3.Visible = false;
                            s4.Visible = false;
                            s5.Visible = false;
                            s6.Visible = false;
                            sca1.Visible = false;
                            sca2.Visible = false;
                            sca3.Visible = false;
                            sca4.Visible = false;
                            sca5.Visible = false;
                            sca6.Visible = false;
                            //lblscan1.Text = mdlGlobal.scan_setup1;
                            //s1.Text = mdlGlobal.scan_setup1;
                            txtOper.Text = "";
                            txtOper.Focus();
                            lblOper.Text = "";
                            return;
                        }

                        if (mdlGlobal.scan_setup1 != "Select" && mdlGlobal.scan_setup2 == "Select" && mdlGlobal.scan_setup3 == "Select" && mdlGlobal.scan_setup4 == "Select" && mdlGlobal.scan_setup5 == "Select" && mdlGlobal.scan_setup6 == "Select")
                        {
                            lblscan1.Visible = true;
                            lblscan2.Visible = false;
                            lblscan3.Visible = false;
                            lblscan4.Visible = false;
                            lblscan5.Visible = false;
                            lblscan6.Visible = false;
                            txtscan1.Visible = true;
                            txtscan2.Visible = false;
                            txtscan3.Visible = false;
                            txtscan4.Visible = false;
                            txtscan5.Visible = false;
                            txtscan6.Visible = false;
                            s1.Visible = true;
                            s2.Visible = false;
                            s3.Visible = false;
                            s4.Visible = false;
                            s5.Visible = false;
                            s6.Visible = false;
                            sca1.Visible = true;
                            sca2.Visible = false;
                            sca3.Visible = false;
                            sca4.Visible = false;
                            sca5.Visible = false;
                            sca6.Visible = false;
                            lblscan1.Text = mdlGlobal.scan_setup1;
                            s1.Text = mdlGlobal.scan_setup1;
                            txtOper.Text = "";
                            txtOper.Focus();
                            lblOper.Text = "";
                        }

                        if (mdlGlobal.scan_setup1 != "Select" && mdlGlobal.scan_setup2 != "Select" && mdlGlobal.scan_setup3 == "Select" && mdlGlobal.scan_setup4 == "Select" && mdlGlobal.scan_setup5 == "Select" && mdlGlobal.scan_setup6 == "Select")
                        {
                            lblscan1.Visible = true;
                            lblscan2.Visible = true;
                            lblscan3.Visible = false;
                            lblscan4.Visible = false;
                            lblscan5.Visible = false;
                            lblscan6.Visible = false;
                            txtscan1.Visible = true;
                            txtscan2.Visible = true;
                            txtscan3.Visible = false;
                            txtscan4.Visible = false;
                            txtscan5.Visible = false;
                            txtscan6.Visible = false;
                            s1.Visible = true;
                            s2.Visible = true;
                            s3.Visible = false;
                            s4.Visible = false;
                            s5.Visible = false;
                            s6.Visible = false;
                            sca1.Visible = true;
                            sca2.Visible = true;
                            sca3.Visible = false;
                            sca4.Visible = false;
                            sca5.Visible = false;
                            sca6.Visible = false;
                            lblscan1.Text = mdlGlobal.scan_setup1;
                            lblscan2.Text = mdlGlobal.scan_setup2;
                            s1.Text = mdlGlobal.scan_setup1;
                            s2.Text = mdlGlobal.scan_setup2;
                            txtOper.Text = "";
                            txtOper.Focus();
                            lblOper.Text = "";
                        }

                        if (mdlGlobal.scan_setup1 != "Select" && mdlGlobal.scan_setup2 != "Select" && mdlGlobal.scan_setup3 != "Select" && mdlGlobal.scan_setup4 == "Select" && mdlGlobal.scan_setup5 == "Select" && mdlGlobal.scan_setup6 == "Select")
                        {
                            lblscan1.Visible = true;
                            lblscan2.Visible = true;
                            lblscan3.Visible = true;
                            lblscan4.Visible = false;
                            lblscan5.Visible = false;
                            lblscan6.Visible = false;
                            txtscan1.Visible = true;
                            txtscan2.Visible = true;
                            txtscan3.Visible = true;
                            txtscan4.Visible = false;
                            txtscan5.Visible = false;
                            txtscan6.Visible = false;
                            s1.Visible = true;
                            s2.Visible = true;
                            s3.Visible = true;
                            s4.Visible = false;
                            s5.Visible = false;
                            s6.Visible = false;
                            sca1.Visible = true;
                            sca2.Visible = true;
                            sca3.Visible = true;
                            sca4.Visible = false;
                            sca5.Visible = false;
                            sca6.Visible = false;
                            lblscan1.Text = mdlGlobal.scan_setup1;
                            lblscan2.Text = mdlGlobal.scan_setup2;
                            lblscan3.Text = mdlGlobal.scan_setup3;
                            s1.Text = mdlGlobal.scan_setup1;
                            s2.Text = mdlGlobal.scan_setup2;
                            s3.Text = mdlGlobal.scan_setup3;
                            txtOper.Text = "";
                            txtOper.Focus();
                            lblOper.Text = "";
                        }

                        if (mdlGlobal.scan_setup1 != "Select" && mdlGlobal.scan_setup2 != "Select" && mdlGlobal.scan_setup3 != "Select" && mdlGlobal.scan_setup4 != "Select" && mdlGlobal.scan_setup5 == "Select" && mdlGlobal.scan_setup6 == "Select")
                        {
                            lblscan1.Visible = true;
                            lblscan2.Visible = true;
                            lblscan3.Visible = true;
                            lblscan4.Visible = true;
                            lblscan5.Visible = false;
                            lblscan6.Visible = false;
                            txtscan1.Visible = true;
                            txtscan2.Visible = true;
                            txtscan3.Visible = true;
                            txtscan4.Visible = true;
                            txtscan5.Visible = false;
                            txtscan6.Visible = false;
                            s1.Visible = true;
                            s2.Visible = true;
                            s3.Visible = true;
                            s4.Visible = true;
                            s5.Visible = false;
                            s6.Visible = false;
                            sca1.Visible = true;
                            sca2.Visible = true;
                            sca3.Visible = true;
                            sca4.Visible = true;
                            sca5.Visible = false;
                            sca6.Visible = false;
                            lblscan1.Text = mdlGlobal.scan_setup1;
                            lblscan2.Text = mdlGlobal.scan_setup2;
                            lblscan3.Text = mdlGlobal.scan_setup3;
                            lblscan4.Text = mdlGlobal.scan_setup4;
                            s1.Text = mdlGlobal.scan_setup1;
                            s2.Text = mdlGlobal.scan_setup2;
                            s3.Text = mdlGlobal.scan_setup3;
                            s4.Text = mdlGlobal.scan_setup4;
                            txtOper.Text = "";
                            txtOper.Focus();
                            lblOper.Text = "";
                        }

                        if (mdlGlobal.scan_setup1 != "Select" && mdlGlobal.scan_setup2 != "Select" && mdlGlobal.scan_setup3 != "Select" && mdlGlobal.scan_setup4 != "Select" && mdlGlobal.scan_setup5 != "Select" && mdlGlobal.scan_setup6 == "Select")
                        {
                            lblscan1.Visible = true;
                            lblscan2.Visible = true;
                            lblscan3.Visible = true;
                            lblscan4.Visible = true;
                            lblscan5.Visible = true;
                            lblscan6.Visible = false;
                            txtscan1.Visible = true;
                            txtscan2.Visible = true;
                            txtscan3.Visible = true;
                            txtscan4.Visible = true;
                            txtscan5.Visible = true;
                            txtscan6.Visible = false;
                            s1.Visible = true;
                            s2.Visible = true;
                            s3.Visible = true;
                            s4.Visible = true;
                            s5.Visible = true;
                            s6.Visible = false;
                            sca1.Visible = true;
                            sca2.Visible = true;
                            sca3.Visible = true;
                            sca4.Visible = true;
                            sca5.Visible = true;
                            sca6.Visible = false;
                            lblscan1.Text = mdlGlobal.scan_setup1;
                            lblscan2.Text = mdlGlobal.scan_setup2;
                            lblscan3.Text = mdlGlobal.scan_setup3;
                            lblscan4.Text = mdlGlobal.scan_setup4;
                            lblscan5.Text = mdlGlobal.scan_setup5;
                            s1.Text = mdlGlobal.scan_setup1;
                            s2.Text = mdlGlobal.scan_setup2;
                            s3.Text = mdlGlobal.scan_setup3;
                            s4.Text = mdlGlobal.scan_setup4;
                            s5.Text = mdlGlobal.scan_setup5;
                            txtOper.Text = "";
                            txtOper.Focus();
                            lblOper.Text = "";
                        }

                        if (mdlGlobal.scan_setup1 != "Select" && mdlGlobal.scan_setup2 != "Select" && mdlGlobal.scan_setup3 != "Select" && mdlGlobal.scan_setup4 != "Select" && mdlGlobal.scan_setup5 != "Select" && mdlGlobal.scan_setup6 != "Select")
                        {
                            lblscan1.Visible = true;
                            lblscan2.Visible = true;
                            lblscan3.Visible = true;
                            lblscan4.Visible = true;
                            lblscan5.Visible = true;
                            lblscan6.Visible = true;
                            txtscan1.Visible = true;
                            txtscan2.Visible = true;
                            txtscan3.Visible = true;
                            txtscan4.Visible = true;
                            txtscan5.Visible = true;
                            txtscan6.Visible = true;
                            s1.Visible = true;
                            s2.Visible = true;
                            s3.Visible = true;
                            s4.Visible = true;
                            s5.Visible = true;
                            s6.Visible = true;
                            sca1.Visible = true;
                            sca2.Visible = true;
                            sca3.Visible = true;
                            sca4.Visible = true;
                            sca5.Visible = true;
                            sca6.Visible = true;
                            lblscan1.Text = mdlGlobal.scan_setup1;
                            lblscan2.Text = mdlGlobal.scan_setup2;
                            lblscan3.Text = mdlGlobal.scan_setup3;
                            lblscan4.Text = mdlGlobal.scan_setup4;
                            lblscan5.Text = mdlGlobal.scan_setup5;
                            lblscan6.Text = mdlGlobal.scan_setup6;
                            s1.Text = mdlGlobal.scan_setup1;
                            s2.Text = mdlGlobal.scan_setup2;
                            s3.Text = mdlGlobal.scan_setup3;
                            s4.Text = mdlGlobal.scan_setup4;
                            s5.Text = mdlGlobal.scan_setup5;
                            s6.Text = mdlGlobal.scan_setup6;
                            txtOper.Text = "";
                            txtOper.Focus();
                            lblOper.Text = "";
                        }
                    }
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cbModel_MouseClick(object sender, MouseEventArgs e)
        {
            lblModel.Visible = true;
            lblModel.Text = cbModel.Text;

        }

        //private void txtBarcodeScan_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    //if (e.KeyCode == Keys.Enter)
        //    if (e.KeyChar == Convert.ToChar(Keys.Enter))
        //    {                

        //        if (cbModel.Text == "")
        //        {

        //            MessageBox.Show("Please Choose Model before!.");
        //            txtBarcodeScan.Text = "";
        //            cbModel.Text = "";
        //            cbModel.Focus();
        //            return;
        //        }
        //        else if (txtOper.Text == "" && lblOper.Text == "")
        //        {

        //            MessageBox.Show("Please Input Operator ID before!.");
        //            txtBarcodeScan.Text = "";
        //            cbModel.Text = "";
        //            txtOper.Text = "";
        //            txtOper.Focus();
        //            return;
        //        }

        //        if ((txtBarcodeScan.Text.Length <= 10) || (txtBarcodeScan.Text.Length > 20))
        //        {
        //            lblResult.Visible = true;
        //            lblResult.BackColor = System.Drawing.Color.Red;
        //            lblResult.Text = "Wrong BARCODE Format";
        //            txtResult.Text = "Worng!! Model BARCODE Format";
        //            txtBarcodeScan.Text = "";
        //            txtBarcodeScan.Focus();
        //            return;
        //        }
        //    }

        //    //if (e.KeyCode == Keys.Enter)
        //    if (e.KeyChar == Convert.ToChar(Keys.Enter))
        //    {
        //        //mdlGlobal.count_model = lblModel.Text.Length;
        //        //mdlGlobal.CurrentModel = txtBarcodeScan.Text.Substring(0, Math.Min(mdlGlobal.count_model, txtBarcodeScan.Text.Length));

        //        //timer2.Enabled = false;
        //        lblResult.Text = "";
        //        txtResult.Text = "";
        //        //PackingCode = "";
        //        //txt_result_message = "";

        //        //timer2.Enabled = true;


        //        using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
        //        {
        //            SqlCommand command =
        //            //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
        //            new SqlCommand("select model from models with (nolock) where description='" + lblModel.Text + "'", connection);
        //            connection.Open();
        //            //sqlconnection.Open();

        //            SqlDataReader read = command.ExecuteReader();

        //            mdlGlobal.CurrentModel = "";
        //            while (read.Read())
        //            {
        //                mdlGlobal.CurrentModel = (read["model"].ToString());
        //            }
        //            read.Close();

        //        }

        //        sqlconnection.Close();

        //        //Check Value NULL
        //        if (txt_Plan_Qty.Text == "")
        //        {
        //            txt_Plan_Qty.Text = "0";
        //        }
        //        //check Plan Qty =< Product Qty then message (if Plan Qty=0 then no message)                
        //        mdlGlobal.txtPlanQty = System.Convert.ToInt32(txt_Plan_Qty.Text);
        //        mdlGlobal.ProductOKCount = System.Convert.ToInt32(Product_OK_Count.Text);
        //        if (mdlGlobal.txtPlanQty == 0)
        //        {

        //        }
        //        else
        //        {
        //            if (mdlGlobal.txtPlanQty <= mdlGlobal.ProductOKCount)
        //            {
        //                mdlGlobal.ProdEndScreenMsg = "Over Production Qty check Target";
        //                txtResult.Text = mdlGlobal.ProdEndScreenMsg;
        //                //grpStatus.BackColor = System.Drawing.Color.Red;
        //                txtBarcodeScan.Text = "";
        //                /*---Show Over Production Qty---*/
        //                ProdQtyEndMessage(mdlGlobal.ProdEndScreenMsg);
        //                return;
        //            }
        //        }

        //        //pcbModel = pcbContent;
        //        mdlGlobal.PCBsn = txtBarcodeScan.Text.Trim();
        //        mdlGlobal.count_model = mdlGlobal.CurrentModel.Length;
        //        mdlGlobal.model_check = txtBarcodeScan.Text.Substring(0, Math.Min(mdlGlobal.count_model, txtBarcodeScan.Text.Length));
        //        if (mdlGlobal.model_check == mdlGlobal.CurrentModel)
        //        {
        //            if (mdlGlobal.Execute_SP == "True")
        //            {
        //                SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

        //                con.Open();

        //                //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
        //                SqlCommand comm = new SqlCommand(mdlGlobal.Stored_Procedure, con);

        //                comm.CommandType = CommandType.StoredProcedure;

        //                comm.Parameters.Add(new SqlParameter("@serial_number", txtBarcodeScan.Text.Trim()));
        //                comm.Parameters.Add(new SqlParameter("@node_name", mdlGlobal.node));
        //                comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.test_type));

        //                if (mdlGlobal.Stored_Procedure != "usp_dummy")
        //                {
        //                    string ret = comm.ExecuteScalar().ToString();
        //                    mdlGlobal.return_flag = ret;
        //                    string chk_flag = mdlGlobal.return_flag.Substring(0, 1);
        //                    if (chk_flag != "0") //if (mdlGlobal.return_flag.Substring(0,1) != "0")
        //                    {
        //                        lblResult.Visible = true;
        //                        lblResult.BackColor = System.Drawing.Color.Red;
        //                        lblResult.Text = mdlGlobal.return_flag; //"Worng Process";
        //                        txtResult.Text = mdlGlobal.return_flag;
        //                        txtBarcodeScan.Text = "";
        //                        txtBarcodeScan.Focus();
        //                        con.Close();
        //                        return;
        //                    }
        //                }
        //                else
        //                    con.Close();
        //                if (txtscan1.Visible == false && txtscan2.Visible == false && txtscan3.Visible == false && txtscan4.Visible == false && txtscan5.Visible == false && txtscan6.Visible == false)
        //                {
        //                    s1.Text = "";
        //                    s2.Text = "";
        //                    s3.Text = "";
        //                    s4.Text = "";
        //                    s5.Text = "";
        //                    s6.Text = "";

        //                    nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
        //                    //insert serial_numbers
        //                    SqlConnection conA1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
        //                    SqlCommand cmdA1 = new SqlCommand("sp_commentadd2_pi3", conA1);
        //                    cmdA1.CommandType = CommandType.StoredProcedure;
        //                    cmdA1.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
        //                    cmdA1.Parameters.AddWithValue("@comment", nComment);
        //                    cmdA1.Parameters.AddWithValue("@pass_fail", "1");
        //                    cmdA1.Parameters.AddWithValue("@node_name", lblNode.Text);


        //                    cmdA1.Parameters.AddWithValue("@test_type", lblScanType.Text);
        //                    cmdA1.Parameters.AddWithValue("@operator", lblOper.Text);
        //                    conA1.Open();
        //                    cmdA1.ExecuteNonQuery();

        //                    lblResult.BackColor = System.Drawing.Color.Green;
        //                    lblResult.ForeColor = Color.MintCream;
        //                    lblResult.Visible = true;
        //                    txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
        //                    passMsg("PASS UNIT SCAN");
        //                    txtBarcodeScan.Text = "";
        //                    txtBarcodeScan.Focus();

        //                    conA1.Close();
        //                    return;
        //                }
        //                //joe                    

        //                if (txtscan1.Visible != false && txtscan2.Visible == false && txtscan3.Visible == false && txtscan4.Visible == false && txtscan5.Visible == false && txtscan6.Visible == false)
        //                {
        //                    lblResult.Visible = false;
        //                    txtResult.Text = "";
        //                    txtscan1.Text = "";
        //                    txtscan1.Focus();

        //                }
        //                if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible == false && txtscan4.Visible == false && txtscan5.Visible == false && txtscan6.Visible == false)
        //                {
        //                    lblResult.Visible = false;
        //                    txtResult.Text = "";
        //                    txtscan1.Text = "";
        //                    txtscan2.Text = "";
        //                    txtscan1.Focus();
        //                }
        //                if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible != false && txtscan4.Visible == false && txtscan5.Visible == false && txtscan6.Visible == false)
        //                {
        //                    lblResult.Visible = false;
        //                    txtResult.Text = "";
        //                    txtscan1.Text = "";
        //                    txtscan2.Text = "";
        //                    txtscan3.Text = "";
        //                    txtscan1.Focus();                           
        //                }
        //                if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible != false && txtscan4.Visible != false && txtscan5.Visible == false && txtscan6.Visible == false)
        //                {
        //                    lblResult.Visible = false;
        //                    txtResult.Text = "";
        //                    txtscan1.Text = "";
        //                    txtscan2.Text = "";
        //                    txtscan3.Text = "";
        //                    txtscan4.Text = "";
        //                    txtscan1.Focus();                                               
        //                }
        //                if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible != false && txtscan4.Visible != false && txtscan5.Visible != false && txtscan6.Visible == false)
        //                {
        //                    lblResult.Visible = false;
        //                    txtResult.Text = "";
        //                    txtscan1.Text = "";
        //                    txtscan2.Text = "";
        //                    txtscan3.Text = "";
        //                    txtscan4.Text = "";
        //                    txtscan5.Text = "";
        //                    txtscan1.Focus();                         
        //                }
        //                if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible != false && txtscan4.Visible != false && txtscan5.Visible != false && txtscan6.Visible != false)
        //                {
        //                    lblResult.Visible = false;
        //                    txtResult.Text = "";
        //                    txtscan1.Text = "";
        //                    txtscan2.Text = "";
        //                    txtscan3.Text = "";
        //                    txtscan4.Text = "";
        //                    txtscan5.Text = "";
        //                    txtscan6.Text = "";
        //                    txtscan1.Focus();
        //                }
        //            }

        //        }

        //        else
        //        {
        //            lblResult.Visible = true;
        //            lblResult.BackColor = System.Drawing.Color.Red;
        //            lblResult.Text = "Worng Model";
        //            txtResult.Text = "Worng!! model Bacode not correct";
        //            txtBarcodeScan.Text = "";
        //            txtBarcodeScan.Focus();
        //            return;
        //        }
                
        //    }
        //}

        void ProdQtyEndMessage(string Msg)
        {
            WindowsFormsApp1.ProdEndScreen frmEnd = new WindowsFormsApp1.ProdEndScreen();

            frmEnd.Label1.Text = Msg;

            txtBarcodeScan.Text = "";
            frmEnd.ShowDialog();
        }
        public void alertMsg(String errMsg)
        {
            //TimerErr.Enabled = false;
            //TimerErr.Enabled = true;
            //gbBox.BackColor = Color.Red;
            lblResult.ForeColor = Color.MintCream;
            lblResult.Visible = true;
            lblResult.Text = errMsg;
            //PlaySound("SOUND108.wav");
        }

        public void passMsg(String msg)
        {
            //TimerErr.Enabled = false;
            //TimerErr.Enabled = true;
            //gbBox.BackColor = Color.Green;
            lblResult.BackColor = System.Drawing.Color.Green;
            lblResult.ForeColor = Color.MintCream;
            lblResult.Visible = true;
            lblResult.Text = msg + "    " + txtBarcodeScan.Text;
            //PlaySound1("chimes.wav");
        }

            public void Get_start_datetime()
        {
            try
            {
                TmStart.Text = "";
                if (!File.Exists(mdlGlobal.pathD))
                {
                    //Create text File
                    File.Create(mdlGlobal.pathD);

                    // Insert Datetime for Database.
                    Get_DateNow();
                    File.SetLastWriteTime(mdlGlobal.pathD, mdlGlobal.NowDB);
                    //File.SetLastWriteTime(pathD, DateTime.Now);
                    DateTime dt = File.GetLastWriteTime(mdlGlobal.pathD);
                    TmStart.Text = dt.ToString("MM/dd/yyyy h:mm:ss tt");
                    File.WriteAllText(mdlGlobal.pathD, TmStart.Text);
                }
                else
                {
                    //Read text file 
                    TmStart.Text = File.ReadAllText(mdlGlobal.pathD);
                    //Check Value if null insert datetime for database
                    if (TmStart.Text == "")
                    {
                        // Insert Datetime for Database.
                        Get_DateNow();
                        mdlGlobal.DataNow_DB = mdlGlobal.NowDB;
                        File.SetLastWriteTime(mdlGlobal.pathD, mdlGlobal.DataNow_DB);
                        //File.SetLastWriteTime(pathD, DateTime.Now);
                        DateTime dt = File.GetLastWriteTime(mdlGlobal.pathD);
                        TmStart.Text = dt.ToString("MM/dd/yyyy h:mm:ss tt");
                        File.WriteAllText(mdlGlobal.pathD, TmStart.Text);
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
            }
        }

        private void SetupToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void scanSetupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            group_scan_setup.Visible = true;
            sp1.Items.Clear();
            sp2.Items.Clear();
            sp3.Items.Clear();
            sp4.Items.Clear();
            sp5.Items.Clear();
            sp6.Items.Clear();
            sp1.Text = "";
            sp2.Text = "";
            sp3.Text = "";
            sp4.Text = "";
            sp5.Text = "";
            sp6.Text = "";

            string conStr3 = @"Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;";
            SqlConnection conn3 = new SqlConnection(conStr3);
            DataSet ds3 = new DataSet();
            string getEmpSQL3 = "SELECT PCBNumber,content,Type,comment FROM DeckBarcodeValidation where model ='" + mdlGlobal.CurrentModel + "'";

            SqlDataAdapter sda3 = new SqlDataAdapter(getEmpSQL3, conn3);

            try
            {
                conn3.Open();
                sda3.Fill(ds3);

                for (int i = 0; i < ds3.Tables[0].Rows.Count; i++)
                {
                    sp1.Items.Add((ds3.Tables[0].Rows[i][0]) + "," + (ds3.Tables[0].Rows[i][1]) + "," + (ds3.Tables[0].Rows[i][2]) + "," + (ds3.Tables[0].Rows[i][3]));
                    sp2.Items.Add((ds3.Tables[0].Rows[i][0]) + "," + (ds3.Tables[0].Rows[i][1]) + "," + (ds3.Tables[0].Rows[i][2]) + "," + (ds3.Tables[0].Rows[i][3]));
                    sp3.Items.Add((ds3.Tables[0].Rows[i][0]) + "," + (ds3.Tables[0].Rows[i][1]) + "," + (ds3.Tables[0].Rows[i][2]) + "," + (ds3.Tables[0].Rows[i][3]));
                    sp4.Items.Add((ds3.Tables[0].Rows[i][0]) + "," + (ds3.Tables[0].Rows[i][1]) + "," + (ds3.Tables[0].Rows[i][2]) + "," + (ds3.Tables[0].Rows[i][3]));
                    sp5.Items.Add((ds3.Tables[0].Rows[i][0]) + "," + (ds3.Tables[0].Rows[i][1]) + "," + (ds3.Tables[0].Rows[i][2]) + "," + (ds3.Tables[0].Rows[i][3]));
                    sp6.Items.Add((ds3.Tables[0].Rows[i][0]) + "," + (ds3.Tables[0].Rows[i][1]) + "," + (ds3.Tables[0].Rows[i][2]) + "," + (ds3.Tables[0].Rows[i][3]));
                }
            }
            catch (SqlException se)
            {
                MessageBox.Show("An error occured while connecting to database" + se.ToString());
            }
            finally
            {
                conn3.Close();
            }

        }

        private void save1_Click(object sender, EventArgs e)
        {
            if (sp1.Text == "" && sp2.Text == "" && sp3.Text == "" && sp4.Text == "" && sp5.Text == "" && sp6.Text == "")
            {
                
                string[] lines = { "Scan1 = 99,Select", "Scan2 = 99,Select", "Scan3 = 99,Select", "Scan4 = 99,Select", "Scan5 = 99,Select", "Scan6 = 99,Select" };

                using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scan))              
                {

                    foreach (string line in lines)
                        outputFile.WriteLine(line);
                }
                MessageBox.Show("Complete of Save");
                lblscan1.Visible = false;
                lblscan2.Visible = false;
                lblscan3.Visible = false;
                lblscan4.Visible = false;
                lblscan5.Visible = false;
                lblscan6.Visible = false;
                txtscan1.Visible = false;
                txtscan2.Visible = false;
                txtscan3.Visible = false;
                txtscan4.Visible = false;
                txtscan5.Visible = false;
                txtscan6.Visible = false;
                s1.Visible = false;
                s2.Visible = false;
                s3.Visible = false;
                s4.Visible = false;
                s5.Visible = false;
                s6.Visible = false;
                sca1.Visible = false;
                sca2.Visible = false;
                sca3.Visible = false;
                sca4.Visible = false;
                sca5.Visible = false;
                sca6.Visible = false;
                
                txtBarcodeScan.Text = "";
                txtBarcodeScan.Focus();
                group_scan_setup.Visible = false;
                return;
            }

            if (sp1.Text != "" && sp2.Text == "" && sp3.Text == "" && sp4.Text == "" && sp5.Text == "" && sp6.Text == "")
            {
                string[] str = sp1.Text.Split(',');
                mdlGlobal.scan_setup1 = Convert.ToString(str[2]).Trim() + "," + Convert.ToString(str[3]).Trim();
                //clear text              
                StreamWriter strm = File.CreateText(mdlGlobal.path_scan);
                //StreamWriter strm = File.CreateText(mdlGlobal.path_scanD);
                strm.Flush();
                strm.Close();

                // Create a string array with the additional lines of text
                string[] lines = { "Scan1 = " + mdlGlobal.scan_setup1, "Scan2 = 99,Select", "Scan3 = 99,Select", "Scan4 = 99,Select", "Scan5 = 99,Select", "Scan6 = 99,Select" };

                using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scan))
                //using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scanD))
                {

                    foreach (string line in lines)
                        outputFile.WriteLine(line);
                }
                MessageBox.Show("Complete of Save");
                lblscan1.Visible = true;
                lblscan2.Visible = false;
                lblscan3.Visible = false;
                lblscan4.Visible = false;
                lblscan5.Visible = false;
                lblscan6.Visible = false;
                txtscan1.Visible = true;
                txtscan2.Visible = false;
                txtscan3.Visible = false;
                txtscan4.Visible = false;
                txtscan5.Visible = false;
                txtscan6.Visible = false;
                s1.Visible = true;
                s2.Visible = false;
                s3.Visible = false;
                s4.Visible = false;
                s5.Visible = false;
                s6.Visible = false;
                sca1.Visible = true;
                sca2.Visible = false;
                sca3.Visible = false;
                sca4.Visible = false;
                sca5.Visible = false;
                sca6.Visible = false;
                lblscan1.Text = Convert.ToString(str[3]).Trim();
                s1.Text = Convert.ToString(str[3]).Trim();
                txtBarcodeScan.Text = "";
                txtBarcodeScan.Focus();
                group_scan_setup.Visible = false;
            }
            if (sp1.Text != "" && sp2.Text != "" && sp3.Text == "" && sp4.Text == "" && sp5.Text == "" && sp6.Text == "")
            {
                string[] str1 = sp1.Text.Split(',');
                string[] str2 = sp2.Text.Split(',');
                mdlGlobal.scan_setup1 = Convert.ToString(str1[2]).Trim() + "," + Convert.ToString(str1[3]).Trim();
                mdlGlobal.scan_setup2 = Convert.ToString(str2[2]).Trim() + "," + Convert.ToString(str2[3]).Trim();
                //clear text              
                StreamWriter strm = File.CreateText(mdlGlobal.path_scan);
                //StreamWriter strm = File.CreateText(mdlGlobal.path_scanD);
                strm.Flush();
                strm.Close();

                // Create a string array with the additional lines of text
                string[] lines = { "Scan1 = " + mdlGlobal.scan_setup1, "Scan2 = " + mdlGlobal.scan_setup2, "Scan3 = 99,Select", "Scan4 = 99,Select", "Scan5 = 99,Select", "Scan6 = 99,Select" };

                using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scan))
                //using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scanD))
                {
                    foreach (string line in lines)
                        outputFile.WriteLine(line);
                }
                MessageBox.Show("Complete of Save");
                lblscan1.Visible = true;
                lblscan2.Visible = true;
                lblscan3.Visible = false;
                lblscan4.Visible = false;
                lblscan5.Visible = false;
                lblscan6.Visible = false;
                txtscan1.Visible = true;
                txtscan2.Visible = true;
                txtscan3.Visible = false;
                txtscan4.Visible = false;
                txtscan5.Visible = false;
                txtscan6.Visible = false;
                s1.Visible = true;
                s2.Visible = true;
                s3.Visible = false;
                s4.Visible = false;
                s5.Visible = false;
                s6.Visible = false;
                sca1.Visible = true;
                sca2.Visible = true;
                sca3.Visible = false;
                sca4.Visible = false;
                sca5.Visible = false;
                sca6.Visible = false;
                lblscan1.Text = Convert.ToString(str1[3]).Trim();
                lblscan2.Text = Convert.ToString(str2[3]).Trim();
                s1.Text = Convert.ToString(str1[3]).Trim();
                s2.Text = Convert.ToString(str2[3]).Trim();
                txtBarcodeScan.Text = "";
                txtBarcodeScan.Focus();
                group_scan_setup.Visible = false;
            }
            if (sp1.Text != "" && sp2.Text != "" && sp3.Text != "" && sp4.Text == "" && sp5.Text == "" && sp6.Text == "")
            {
                string[] str1 = sp1.Text.Split(',');
                string[] str2 = sp2.Text.Split(',');
                string[] str3 = sp3.Text.Split(',');
                mdlGlobal.scan_setup1 = Convert.ToString(str1[2]).Trim() + "," + Convert.ToString(str1[3]).Trim();
                mdlGlobal.scan_setup2 = Convert.ToString(str2[2]).Trim() + "," + Convert.ToString(str2[3]).Trim();
                mdlGlobal.scan_setup3 = Convert.ToString(str3[2]).Trim() + "," + Convert.ToString(str3[3]).Trim();
                //clear text              
                StreamWriter strm = File.CreateText(mdlGlobal.path_scan);
                //StreamWriter strm = File.CreateText(mdlGlobal.path_scanD);
                strm.Flush();
                strm.Close();

                // Create a string array with the additional lines of text
                string[] lines = { "Scan1 = " + mdlGlobal.scan_setup1, "Scan2 = " + mdlGlobal.scan_setup2, "Scan3 = " + mdlGlobal.scan_setup3, "Scan4 = 99,Select", "Scan5 = 99,Select", "Scan6 = 99,Select" };

                using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scan))
                //using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scanD))
                {
                    foreach (string line in lines)
                        outputFile.WriteLine(line);
                }
                MessageBox.Show("Complete of Save");
                lblscan1.Visible = true;
                lblscan2.Visible = true;
                lblscan3.Visible = true;
                lblscan4.Visible = false;
                lblscan5.Visible = false;
                lblscan6.Visible = false;
                txtscan1.Visible = true;
                txtscan2.Visible = true;
                txtscan3.Visible = true;
                txtscan4.Visible = false;
                txtscan5.Visible = false;
                txtscan6.Visible = false;
                s1.Visible = true;
                s2.Visible = true;
                s3.Visible = true;
                s4.Visible = false;
                s5.Visible = false;
                s6.Visible = false;
                sca1.Visible = true;
                sca2.Visible = true;
                sca3.Visible = true;
                sca4.Visible = false;
                sca5.Visible = false;
                sca6.Visible = false;
                lblscan1.Text = Convert.ToString(str1[3]).Trim();
                lblscan2.Text = Convert.ToString(str2[3]).Trim();
                lblscan3.Text = Convert.ToString(str3[3]).Trim();
                s1.Text = Convert.ToString(str1[3]).Trim();
                s2.Text = Convert.ToString(str2[3]).Trim();
                s3.Text = Convert.ToString(str3[3]).Trim();
                txtBarcodeScan.Text = "";
                txtBarcodeScan.Focus();
                group_scan_setup.Visible = false;
            }
            if (sp1.Text != "" && sp2.Text != "" && sp3.Text != "" && sp4.Text != "" && sp5.Text == "" && sp6.Text == "")
            {
                string[] str1 = sp1.Text.Split(',');
                string[] str2 = sp2.Text.Split(',');
                string[] str3 = sp3.Text.Split(',');
                string[] str4 = sp4.Text.Split(',');
                mdlGlobal.scan_setup1 = Convert.ToString(str1[2]).Trim() + "," + Convert.ToString(str1[3]).Trim();
                mdlGlobal.scan_setup2 = Convert.ToString(str2[2]).Trim() + "," + Convert.ToString(str2[3]).Trim();
                mdlGlobal.scan_setup3 = Convert.ToString(str3[2]).Trim() + "," + Convert.ToString(str3[3]).Trim();
                mdlGlobal.scan_setup4 = Convert.ToString(str4[2]).Trim() + "," + Convert.ToString(str4[3]).Trim();
                //clear text              
                StreamWriter strm = File.CreateText(mdlGlobal.path_scan);
                //StreamWriter strm = File.CreateText(mdlGlobal.path_scanD);
                strm.Flush();
                strm.Close();

                // Create a string array with the additional lines of text
                string[] lines = { "Scan1 = " + mdlGlobal.scan_setup1, "Scan2 = " + mdlGlobal.scan_setup2, "Scan3 = " + mdlGlobal.scan_setup3, "Scan4 = " + mdlGlobal.scan_setup4, "Scan5 = 99,Select", "Scan6 = 99,Select" };

                using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scan))
                //using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scanD))
                {
                    foreach (string line in lines)
                        outputFile.WriteLine(line);
                }
                MessageBox.Show("Complete of Save");
                lblscan1.Visible = true;
                lblscan2.Visible = true;
                lblscan3.Visible = true;
                lblscan4.Visible = true;
                lblscan5.Visible = false;
                lblscan6.Visible = false;
                txtscan1.Visible = true;
                txtscan2.Visible = true;
                txtscan3.Visible = true;
                txtscan4.Visible = true;
                txtscan5.Visible = false;
                txtscan6.Visible = false;
                s1.Visible = true;
                s2.Visible = true;
                s3.Visible = true;
                s4.Visible = true;
                s5.Visible = false;
                s6.Visible = false;
                sca1.Visible = true;
                sca2.Visible = true;
                sca3.Visible = true;
                sca4.Visible = true;
                sca5.Visible = false;
                sca6.Visible = false;
                lblscan1.Text = Convert.ToString(str1[3]).Trim();
                lblscan2.Text = Convert.ToString(str2[3]).Trim();
                lblscan3.Text = Convert.ToString(str3[3]).Trim();
                lblscan4.Text = Convert.ToString(str4[3]).Trim();
                s1.Text = Convert.ToString(str1[3]).Trim();
                s2.Text = Convert.ToString(str2[3]).Trim();
                s3.Text = Convert.ToString(str3[3]).Trim();
                s4.Text = Convert.ToString(str4[3]).Trim();
                txtBarcodeScan.Text = "";
                txtBarcodeScan.Focus();
                group_scan_setup.Visible = false;
            }
            if (sp1.Text != "" && sp2.Text != "" && sp3.Text != "" && sp4.Text != "" && sp5.Text != "" && sp6.Text == "")
            {
                string[] str1 = sp1.Text.Split(',');
                string[] str2 = sp2.Text.Split(',');
                string[] str3 = sp3.Text.Split(',');
                string[] str4 = sp4.Text.Split(',');
                string[] str5 = sp5.Text.Split(',');
                mdlGlobal.scan_setup1 = Convert.ToString(str1[2]).Trim() + "," + Convert.ToString(str1[3]).Trim();
                mdlGlobal.scan_setup2 = Convert.ToString(str2[2]).Trim() + "," + Convert.ToString(str2[3]).Trim();
                mdlGlobal.scan_setup3 = Convert.ToString(str3[2]).Trim() + "," + Convert.ToString(str3[3]).Trim();
                mdlGlobal.scan_setup4 = Convert.ToString(str4[2]).Trim() + "," + Convert.ToString(str4[3]).Trim();
                mdlGlobal.scan_setup5 = Convert.ToString(str5[2]).Trim() + "," + Convert.ToString(str5[3]).Trim();
                //clear text              
                StreamWriter strm = File.CreateText(mdlGlobal.path_scan);
                //StreamWriter strm = File.CreateText(mdlGlobal.path_scanD);
                strm.Flush();
                strm.Close();

                // Create a string array with the additional lines of text
                string[] lines = { "Scan1 = " + mdlGlobal.scan_setup1, "Scan2 = " + mdlGlobal.scan_setup2, "Scan3 = " + mdlGlobal.scan_setup3, "Scan4 = " + mdlGlobal.scan_setup4, "Scan5 = " + mdlGlobal.scan_setup5, "Scan6 = 99,Select" };

                using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scan))
                //using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scanD))
                {
                    foreach (string line in lines)
                        outputFile.WriteLine(line);
                }
                MessageBox.Show("Complete of Save");
                lblscan1.Visible = true;
                lblscan2.Visible = true;
                lblscan3.Visible = true;
                lblscan4.Visible = true;
                lblscan5.Visible = true;
                lblscan6.Visible = false;
                txtscan1.Visible = true;
                txtscan2.Visible = true;
                txtscan3.Visible = true;
                txtscan4.Visible = true;
                txtscan5.Visible = true;
                txtscan6.Visible = false;
                s1.Visible = true;
                s2.Visible = true;
                s3.Visible = true;
                s4.Visible = true;
                s5.Visible = true;
                s6.Visible = false;
                sca1.Visible = true;
                sca2.Visible = true;
                sca3.Visible = true;
                sca4.Visible = true;
                sca5.Visible = true;
                sca6.Visible = false;
                lblscan1.Text = Convert.ToString(str1[3]).Trim();
                lblscan2.Text = Convert.ToString(str2[3]).Trim();
                lblscan3.Text = Convert.ToString(str3[3]).Trim();
                lblscan4.Text = Convert.ToString(str4[3]).Trim();
                lblscan5.Text = Convert.ToString(str5[3]).Trim();
                s1.Text = Convert.ToString(str1[3]).Trim();
                s2.Text = Convert.ToString(str2[3]).Trim();
                s3.Text = Convert.ToString(str3[3]).Trim();
                s4.Text = Convert.ToString(str4[3]).Trim();
                s5.Text = Convert.ToString(str5[3]).Trim();
                txtBarcodeScan.Text = "";
                txtBarcodeScan.Focus();
                group_scan_setup.Visible = false;
            }
            if (sp1.Text != "" && sp2.Text != "" && sp3.Text != "" && sp4.Text != "" && sp5.Text != "" && sp6.Text != "")
            {
                string[] str1 = sp1.Text.Split(',');
                string[] str2 = sp2.Text.Split(',');
                string[] str3 = sp3.Text.Split(',');
                string[] str4 = sp4.Text.Split(',');
                string[] str5 = sp5.Text.Split(',');
                string[] str6 = sp6.Text.Split(',');
                mdlGlobal.scan_setup1 = Convert.ToString(str1[2]).Trim() + "," + Convert.ToString(str1[3]).Trim();
                mdlGlobal.scan_setup2 = Convert.ToString(str2[2]).Trim() + "," + Convert.ToString(str2[3]).Trim();
                mdlGlobal.scan_setup3 = Convert.ToString(str3[2]).Trim() + "," + Convert.ToString(str3[3]).Trim();
                mdlGlobal.scan_setup4 = Convert.ToString(str4[2]).Trim() + "," + Convert.ToString(str4[3]).Trim();
                mdlGlobal.scan_setup5 = Convert.ToString(str5[2]).Trim() + "," + Convert.ToString(str5[3]).Trim();
                mdlGlobal.scan_setup6 = Convert.ToString(str6[2]).Trim() + "," + Convert.ToString(str6[3]).Trim();
                //clear text              
                StreamWriter strm = File.CreateText(mdlGlobal.path_scan);
                //StreamWriter strm = File.CreateText(mdlGlobal.path_scanD);
                strm.Flush();
                strm.Close();

                // Create a string array with the additional lines of text
                string[] lines = { "Scan1 = " + mdlGlobal.scan_setup1, "Scan2 = " + mdlGlobal.scan_setup2, "Scan3 = " + mdlGlobal.scan_setup3, "Scan4 = " + mdlGlobal.scan_setup4, "Scan5 = " + mdlGlobal.scan_setup5, "Scan6 = " + mdlGlobal.scan_setup6 };

                using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scan))
                //using (StreamWriter outputFile = new StreamWriter(mdlGlobal.path_scanD))
                {
                    foreach (string line in lines)
                        outputFile.WriteLine(line);
                }
                MessageBox.Show("Complete of Save");
                lblscan1.Visible = true;
                lblscan2.Visible = true;
                lblscan3.Visible = true;
                lblscan4.Visible = true;
                lblscan5.Visible = true;
                lblscan6.Visible = true;
                txtscan1.Visible = true;
                txtscan2.Visible = true;
                txtscan3.Visible = true;
                txtscan4.Visible = true;
                txtscan5.Visible = true;
                txtscan6.Visible = true;
                s1.Visible = true;
                s2.Visible = true;
                s3.Visible = true;
                s4.Visible = true;
                s5.Visible = true;
                s6.Visible = true;
                sca1.Visible = true;
                sca2.Visible = true;
                sca3.Visible = true;
                sca4.Visible = true;
                sca5.Visible = true;
                sca6.Visible = true;
                lblscan1.Text = Convert.ToString(str1[3]).Trim();
                lblscan2.Text = Convert.ToString(str2[3]).Trim();
                lblscan3.Text = Convert.ToString(str3[3]).Trim();
                lblscan4.Text = Convert.ToString(str4[3]).Trim();
                lblscan5.Text = Convert.ToString(str5[3]).Trim();
                lblscan6.Text = Convert.ToString(str6[3]).Trim();
                s1.Text = Convert.ToString(str1[3]).Trim();
                s2.Text = Convert.ToString(str2[3]).Trim();
                s3.Text = Convert.ToString(str3[3]).Trim();
                s4.Text = Convert.ToString(str4[3]).Trim();
                s5.Text = Convert.ToString(str5[3]).Trim();
                s6.Text = Convert.ToString(str6[3]).Trim();
                txtBarcodeScan.Text = "";
                txtBarcodeScan.Focus();
                group_scan_setup.Visible = false;
            }
        }

        private void setINIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //show INI form
        }

        //private void txtBarcodeScan_TextChanged(object sender, EventArgs e)
        //{

        //}
        //joe
        private void txtscan1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txtBarcodeScan.Text == "")
                {
                    lblResult.Visible = true;
                    lblResult.BackColor = System.Drawing.Color.Red;
                    lblResult.Text = "Wrong Scan";
                    txtResult.Text = "Worng!! scan fist Mainseal";
                    txtscan1.Text = "";
                    txtscan1.Focus();
                    
                    return;
                }

                using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                {
                    SqlCommand command =
                    //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                    new SqlCommand("select Type from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s1.Text + "'", connection);
                    connection.Open();
                    //sqlconnection.Open();

                    SqlDataReader read = command.ExecuteReader();

                    //mdlGlobal.CurrentModel = "";
                    while (read.Read())
                    {
                        mdlGlobal.pcb_type = (read["Type"].ToString());
                    }
                    if (mdlGlobal.pcb_type == null)
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = "Wrong DeckBacode setup";
                        txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                        //txtBarcodeScan.Text = "";
                        txtscan1.Text = "";
                        txtscan1.Focus();
                        //txtBarcodeScan.Focus();
                        read.Close();
                        sqlconnection.Close();
                        return;
                    }
                    read.Close();

                }

                sqlconnection.Close();

                if (mdlGlobal.pcb_type == "1" || mdlGlobal.pcb_type == "2" || mdlGlobal.pcb_type == "5" || mdlGlobal.pcb_type == "6" || mdlGlobal.pcb_type == "7" || mdlGlobal.pcb_type == "8" || mdlGlobal.pcb_type == "9" || mdlGlobal.pcb_type == "10" || mdlGlobal.pcb_type == "86" || mdlGlobal.pcb_type == "87" || mdlGlobal.pcb_type == "90" || mdlGlobal.pcb_type == "92" || mdlGlobal.pcb_type == "93" || mdlGlobal.pcb_type == "12" || mdlGlobal.pcb_type == "13")
                {
                    //verrify Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP1, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    //Nee Addition for verify process ICT or Function 13DEc2019
                    if (mdlGlobal.SP1.ToUpper() == "USP_PCB_MODEL_CHECK1"){
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan1.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type));
                    }
                    else {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan1.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.test_type));
                        comm.Parameters.Add(new SqlParameter("@PCB_test", mdlGlobal.pcb_type));
                    }
                    //Nee Skip for verify process ICT or Function 13DEc2019
                    ////SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    //SqlCommand comm = new SqlCommand(mdlGlobal.SP1, con);

                    //comm.CommandType = CommandType.StoredProcedure;

                    //comm.Parameters.Add(new SqlParameter("@serial_number", txtscan1.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type));

                    string ret1 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret1;
                    if (ret1 != "0")
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = mdlGlobal.return_flag; //"Worng Process";
                        txtResult.Text = mdlGlobal.return_flag + " " + "Check at unit status or DeckBacodeValidation not data";
                        //txtBarcodeScan.Text = "";
                        txtscan1.Text = "";
                        txtscan1.Focus();
                        //txtBarcodeScan.Focus();
                        con.Close();
                        return;
                    }


                    con.Close();


                    //function recive txtscan
                    if (txtscan2.Visible == false)
                    {
                        s2.Text = "";
                        s3.Text = "";
                        s4.Text = "";
                        s5.Text = "";
                        s6.Text = "";

                        nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                        ////insert serial_numbers
                        SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                        cmdA.CommandType = CommandType.StoredProcedure;
                        cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                        cmdA.Parameters.AddWithValue("@comment", nComment);
                        cmdA.Parameters.AddWithValue("@pass_fail", "1");
                        cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                        cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                        cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                        conA.Open();
                        cmdA.ExecuteNonQuery();

                        conA.Close();

                        ////insert DeckBarcoderelations
                        SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                        cmd1.CommandType = CommandType.StoredProcedure;
                        cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                        cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                        cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                        con1.Open();
                        cmd1.ExecuteNonQuery();

                        con1.Close();

                        count_update();

                    }                                      

                    if (txtscan2.Visible == false)
                    {
                        lblResult.BackColor = System.Drawing.Color.Green;
                        lblResult.ForeColor = Color.MintCream;
                        lblResult.Visible = true;
                        txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                        passMsg("PASS UNIT SCAN");
                        txtBarcodeScan.Text = "";
                        txtscan1.Text = "";
                        txtBarcodeScan.Focus();
                    }
                    else
                    {
                        lblResult.Visible = false;
                        txtResult.Text = "";
                        txtscan2.Text = "";
                        txtscan2.Focus();
                    }

                    
                }
                else
                {
                    //verrify not Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP1, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    comm.Parameters.Add(new SqlParameter("@serial_number", txtscan1.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type));

                    string ret2 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret2;
                    if (ret2 != "0")
                    {
                        using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                        {
                            SqlCommand command =
                            //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                            new SqlCommand("select Start_Pos,Length,Content from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s1.Text + "'", connection);
                            connection.Open();
                            //sqlconnection.Open();

                            SqlDataReader read = command.ExecuteReader();

                            //mdlGlobal.CurrentModel = "";
                            while (read.Read())
                            {
                                mdlGlobal.start1 = int.Parse(read["Start_Pos"].ToString());
                                mdlGlobal.length1 = int.Parse(read["Length"].ToString());
                                mdlGlobal.Content1 = (read["Content"].ToString());
                            }
                            if (mdlGlobal.Content1 == null)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong DeckBacode setup";
                                txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                                //txtBarcodeScan.Text = "";
                                txtscan1.Text = "";
                                txtscan1.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;
                            }

                            if (txtscan1.Text.Substring((mdlGlobal.start1 - 1), mdlGlobal.length1) != mdlGlobal.Content1)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong Part No.";
                                txtResult.Text = "Worng!! Part Not match Model check master DeckBacodevalidation or material";
                                //txtBarcodeScan.Text = "";
                                txtscan1.Text = "";
                                txtscan1.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;

                            }
                            else
                            {
                                //function recive txtscan
                                if (txtscan2.Visible == false)
                                {
                                    s2.Text = "";
                                    s3.Text = "";
                                    s4.Text = "";
                                    s5.Text = "";
                                    s6.Text = "";

                                    nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                                    ////insert serial_numbers
                                    SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                                    cmdA.CommandType = CommandType.StoredProcedure;
                                    cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                                    cmdA.Parameters.AddWithValue("@comment", nComment);
                                    cmdA.Parameters.AddWithValue("@pass_fail", "1");
                                    cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                                    cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                                    cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                                    conA.Open();
                                    cmdA.ExecuteNonQuery();

                                    conA.Close();

                                    ////insert DeckBarcoderelations
                                    SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                                    cmd1.CommandType = CommandType.StoredProcedure;
                                    cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                                    cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                                    cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con1.Open();
                                    cmd1.ExecuteNonQuery();

                                    con1.Close();

                                    count_update();
                                }                               

                                if (txtscan2.Visible == false)
                                {
                                    lblResult.BackColor = System.Drawing.Color.Green;
                                    lblResult.ForeColor = Color.MintCream;
                                    lblResult.Visible = true;
                                    txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                                    passMsg("PASS UNIT SCAN");
                                    txtBarcodeScan.Text = "";
                                    txtscan1.Text = "";
                                    txtBarcodeScan.Focus();
                                }
                                else
                                {
                                    lblResult.Visible = false;
                                    txtResult.Text = "";
                                    txtscan2.Text = "";
                                    txtscan2.Focus();
                                }

                                

                            }
                            read.Close();

                        }

                        sqlconnection.Close();

                    }


                    con.Close();
                }


            }
        }

        private void txtscan2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txtscan1.Text == "")
                {
                    lblResult.Visible = true;
                    lblResult.BackColor = System.Drawing.Color.Red;
                    lblResult.Text = "Wrong Scan";
                    txtResult.Text = "Worng!! scan fist Material";
                    txtscan2.Text = "";
                    txtscan2.Focus();

                    return;
                }

                using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                {
                    SqlCommand command =
                    //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                    new SqlCommand("select Type from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s2.Text + "'", connection);
                    connection.Open();
                    //sqlconnection.Open();

                    SqlDataReader read = command.ExecuteReader();

                    //mdlGlobal.CurrentModel = "";
                    while (read.Read())
                    {
                        mdlGlobal.pcb_type2 = (read["Type"].ToString());
                    }
                    if (mdlGlobal.pcb_type2 == null)
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = "Wrong DeckBacode setup";
                        txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                        //txtBarcodeScan.Text = "";
                        txtscan2.Text = "";
                        txtscan2.Focus();
                        //txtBarcodeScan.Focus();
                        read.Close();
                        sqlconnection.Close();
                        return;
                    }
                    read.Close();

                }

                sqlconnection.Close();

                if (mdlGlobal.pcb_type2 == "1" || mdlGlobal.pcb_type2 == "2" || mdlGlobal.pcb_type2 == "5" || mdlGlobal.pcb_type2 == "6" || mdlGlobal.pcb_type2 == "7" || mdlGlobal.pcb_type2 == "8" || mdlGlobal.pcb_type2 == "9" || mdlGlobal.pcb_type2 == "10" || mdlGlobal.pcb_type2 == "86" || mdlGlobal.pcb_type2 == "87" || mdlGlobal.pcb_type2 == "90" || mdlGlobal.pcb_type2 == "92" || mdlGlobal.pcb_type2 == "93" || mdlGlobal.pcb_type2 == "12" || mdlGlobal.pcb_type2 == "13")
                {
                    //verrify Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP2, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    //Nee Addition for verify process ICT or Function 13DEc2019
                    if (mdlGlobal.SP2.ToUpper() == "USP_PCB_MODEL_CHECK1")
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan2.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type2));
                    }
                    else
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan2.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.test_type));
                        comm.Parameters.Add(new SqlParameter("@PCB_test", mdlGlobal.pcb_type2));
                    }
                    //Nee Skip for verify process ICT or Function 13DEc2019
                    ////SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    //SqlCommand comm = new SqlCommand(mdlGlobal.SP2, con);

                    //comm.CommandType = CommandType.StoredProcedure;

                    //comm.Parameters.Add(new SqlParameter("@serial_number", txtscan2.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type2));

                    string ret1 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret1;
                    if (ret1 != "0")
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = mdlGlobal.return_flag; //"Worng Process";
                        txtResult.Text = mdlGlobal.return_flag + " " + "Check at unit status or DeckBacodeValidation not data";
                        //txtBarcodeScan.Text = "";
                        txtscan2.Text = "";
                        txtscan2.Focus();
                        //txtBarcodeScan.Focus();
                        con.Close();
                        return;
                    }


                    con.Close();


                    //function recive txtscan
                    if (txtscan3.Visible == false)
                    {
                        s3.Text = "";
                        s4.Text = "";
                        s5.Text = "";
                        s6.Text = "";

                        nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                        ////insert serial_numbers
                        SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                        cmdA.CommandType = CommandType.StoredProcedure;
                        cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                        cmdA.Parameters.AddWithValue("@comment", nComment);
                        cmdA.Parameters.AddWithValue("@pass_fail", "1");
                        cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                        cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                        cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                        conA.Open();
                        cmdA.ExecuteNonQuery();

                        conA.Close();

                        SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                        cmd1.CommandType = CommandType.StoredProcedure;
                        cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                        cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                        cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                        con1.Open();
                        cmd1.ExecuteNonQuery();

                        con1.Close();

                        SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                        cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                        cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                        con2.Open();
                        cmd2.ExecuteNonQuery();

                        con2.Close();

                        count_update();
                    }                   

                    if (txtscan3.Visible == false)
                    {
                        lblResult.BackColor = System.Drawing.Color.Green;
                        lblResult.ForeColor = Color.MintCream;
                        lblResult.Visible = true;
                        txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                        passMsg("PASS UNIT SCAN");
                        txtBarcodeScan.Text = "";
                        txtscan1.Text = "";
                        txtscan2.Text = "";
                        txtBarcodeScan.Focus();
                    }
                    else
                    {
                        lblResult.Visible = false;
                        txtResult.Text = "";
                        txtscan3.Text = "";
                        txtscan3.Focus();
                    }

                   
                }
                else
                {
                    //verrify not Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP2, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    comm.Parameters.Add(new SqlParameter("@serial_number", txtscan2.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type));

                    string ret2 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret2;
                    if (ret2 != "0")
                    {
                        using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                        {
                            SqlCommand command =
                            //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                            new SqlCommand("select Start_Pos,Length,Content from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s2.Text + "'", connection);
                            connection.Open();
                            //sqlconnection.Open();

                            SqlDataReader read = command.ExecuteReader();

                            //mdlGlobal.CurrentModel = "";
                            while (read.Read())
                            {
                                mdlGlobal.start1 = int.Parse(read["Start_Pos"].ToString());
                                mdlGlobal.length1 = int.Parse(read["Length"].ToString());
                                mdlGlobal.Content1 = (read["Content"].ToString());


                            }
                            if (mdlGlobal.Content1 == null)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong DeckBacode setup";
                                txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                                //txtBarcodeScan.Text = "";
                                txtscan2.Text = "";
                                txtscan2.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;
                            }

                            if (txtscan2.Text.Substring((mdlGlobal.start1 - 1), mdlGlobal.length1) != mdlGlobal.Content1)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong Part No.";
                                txtResult.Text = "Worng!! Part Not match Model check master DeckBacodevalidation or material";
                                //txtBarcodeScan.Text = "";
                                txtscan2.Text = "";
                                txtscan2.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;

                            }
                            else
                            {
                                //function recive txtscan
                                //s2.Text = "";
                                if (txtscan3.Visible == false)
                                {
                                    s3.Text = "";
                                    s4.Text = "";
                                    s5.Text = "";
                                    s6.Text = "";

                                    nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                                    ////insert serial_numbers
                                    SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                                    cmdA.CommandType = CommandType.StoredProcedure;
                                    cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                                    cmdA.Parameters.AddWithValue("@comment", nComment);
                                    cmdA.Parameters.AddWithValue("@pass_fail", "1");
                                    cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                                    cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                                    cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                                    conA.Open();
                                    cmdA.ExecuteNonQuery();

                                    conA.Close();

                                    SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                                    cmd1.CommandType = CommandType.StoredProcedure;
                                    cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                                    cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                                    cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con1.Open();
                                    cmd1.ExecuteNonQuery();

                                    con1.Close();

                                    ////insert DeckBarcoderelations
                                    SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                                    cmd2.CommandType = CommandType.StoredProcedure;
                                    cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                                    cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                                    cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con2.Open();
                                    cmd2.ExecuteNonQuery();


                                    con2.Close();

                                    count_update();
                                }
                                

                                if (txtscan3.Visible == false)
                                {
                                    lblResult.BackColor = System.Drawing.Color.Green;
                                    lblResult.ForeColor = Color.MintCream;
                                    lblResult.Visible = true;
                                    txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                                    passMsg("PASS UNIT SCAN");
                                    txtBarcodeScan.Text = "";
                                    txtscan1.Text = "";
                                    txtscan2.Text = "";
                                    txtBarcodeScan.Focus();
                                }
                                else
                                {
                                    lblResult.Visible = false;
                                    txtResult.Text = "";
                                    txtscan3.Text = "";
                                    txtscan3.Focus();
                                }

                               

                            }
                            read.Close();

                        }

                        sqlconnection.Close();

                    }


                    con.Close();
                }


            }
        }

        private void txtscan3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txtscan2.Text == "")
                {
                    lblResult.Visible = true;
                    lblResult.BackColor = System.Drawing.Color.Red;
                    lblResult.Text = "Wrong Scan";
                    txtResult.Text = "Worng!! scan fist Material";
                    txtscan3.Text = "";
                    txtscan3.Focus();

                    return;
                }

                using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                {
                    SqlCommand command =
                    //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                    new SqlCommand("select Type from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s3.Text + "'", connection);
                    connection.Open();
                    //sqlconnection.Open();

                    SqlDataReader read = command.ExecuteReader();

                    //mdlGlobal.CurrentModel = "";
                    while (read.Read())
                    {
                        mdlGlobal.pcb_type3 = (read["Type"].ToString());
                    }
                    if (mdlGlobal.pcb_type3 == null)
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = "Wrong DeckBacode setup";
                        txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                        //txtBarcodeScan.Text = "";
                        txtscan3.Text = "";
                        txtscan3.Focus();
                        //txtBarcodeScan.Focus();
                        read.Close();
                        sqlconnection.Close();
                        return;
                    }
                    read.Close();

                }

                sqlconnection.Close();

                if (mdlGlobal.pcb_type3 == "1" || mdlGlobal.pcb_type3 == "2" || mdlGlobal.pcb_type3 == "5" || mdlGlobal.pcb_type3 == "6" || mdlGlobal.pcb_type3 == "7" || mdlGlobal.pcb_type3 == "8" || mdlGlobal.pcb_type3 == "9" || mdlGlobal.pcb_type3 == "10" || mdlGlobal.pcb_type3 == "86" || mdlGlobal.pcb_type3 == "87" || mdlGlobal.pcb_type3 == "90" || mdlGlobal.pcb_type3 == "92" || mdlGlobal.pcb_type3 == "93" || mdlGlobal.pcb_type3 == "12" || mdlGlobal.pcb_type3 == "13")
                {
                    //verrify Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP3, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    //Nee Addition for verify process ICT or Function 13DEc2019
                    if (mdlGlobal.SP3.ToUpper() == "USP_PCB_MODEL_CHECK1")
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan3.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type3));
                    }
                    else
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan3.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.test_type));
                        comm.Parameters.Add(new SqlParameter("@PCB_test", mdlGlobal.pcb_type3));
                    }
                    //Nee Skip for verify process ICT or Function 13DEc2019
                    ////SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    //SqlCommand comm = new SqlCommand(mdlGlobal.SP3, con);

                    //comm.CommandType = CommandType.StoredProcedure;

                    //comm.Parameters.Add(new SqlParameter("@serial_number", txtscan3.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type3));

                    string ret3 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret3;
                    if (ret3 != "0")
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = mdlGlobal.return_flag; //"Worng Process";
                        txtResult.Text = mdlGlobal.return_flag + " " + "Check at unit status or DeckBacodeValidation not data";
                        //txtBarcodeScan.Text = "";
                        txtscan3.Text = "";
                        txtscan3.Focus();
                        //txtBarcodeScan.Focus();
                        con.Close();
                        return;
                    }


                    con.Close();


                    //function recive txtscan
                    if (txtscan4.Visible == false)
                    {                        
                        s4.Text = "";
                        s5.Text = "";
                        s6.Text = "";

                        nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                        ////insert serial_numbers
                        SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                        cmdA.CommandType = CommandType.StoredProcedure;
                        cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                        cmdA.Parameters.AddWithValue("@comment", nComment);
                        cmdA.Parameters.AddWithValue("@pass_fail", "1");
                        cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                        cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                        cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                        conA.Open();
                        cmdA.ExecuteNonQuery();

                        conA.Close();

                        SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                        cmd1.CommandType = CommandType.StoredProcedure;
                        cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                        cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                        cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                        con1.Open();
                        cmd1.ExecuteNonQuery();

                        con1.Close();

                        SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                        cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                        cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                        con2.Open();
                        cmd2.ExecuteNonQuery();

                        con2.Close();

                        SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd3 = new SqlCommand("sp_InsertBarcodeLink", con3);
                        cmd3.CommandType = CommandType.StoredProcedure;
                        cmd3.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd3.Parameters.AddWithValue("@BC2", txtscan3.Text);
                        cmd3.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                        cmd3.Parameters.AddWithValue("@Node", lblNode.Text);
                        con3.Open();
                        cmd3.ExecuteNonQuery();

                        con3.Close();

                        SqlConnection con4 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd4 = new SqlCommand("sp_InsertBarcodeLink", con4);
                        cmd4.CommandType = CommandType.StoredProcedure;
                        cmd4.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd4.Parameters.AddWithValue("@BC2", mdlGlobal.XM_ID);
                        cmd4.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                        cmd4.Parameters.AddWithValue("@Node", lblNode.Text);
                        con4.Open();
                        cmd4.ExecuteNonQuery();

                        con4.Close();

                        count_update();
                    }                   


                    if (txtscan4.Visible == false)
                    {
                        lblResult.BackColor = System.Drawing.Color.Green;
                        lblResult.ForeColor = Color.MintCream;
                        lblResult.Visible = true;
                        txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                        passMsg("PASS UNIT SCAN");
                        txtBarcodeScan.Text = "";
                        txtscan1.Text = "";
                        txtscan2.Text = "";
                        txtscan3.Text = "";
                        txtBarcodeScan.Focus();
                    }
                    else
                    {
                        lblResult.Visible = false;
                        txtResult.Text = "";
                        txtscan4.Text = "";
                        txtscan4.Focus();
                    }

                   
                }
                else
                {
                    //verrify not Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP3, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    comm.Parameters.Add(new SqlParameter("@serial_number", txtscan3.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type));

                    string ret3 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret3;
                    if (ret3 != "0")
                    {
                        using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                        {
                            SqlCommand command =
                            //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                            new SqlCommand("select Start_Pos,Length,Content from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s3.Text + "'", connection);
                            connection.Open();
                            //sqlconnection.Open();

                            SqlDataReader read = command.ExecuteReader();

                            //mdlGlobal.CurrentModel = "";
                            while (read.Read())
                            {
                                mdlGlobal.start1 = int.Parse(read["Start_Pos"].ToString());
                                mdlGlobal.length1 = int.Parse(read["Length"].ToString());
                                mdlGlobal.Content1 = (read["Content"].ToString());


                            }
                            if (mdlGlobal.Content1 == null)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong DeckBacode setup";
                                txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                                //txtBarcodeScan.Text = "";
                                txtscan3.Text = "";
                                txtscan3.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;
                            }

                            if (txtscan3.Text.Substring((mdlGlobal.start1 - 1), mdlGlobal.length1) != mdlGlobal.Content1)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong Part No.";
                                txtResult.Text = "Worng!! Part Not match Model check master DeckBacodevalidation or material";
                                //txtBarcodeScan.Text = "";
                                txtscan3.Text = "";
                                txtscan3.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;

                            }
                            else
                            {
                                //function recive txtscan
                                //s2.Text = "";
                                if (txtscan4.Visible == false)
                                {                                   
                                    s4.Text = "";
                                    s5.Text = "";
                                    s6.Text = "";

                                    nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                                    ////insert serial_numbers
                                    SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                                    cmdA.CommandType = CommandType.StoredProcedure;
                                    cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                                    cmdA.Parameters.AddWithValue("@comment", nComment);
                                    cmdA.Parameters.AddWithValue("@pass_fail", "1");
                                    cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                                    cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                                    cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                                    conA.Open();
                                    cmdA.ExecuteNonQuery();

                                    conA.Close();

                                    SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                                    cmd1.CommandType = CommandType.StoredProcedure;
                                    cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                                    cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                                    cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con1.Open();
                                    cmd1.ExecuteNonQuery();

                                    con1.Close();

                                    SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                                    cmd2.CommandType = CommandType.StoredProcedure;
                                    cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                                    cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                                    cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con2.Open();
                                    cmd2.ExecuteNonQuery();

                                    con2.Close();

                                    ////insert DeckBarcoderelations
                                    SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd3 = new SqlCommand("sp_InsertBarcodeLink", con3);
                                    cmd3.CommandType = CommandType.StoredProcedure;
                                    cmd3.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd3.Parameters.AddWithValue("@BC2", txtscan3.Text);
                                    cmd3.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                                    cmd3.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con3.Open();
                                    cmd3.ExecuteNonQuery();

                                    con3.Close();

                                    SqlConnection con4 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd4 = new SqlCommand("sp_InsertBarcodeLink", con4);
                                    cmd4.CommandType = CommandType.StoredProcedure;
                                    cmd4.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd4.Parameters.AddWithValue("@BC2", mdlGlobal.XM_ID);
                                    cmd4.Parameters.AddWithValue("@Type", "221");
                                    cmd4.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con4.Open();
                                    cmd4.ExecuteNonQuery();

                                    con4.Close();



                                    count_update();

                                }
                               

                                if (txtscan4.Visible == false)
                                {
                                    lblResult.BackColor = System.Drawing.Color.Green;
                                    lblResult.ForeColor = Color.MintCream;
                                    lblResult.Visible = true;
                                    txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                                    passMsg("PASS UNIT SCAN");
                                    txtBarcodeScan.Text = "";
                                    txtscan1.Text = "";
                                    txtscan2.Text = "";
                                    txtscan3.Text = "";
                                    txtBarcodeScan.Focus();
                                }
                                else
                                {
                                    lblResult.Visible = false;
                                    txtResult.Text = "";
                                    txtscan4.Text = "";
                                    txtscan4.Focus();
                                }

                               

                            }
                            read.Close();

                        }

                        sqlconnection.Close();

                    }


                    con.Close();
                }


            }
        }
        //joe
        private void txtscan4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txtscan3.Text == "")
                {
                    lblResult.Visible = true;
                    lblResult.BackColor = System.Drawing.Color.Red;
                    lblResult.Text = "Wrong Scan";
                    txtResult.Text = "Worng!! scan fist Material";
                    txtscan4.Text = "";
                    txtscan4.Focus();

                    return;
                }

                using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                {
                    SqlCommand command =
                    //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                    new SqlCommand("select Type from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s4.Text + "'", connection);
                    connection.Open();
                    //sqlconnection.Open();

                    SqlDataReader read = command.ExecuteReader();

                    //mdlGlobal.CurrentModel = "";
                    while (read.Read())
                    {
                        mdlGlobal.pcb_type4 = (read["Type"].ToString());
                    }
                    if (mdlGlobal.pcb_type4 == null)
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = "Wrong DeckBacode setup";
                        txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                        //txtBarcodeScan.Text = "";
                        txtscan4.Text = "";
                        txtscan4.Focus();
                        //txtBarcodeScan.Focus();
                        read.Close();
                        sqlconnection.Close();
                        return;
                    }
                    read.Close();

                }

                sqlconnection.Close();

                if (mdlGlobal.pcb_type4 == "1" || mdlGlobal.pcb_type4 == "2" || mdlGlobal.pcb_type4 == "5" || mdlGlobal.pcb_type4 == "6" || mdlGlobal.pcb_type4 == "7" || mdlGlobal.pcb_type4 == "8" || mdlGlobal.pcb_type4 == "9" || mdlGlobal.pcb_type4 == "10" || mdlGlobal.pcb_type4 == "86" || mdlGlobal.pcb_type4 == "87" || mdlGlobal.pcb_type4 == "90" || mdlGlobal.pcb_type4 == "92" || mdlGlobal.pcb_type4 == "93" || mdlGlobal.pcb_type4 == "12" || mdlGlobal.pcb_type4 == "13")
                {
                    //verrify Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP4, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    //Nee Addition for verify process ICT or Function 13DEc2019
                    if (mdlGlobal.SP4.ToUpper() == "USP_PCB_MODEL_CHECK1")
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan4.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type4));
                    }
                    else
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan4.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.test_type));
                        comm.Parameters.Add(new SqlParameter("@PCB_test", mdlGlobal.pcb_type4));
                    }
                    //Nee Skip for verify process ICT or Function 13DEc2019
                    ////SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    //SqlCommand comm = new SqlCommand(mdlGlobal.SP4, con);

                    //comm.CommandType = CommandType.StoredProcedure;

                    //comm.Parameters.Add(new SqlParameter("@serial_number", txtscan4.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type4));

                    string ret4 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret4;
                    if (ret4 != "0")
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = mdlGlobal.return_flag; //"Worng Process";
                        txtResult.Text = mdlGlobal.return_flag + " " + "Check at unit status or DeckBacodeValidation not data";
                        //txtBarcodeScan.Text = "";
                        txtscan4.Text = "";
                        txtscan4.Focus();
                        //txtBarcodeScan.Focus();
                        con.Close();
                        return;
                    }


                    con.Close();


                    //function recive txtscan
                    if (txtscan5.Visible == false)
                    {                        
                        s5.Text = "";
                        s6.Text = "";

                        nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                        ////insert serial_numbers
                        SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                        cmdA.CommandType = CommandType.StoredProcedure;
                        cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                        cmdA.Parameters.AddWithValue("@comment", nComment);
                        cmdA.Parameters.AddWithValue("@pass_fail", "1");
                        cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                        cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                        cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                        conA.Open();
                        cmdA.ExecuteNonQuery();

                        conA.Close();

                        SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                        cmd1.CommandType = CommandType.StoredProcedure;
                        cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                        cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                        cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                        con1.Open();
                        cmd1.ExecuteNonQuery();

                        con1.Close();

                        SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                        cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                        cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                        con2.Open();
                        cmd2.ExecuteNonQuery();

                        con2.Close();

                        SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd3 = new SqlCommand("sp_InsertBarcodeLink", con3);
                        cmd3.CommandType = CommandType.StoredProcedure;
                        cmd3.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd3.Parameters.AddWithValue("@BC2", txtscan3.Text);
                        cmd3.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                        cmd3.Parameters.AddWithValue("@Node", lblNode.Text);
                        con3.Open();
                        cmd3.ExecuteNonQuery();

                        con3.Close();                        

                        count_update();
                    }


                    if (txtscan5.Visible == false)
                    {
                        lblResult.BackColor = System.Drawing.Color.Green;
                        lblResult.ForeColor = Color.MintCream;
                        lblResult.Visible = true;
                        txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                        passMsg("PASS UNIT SCAN");
                        txtBarcodeScan.Text = "";
                        txtscan1.Text = "";
                        txtscan2.Text = "";
                        txtscan3.Text = "";
                        txtscan4.Text = "";
                        txtBarcodeScan.Focus();
                    }
                    else
                    {
                        lblResult.Visible = false;
                        txtResult.Text = "";
                        txtscan5.Text = "";
                        txtscan5.Focus();
                    }


                }
                else
                {
                    //verrify not Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP4, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    comm.Parameters.Add(new SqlParameter("@serial_number", txtscan4.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type));

                    string ret4 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret4;
                    if (ret4 != "0")
                    {
                        using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                        {
                            SqlCommand command =
                            //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                            new SqlCommand("select Start_Pos,Length,Content from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s4.Text + "'", connection);
                            connection.Open();
                            //sqlconnection.Open();

                            SqlDataReader read = command.ExecuteReader();

                            //mdlGlobal.CurrentModel = "";
                            while (read.Read())
                            {
                                mdlGlobal.start1 = int.Parse(read["Start_Pos"].ToString());
                                mdlGlobal.length1 = int.Parse(read["Length"].ToString());
                                mdlGlobal.Content1 = (read["Content"].ToString());


                            }
                            if (mdlGlobal.Content1 == null)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong DeckBacode setup";
                                txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                                //txtBarcodeScan.Text = "";
                                txtscan4.Text = "";
                                txtscan4.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;
                            }

                            if (txtscan4.Text.Substring((mdlGlobal.start1 - 1), mdlGlobal.length1) != mdlGlobal.Content1)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong Part No.";
                                txtResult.Text = "Worng!! Part Not match Model check master DeckBacodevalidation or material";
                                //txtBarcodeScan.Text = "";
                                txtscan4.Text = "";
                                txtscan4.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;

                            }
                            else
                            {
                                //function recive txtscan
                                //s2.Text = "";
                                if (txtscan5.Visible == false)
                                {                                   
                                    s5.Text = "";
                                    s6.Text = "";

                                    nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                                    ////insert serial_numbers
                                    SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                                    cmdA.CommandType = CommandType.StoredProcedure;
                                    cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                                    cmdA.Parameters.AddWithValue("@comment", nComment);
                                    cmdA.Parameters.AddWithValue("@pass_fail", "1");
                                    cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                                    cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                                    cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                                    conA.Open();
                                    cmdA.ExecuteNonQuery();

                                    conA.Close();

                                    SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                                    cmd1.CommandType = CommandType.StoredProcedure;
                                    cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                                    cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                                    cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con1.Open();
                                    cmd1.ExecuteNonQuery();

                                    con1.Close();

                                    SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                                    cmd2.CommandType = CommandType.StoredProcedure;
                                    cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                                    cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                                    cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con2.Open();
                                    cmd2.ExecuteNonQuery();

                                    con2.Close();

                                    ////insert DeckBarcoderelations
                                    SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd3 = new SqlCommand("sp_InsertBarcodeLink", con3);
                                    cmd3.CommandType = CommandType.StoredProcedure;
                                    cmd3.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd3.Parameters.AddWithValue("@BC2", txtscan3.Text);
                                    cmd3.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                                    cmd3.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con3.Open();
                                    cmd3.ExecuteNonQuery();

                                    con3.Close();

                                    SqlConnection con4 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd4 = new SqlCommand("sp_InsertBarcodeLink", con4);
                                    cmd4.CommandType = CommandType.StoredProcedure;
                                    cmd4.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd4.Parameters.AddWithValue("@BC2", txtscan4.Text);
                                    cmd4.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type4);
                                    cmd4.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con4.Open();
                                    cmd4.ExecuteNonQuery();
                                   

                                    con4.Close();

                                    count_update();

                                }


                                if (txtscan5.Visible == false)
                                {
                                    lblResult.BackColor = System.Drawing.Color.Green;
                                    lblResult.ForeColor = Color.MintCream;
                                    lblResult.Visible = true;
                                    txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                                    passMsg("PASS UNIT SCAN");
                                    txtBarcodeScan.Text = "";
                                    txtscan1.Text = "";
                                    txtscan2.Text = "";
                                    txtscan3.Text = "";
                                    txtscan4.Text = "";
                                    txtBarcodeScan.Focus();
                                }
                                else
                                {
                                    lblResult.Visible = false;
                                    txtResult.Text = "";
                                    txtscan5.Text = "";
                                    txtscan5.Focus();
                                }



                            }
                            read.Close();

                        }

                        sqlconnection.Close();

                    }


                    con.Close();
                }


            }
        }

        private void txtscan5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txtscan4.Text == "")
                {
                    lblResult.Visible = true;
                    lblResult.BackColor = System.Drawing.Color.Red;
                    lblResult.Text = "Wrong Scan";
                    txtResult.Text = "Worng!! scan fist Material";
                    txtscan5.Text = "";
                    txtscan5.Focus();

                    return;
                }

                using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                {
                    SqlCommand command =
                    //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                    new SqlCommand("select Type from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s5.Text + "'", connection);
                    connection.Open();
                    //sqlconnection.Open();

                    SqlDataReader read = command.ExecuteReader();

                    //mdlGlobal.CurrentModel = "";
                    while (read.Read())
                    {
                        mdlGlobal.pcb_type5 = (read["Type"].ToString());
                    }
                    if (mdlGlobal.pcb_type5 == null)
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = "Wrong DeckBacode setup";
                        txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                        //txtBarcodeScan.Text = "";
                        txtscan5.Text = "";
                        txtscan5.Focus();
                        //txtBarcodeScan.Focus();
                        read.Close();
                        sqlconnection.Close();
                        return;
                    }
                    read.Close();

                }

                sqlconnection.Close();

                if (mdlGlobal.pcb_type5 == "1" || mdlGlobal.pcb_type5 == "2" || mdlGlobal.pcb_type5 == "5" || mdlGlobal.pcb_type5 == "6" || mdlGlobal.pcb_type5 == "7" || mdlGlobal.pcb_type5 == "8" || mdlGlobal.pcb_type5 == "9" || mdlGlobal.pcb_type5 == "10" || mdlGlobal.pcb_type5 == "86" || mdlGlobal.pcb_type5 == "87" || mdlGlobal.pcb_type5 == "90" || mdlGlobal.pcb_type5 == "92" || mdlGlobal.pcb_type5 == "93" || mdlGlobal.pcb_type5 == "12" || mdlGlobal.pcb_type5 == "13")
                {
                    //verrify Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP5, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    //Nee Addition for verify process ICT or Function 13DEc2019
                    if (mdlGlobal.SP5.ToUpper() == "USP_PCB_MODEL_CHECK1")
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan5.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type5));
                    }
                    else
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan5.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.test_type));
                        comm.Parameters.Add(new SqlParameter("@PCB_test", mdlGlobal.pcb_type5));
                    }
                    //Nee Skip for verify process ICT or Function 13DEc2019
                    ////SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    //SqlCommand comm = new SqlCommand(mdlGlobal.SP5, con);

                    //comm.CommandType = CommandType.StoredProcedure;

                    //comm.Parameters.Add(new SqlParameter("@serial_number", txtscan5.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type5));

                    string ret5 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret5;
                    if (ret5 != "0")
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = mdlGlobal.return_flag; //"Worng Process";
                        txtResult.Text = mdlGlobal.return_flag + " " + "Check at unit status or DeckBacodeValidation not data";
                        //txtBarcodeScan.Text = "";
                        txtscan5.Text = "";
                        txtscan5.Focus();
                        //txtBarcodeScan.Focus();
                        con.Close();
                        return;
                    }


                    con.Close();


                    //function recive txtscan
                    if (txtscan6.Visible == false)
                    {                        
                        s6.Text = "";

                        nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                        ////insert serial_numbers
                        SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                        cmdA.CommandType = CommandType.StoredProcedure;
                        cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                        cmdA.Parameters.AddWithValue("@comment", nComment);
                        cmdA.Parameters.AddWithValue("@pass_fail", "1");
                        cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                        cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                        cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                        conA.Open();
                        cmdA.ExecuteNonQuery();

                        conA.Close();

                        SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                        cmd1.CommandType = CommandType.StoredProcedure;
                        cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                        cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                        cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                        con1.Open();
                        cmd1.ExecuteNonQuery();

                        con1.Close();

                        SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                        cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                        cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                        con2.Open();
                        cmd2.ExecuteNonQuery();

                        con2.Close();

                        SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd3 = new SqlCommand("sp_InsertBarcodeLink", con3);
                        cmd3.CommandType = CommandType.StoredProcedure;
                        cmd3.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd3.Parameters.AddWithValue("@BC2", txtscan3.Text);
                        cmd3.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                        cmd3.Parameters.AddWithValue("@Node", lblNode.Text);
                        con3.Open();
                        cmd3.ExecuteNonQuery();

                        con3.Close();

                        SqlConnection con4 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd4 = new SqlCommand("sp_InsertBarcodeLink", con4);
                        cmd4.CommandType = CommandType.StoredProcedure;
                        cmd4.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd4.Parameters.AddWithValue("@BC2", txtscan4.Text);
                        cmd4.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type4);
                        cmd4.Parameters.AddWithValue("@Node", lblNode.Text);
                        con4.Open();
                        cmd4.ExecuteNonQuery();

                        con4.Close();

                        SqlConnection con5 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd5 = new SqlCommand("sp_InsertBarcodeLink", con5);
                        cmd5.CommandType = CommandType.StoredProcedure;
                        cmd5.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd5.Parameters.AddWithValue("@BC2", txtscan5.Text);
                        cmd5.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type5);
                        cmd5.Parameters.AddWithValue("@Node", lblNode.Text);
                        con5.Open();
                        cmd5.ExecuteNonQuery();                        

                        con5.Close();

                        count_update();
                    }


                    if (txtscan6.Visible == false)
                    {
                        lblResult.BackColor = System.Drawing.Color.Green;
                        lblResult.ForeColor = Color.MintCream;
                        lblResult.Visible = true;
                        txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                        passMsg("PASS UNIT SCAN");
                        txtBarcodeScan.Text = "";
                        txtscan1.Text = "";
                        txtscan2.Text = "";
                        txtscan3.Text = "";
                        txtscan4.Text = "";
                        txtscan5.Text = "";
                        txtBarcodeScan.Focus();
                    }
                    else
                    {
                        lblResult.Visible = false;
                        txtResult.Text = "";
                        txtscan6.Text = "";
                        txtscan6.Focus();
                    }


                }
                else
                {
                    //verrify not Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP5, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    comm.Parameters.Add(new SqlParameter("@serial_number", txtscan5.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type));

                    string ret5 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret5;
                    if (ret5 != "0")
                    {
                        using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                        {
                            SqlCommand command =
                            //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                            new SqlCommand("select Start_Pos,Length,Content from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s5.Text + "'", connection);
                            connection.Open();
                            //sqlconnection.Open();

                            SqlDataReader read = command.ExecuteReader();

                            //mdlGlobal.CurrentModel = "";
                            while (read.Read())
                            {
                                mdlGlobal.start1 = int.Parse(read["Start_Pos"].ToString());
                                mdlGlobal.length1 = int.Parse(read["Length"].ToString());
                                mdlGlobal.Content1 = (read["Content"].ToString());


                            }
                            if (mdlGlobal.Content1 == null)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong DeckBacode setup";
                                txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                                //txtBarcodeScan.Text = "";
                                txtscan5.Text = "";
                                txtscan5.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;
                            }

                            if (txtscan5.Text.Substring((mdlGlobal.start1 - 1), mdlGlobal.length1) != mdlGlobal.Content1)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong Part No.";
                                txtResult.Text = "Worng!! Part Not match Model check master DeckBacodevalidation or material";
                                //txtBarcodeScan.Text = "";
                                txtscan5.Text = "";
                                txtscan5.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;

                            }
                            else
                            {
                                //function recive txtscan
                                //s2.Text = "";
                                if (txtscan6.Visible == false)
                                {                                   
                                    s6.Text = "";

                                    nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                                    ////insert serial_numbers
                                    SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                                    cmdA.CommandType = CommandType.StoredProcedure;
                                    cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                                    cmdA.Parameters.AddWithValue("@comment", nComment);
                                    cmdA.Parameters.AddWithValue("@pass_fail", "1");
                                    cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                                    cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                                    cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                                    conA.Open();
                                    cmdA.ExecuteNonQuery();

                                    conA.Close();

                                    SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                                    cmd1.CommandType = CommandType.StoredProcedure;
                                    cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                                    cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                                    cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con1.Open();
                                    cmd1.ExecuteNonQuery();

                                    con1.Close();

                                    SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                                    cmd2.CommandType = CommandType.StoredProcedure;
                                    cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                                    cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                                    cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con2.Open();
                                    cmd2.ExecuteNonQuery();

                                    con2.Close();

                                    ////insert DeckBarcoderelations
                                    SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd3 = new SqlCommand("sp_InsertBarcodeLink", con3);
                                    cmd3.CommandType = CommandType.StoredProcedure;
                                    cmd3.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd3.Parameters.AddWithValue("@BC2", txtscan3.Text);
                                    cmd3.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                                    cmd3.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con3.Open();
                                    cmd3.ExecuteNonQuery();

                                    con3.Close();

                                    SqlConnection con4 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd4 = new SqlCommand("sp_InsertBarcodeLink", con4);
                                    cmd4.CommandType = CommandType.StoredProcedure;
                                    cmd4.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd4.Parameters.AddWithValue("@BC2", txtscan4.Text);
                                    cmd4.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type4);
                                    cmd4.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con4.Open();
                                    cmd4.ExecuteNonQuery();


                                    con4.Close();

                                    SqlConnection con5 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd5 = new SqlCommand("sp_InsertBarcodeLink", con5);
                                    cmd5.CommandType = CommandType.StoredProcedure;
                                    cmd5.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd5.Parameters.AddWithValue("@BC2", txtscan5.Text);
                                    cmd5.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type5);
                                    cmd5.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con5.Open();
                                    cmd5.ExecuteNonQuery();

                                    con5.Close();

                                    count_update();
                                }


                                if (txtscan6.Visible == false)
                                {
                                    lblResult.BackColor = System.Drawing.Color.Green;
                                    lblResult.ForeColor = Color.MintCream;
                                    lblResult.Visible = true;
                                    txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                                    passMsg("PASS UNIT SCAN");
                                    txtBarcodeScan.Text = "";
                                    txtscan1.Text = "";
                                    txtscan2.Text = "";
                                    txtscan3.Text = "";
                                    txtscan4.Text = "";
                                    txtscan5.Text = "";
                                    txtBarcodeScan.Focus();
                                }
                                else
                                {
                                    lblResult.Visible = false;
                                    txtResult.Text = "";
                                    txtscan6.Text = "";
                                    txtscan6.Focus();
                                }



                            }
                            read.Close();

                        }

                        sqlconnection.Close();

                    }


                    con.Close();
                }


            }
        }

        private void txtscan6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (txtscan5.Text == "")
                {
                    lblResult.Visible = true;
                    lblResult.BackColor = System.Drawing.Color.Red;
                    lblResult.Text = "Wrong Scan";
                    txtResult.Text = "Worng!! scan fist Material";
                    txtscan6.Text = "";
                    txtscan6.Focus();

                    return;
                }

                using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                {
                    SqlCommand command =
                    //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                    new SqlCommand("select Type from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s6.Text + "'", connection);
                    connection.Open();
                    //sqlconnection.Open();

                    SqlDataReader read = command.ExecuteReader();

                    //mdlGlobal.CurrentModel = "";
                    while (read.Read())
                    {
                        mdlGlobal.pcb_type6 = (read["Type"].ToString());
                    }
                    if (mdlGlobal.pcb_type6 == null)
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = "Wrong DeckBacode setup";
                        txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                        //txtBarcodeScan.Text = "";
                        txtscan6.Text = "";
                        txtscan6.Focus();
                        //txtBarcodeScan.Focus();
                        read.Close();
                        sqlconnection.Close();
                        return;
                    }
                    read.Close();

                }

                sqlconnection.Close();

                if (mdlGlobal.pcb_type6 == "1" || mdlGlobal.pcb_type6 == "2" || mdlGlobal.pcb_type6 == "5" || mdlGlobal.pcb_type6 == "6" || mdlGlobal.pcb_type6 == "7" || mdlGlobal.pcb_type6 == "8" || mdlGlobal.pcb_type6 == "9" || mdlGlobal.pcb_type6 == "10" || mdlGlobal.pcb_type6 == "86" || mdlGlobal.pcb_type6 == "87" || mdlGlobal.pcb_type6 == "90" || mdlGlobal.pcb_type6 == "92" || mdlGlobal.pcb_type6 == "93" || mdlGlobal.pcb_type6 == "12" || mdlGlobal.pcb_type6 == "13")
                {
                    //verrify Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP6, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    //Nee Addition for verify process ICT or Function 13DEc2019
                    if (mdlGlobal.SP6.ToUpper() == "USP_PCB_MODEL_CHECK1")
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan6.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type6));
                    }
                    else
                    {
                        comm.Parameters.Add(new SqlParameter("@serial_number", txtscan6.Text.Trim()));
                        comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                        comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.test_type));
                        comm.Parameters.Add(new SqlParameter("@PCB_test", mdlGlobal.pcb_type6));
                    }
                    //Nee Skip for verify process ICT or Function 13DEc2019
                    ////SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    //SqlCommand comm = new SqlCommand(mdlGlobal.SP6, con);

                    //comm.CommandType = CommandType.StoredProcedure;

                    //comm.Parameters.Add(new SqlParameter("@serial_number", txtscan6.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type6));

                    string ret6 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret6;
                    if (ret6 != "0")
                    {
                        lblResult.Visible = true;
                        lblResult.BackColor = System.Drawing.Color.Red;
                        lblResult.Text = mdlGlobal.return_flag; //"Worng Process";
                        txtResult.Text = mdlGlobal.return_flag + " " + "Check at unit status or DeckBacodeValidation not data";
                        //txtBarcodeScan.Text = "";
                        txtscan6.Text = "";
                        txtscan6.Focus();
                        //txtBarcodeScan.Focus();
                        con.Close();
                        return;
                    }


                    con.Close();


                    //function recive txtscan
                    if (txtscan6.Visible != false)
                    {                       

                        nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                        ////insert serial_numbers
                        SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                        cmdA.CommandType = CommandType.StoredProcedure;
                        cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                        cmdA.Parameters.AddWithValue("@comment", nComment);
                        cmdA.Parameters.AddWithValue("@pass_fail", "1");
                        cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                        cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                        cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                        conA.Open();
                        cmdA.ExecuteNonQuery();

                        conA.Close();

                        SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                        cmd1.CommandType = CommandType.StoredProcedure;
                        cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                        cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                        cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                        con1.Open();
                        cmd1.ExecuteNonQuery();

                        con1.Close();

                        SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                        cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                        cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                        con2.Open();
                        cmd2.ExecuteNonQuery();

                        con2.Close();

                        SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd3 = new SqlCommand("sp_InsertBarcodeLink", con3);
                        cmd3.CommandType = CommandType.StoredProcedure;
                        cmd3.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd3.Parameters.AddWithValue("@BC2", txtscan3.Text);
                        cmd3.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                        cmd3.Parameters.AddWithValue("@Node", lblNode.Text);
                        con3.Open();
                        cmd3.ExecuteNonQuery();

                        con3.Close();

                        SqlConnection con4 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd4 = new SqlCommand("sp_InsertBarcodeLink", con4);
                        cmd4.CommandType = CommandType.StoredProcedure;
                        cmd4.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd4.Parameters.AddWithValue("@BC2", txtscan4.Text);
                        cmd4.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type4);
                        cmd4.Parameters.AddWithValue("@Node", lblNode.Text);
                        con4.Open();
                        cmd4.ExecuteNonQuery();

                        con4.Close();

                        SqlConnection con5 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd5 = new SqlCommand("sp_InsertBarcodeLink", con5);
                        cmd5.CommandType = CommandType.StoredProcedure;
                        cmd5.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd5.Parameters.AddWithValue("@BC2", txtscan5.Text);
                        cmd5.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type5);
                        cmd5.Parameters.AddWithValue("@Node", lblNode.Text);
                        con5.Open();
                        cmd5.ExecuteNonQuery();

                        con5.Close();

                        SqlConnection con6 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                        SqlCommand cmd6 = new SqlCommand("sp_InsertBarcodeLink", con6);
                        cmd6.CommandType = CommandType.StoredProcedure;
                        cmd6.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                        cmd6.Parameters.AddWithValue("@BC2", txtscan6.Text);
                        cmd6.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type6);
                        cmd6.Parameters.AddWithValue("@Node", lblNode.Text);
                        con6.Open();
                        cmd6.ExecuteNonQuery();                        

                        con6.Close();

                        count_update();
                    }


                    if (txtscan6.Visible != false)
                    {
                        lblResult.BackColor = System.Drawing.Color.Green;
                        lblResult.ForeColor = Color.MintCream;
                        lblResult.Visible = true;
                        txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                        passMsg("PASS UNIT SCAN");
                        txtBarcodeScan.Text = "";
                        txtscan1.Text = "";
                        txtscan2.Text = "";
                        txtscan3.Text = "";
                        txtscan4.Text = "";
                        txtscan5.Text = "";
                        txtscan6.Text = "";
                        txtBarcodeScan.Focus();
                    }
                    //else
                    //{

                    //    txtscan6.Text = "";
                    //    txtscan6.Focus();
                    //}


                }
                else
                {
                    //verrify not Pcb
                    SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                    con.Open();

                    //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                    SqlCommand comm = new SqlCommand(mdlGlobal.SP6, con);

                    comm.CommandType = CommandType.StoredProcedure;

                    comm.Parameters.Add(new SqlParameter("@serial_number", txtscan6.Text.Trim()));
                    //comm.Parameters.Add(new SqlParameter("@model", mdlGlobal.CurrentModel));
                    //comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.pcb_type));

                    string ret6 = comm.ExecuteScalar().ToString();
                    mdlGlobal.return_flag = ret6;
                    if (ret6 != "0")
                    {
                        using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                        {
                            SqlCommand command =
                            //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                            new SqlCommand("select Start_Pos,Length,Content from DeckBarcodeValidation with (nolock) where model='" + mdlGlobal.CurrentModel + "' and comment='" + s6.Text + "'", connection);
                            connection.Open();
                            //sqlconnection.Open();

                            SqlDataReader read = command.ExecuteReader();

                            //mdlGlobal.CurrentModel = "";
                            while (read.Read())
                            {
                                mdlGlobal.start1 = int.Parse(read["Start_Pos"].ToString());
                                mdlGlobal.length1 = int.Parse(read["Length"].ToString());
                                mdlGlobal.Content1 = (read["Content"].ToString());


                            }
                            if (mdlGlobal.Content1 == null)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong DeckBacode setup";
                                txtResult.Text = "Worng!! DeckBarcodeValidation Not master setup or not Match scanSetup.ini";
                                //txtBarcodeScan.Text = "";
                                txtscan6.Text = "";
                                txtscan6.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;
                            }

                            if (txtscan6.Text.Substring((mdlGlobal.start1 - 1), mdlGlobal.length1) != mdlGlobal.Content1)
                            {
                                lblResult.Visible = true;
                                lblResult.BackColor = System.Drawing.Color.Red;
                                lblResult.Text = "Wrong Part No.";
                                txtResult.Text = "Worng!! Part Not match Model check master DeckBacodevalidation or material";
                                //txtBarcodeScan.Text = "";
                                txtscan6.Text = "";
                                txtscan6.Focus();
                                //txtBarcodeScan.Focus();
                                read.Close();
                                sqlconnection.Close();
                                return;

                            }
                            else
                            {
                                //function recive txtscan
                                //s2.Text = "";
                                if (txtscan6.Visible != false)
                                {                                   

                                    nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                                    ////insert serial_numbers
                                    SqlConnection conA = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmdA = new SqlCommand("sp_commentadd2_pi3", conA);
                                    cmdA.CommandType = CommandType.StoredProcedure;
                                    cmdA.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                                    cmdA.Parameters.AddWithValue("@comment", nComment);
                                    cmdA.Parameters.AddWithValue("@pass_fail", "1");
                                    cmdA.Parameters.AddWithValue("@node_name", lblNode.Text);


                                    cmdA.Parameters.AddWithValue("@test_type", lblScanType.Text);
                                    cmdA.Parameters.AddWithValue("@operator", lblOper.Text);
                                    conA.Open();
                                    cmdA.ExecuteNonQuery();

                                    conA.Close();

                                    SqlConnection con1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd1 = new SqlCommand("sp_InsertBarcodeLink", con1);
                                    cmd1.CommandType = CommandType.StoredProcedure;
                                    cmd1.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd1.Parameters.AddWithValue("@BC2", txtscan1.Text);
                                    cmd1.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type);
                                    cmd1.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con1.Open();
                                    cmd1.ExecuteNonQuery();

                                    con1.Close();

                                    SqlConnection con2 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd2 = new SqlCommand("sp_InsertBarcodeLink", con2);
                                    cmd2.CommandType = CommandType.StoredProcedure;
                                    cmd2.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd2.Parameters.AddWithValue("@BC2", txtscan2.Text);
                                    cmd2.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type2);
                                    cmd2.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con2.Open();
                                    cmd2.ExecuteNonQuery();

                                    con2.Close();

                                    ////insert DeckBarcoderelations
                                    SqlConnection con3 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd3 = new SqlCommand("sp_InsertBarcodeLink", con3);
                                    cmd3.CommandType = CommandType.StoredProcedure;
                                    cmd3.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd3.Parameters.AddWithValue("@BC2", txtscan3.Text);
                                    cmd3.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type3);
                                    cmd3.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con3.Open();
                                    cmd3.ExecuteNonQuery();

                                    con3.Close();

                                    SqlConnection con4 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd4 = new SqlCommand("sp_InsertBarcodeLink", con4);
                                    cmd4.CommandType = CommandType.StoredProcedure;
                                    cmd4.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd4.Parameters.AddWithValue("@BC2", txtscan4.Text);
                                    cmd4.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type4);
                                    cmd4.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con4.Open();
                                    cmd4.ExecuteNonQuery();


                                    con4.Close();

                                    SqlConnection con5 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd5 = new SqlCommand("sp_InsertBarcodeLink", con5);
                                    cmd5.CommandType = CommandType.StoredProcedure;
                                    cmd5.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd5.Parameters.AddWithValue("@BC2", txtscan5.Text);
                                    cmd5.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type5);
                                    cmd5.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con5.Open();
                                    cmd5.ExecuteNonQuery();

                                    con5.Close();

                                    SqlConnection con6 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                                    SqlCommand cmd6 = new SqlCommand("sp_InsertBarcodeLink", con6);
                                    cmd6.CommandType = CommandType.StoredProcedure;
                                    cmd6.Parameters.AddWithValue("@BC1", txtBarcodeScan.Text);
                                    cmd6.Parameters.AddWithValue("@BC2", txtscan6.Text);
                                    cmd6.Parameters.AddWithValue("@Type", mdlGlobal.pcb_type6);
                                    cmd6.Parameters.AddWithValue("@Node", lblNode.Text);
                                    con6.Open();
                                    cmd6.ExecuteNonQuery();


                                    lblResult.BackColor = System.Drawing.Color.Green;
                                    lblResult.ForeColor = Color.MintCream;
                                    lblResult.Visible = true;
                                    txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                                    passMsg("PASS UNIT SCAN");
                                    txtBarcodeScan.Text = "";
                                    txtBarcodeScan.Focus();

                                    con6.Close();

                                    count_update();
                                }


                                if (txtscan6.Visible != false)
                                {
                                    lblResult.BackColor = System.Drawing.Color.Green;
                                    lblResult.ForeColor = Color.MintCream;
                                    lblResult.Visible = true;
                                    txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                                    passMsg("PASS UNIT SCAN");
                                    txtBarcodeScan.Text = "";
                                    txtscan1.Text = "";
                                    txtscan2.Text = "";
                                    txtscan3.Text = "";
                                    txtscan4.Text = "";
                                    txtscan5.Text = "";
                                    txtscan6.Text = "";
                                    txtBarcodeScan.Focus();
                                }
                                //else
                                //{

                                //    txtscan6.Text = "";
                                //    txtscan6.Focus();
                                //}



                            }
                            read.Close();

                        }

                        sqlconnection.Close();

                    }


                    con.Close();
                }


            }
        }

        private void txtBarcodeScan_KeyPress_1(object sender, KeyPressEventArgs e)
        {
                 if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {

                if (cbModel.Text == "")
                {

                    MessageBox.Show("Please Choose Model before!.");
                    txtBarcodeScan.Text = "";
                    cbModel.Text = "";
                    cbModel.Focus();
                    return;
                }
                else if (txtOper.Text == "" && lblOper.Text == "")
                {

                    MessageBox.Show("Please Input Operator ID before!.");
                    txtBarcodeScan.Text = "";
                    cbModel.Text = "";
                    txtOper.Text = "";
                    txtOper.Focus();
                    return;
                }

                if ((txtBarcodeScan.Text.Length <= 10) || (txtBarcodeScan.Text.Length > 20))
                {
                    lblResult.Visible = true;
                    lblResult.BackColor = System.Drawing.Color.Red;
                    lblResult.Text = "Wrong BARCODE Format";
                    txtResult.Text = "Worng!! Model BARCODE Format";
                    txtBarcodeScan.Text = "";
                    txtBarcodeScan.Focus();
                    return;
                }
            }

            //if (e.KeyCode == Keys.Enter)
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                //mdlGlobal.count_model = lblModel.Text.Length;
                //mdlGlobal.CurrentModel = txtBarcodeScan.Text.Substring(0, Math.Min(mdlGlobal.count_model, txtBarcodeScan.Text.Length));

                //timer2.Enabled = false;
                lblResult.Text = "";
                txtResult.Text = "";
                //PackingCode = "";
                //txt_result_message = "";

                //timer2.Enabled = true;


                using (SqlConnection connection = new SqlConnection("Data Source=10.84.57.104;Initial Catalog=CDataDB;User ID=sa;Password=@sysmanager;"))
                {
                    SqlCommand command =
                    //new SqlCommand("select DeviceID from pcbtrace_PanaCim with (nolock) where PcbID='" + PCBsn + "' order by timedone desc", connection);
                    new SqlCommand("select model from models with (nolock) where description='" + lblModel.Text + "'", connection);
                    connection.Open();
                    //sqlconnection.Open();

                    SqlDataReader read = command.ExecuteReader();

                    mdlGlobal.CurrentModel = "";
                    while (read.Read())
                    {
                        mdlGlobal.CurrentModel = (read["model"].ToString());
                    }
                    read.Close();

                }

                sqlconnection.Close();

                //Check Value NULL
                if (txt_Plan_Qty.Text == "")
                {
                    txt_Plan_Qty.Text = "0";
                }
                //check Plan Qty =< Product Qty then message (if Plan Qty=0 then no message)                
                mdlGlobal.txtPlanQty = System.Convert.ToInt32(txt_Plan_Qty.Text);
                mdlGlobal.ProductOKCount = System.Convert.ToInt32(Product_OK_Count.Text);
                if (mdlGlobal.txtPlanQty == 0)
                {

                }
                else
                {
                    if (mdlGlobal.txtPlanQty <= mdlGlobal.ProductOKCount)
                    {
                        mdlGlobal.ProdEndScreenMsg = "Over Production Qty check Target";
                        txtResult.Text = mdlGlobal.ProdEndScreenMsg;
                        //grpStatus.BackColor = System.Drawing.Color.Red;
                        txtBarcodeScan.Text = "";
                        /*---Show Over Production Qty---*/
                        ProdQtyEndMessage(mdlGlobal.ProdEndScreenMsg);
                        return;
                    }
                }

                //pcbModel = pcbContent;
                mdlGlobal.PCBsn = txtBarcodeScan.Text.Trim();
                mdlGlobal.count_model = mdlGlobal.CurrentModel.Length;
                mdlGlobal.model_check = txtBarcodeScan.Text.Substring(0, Math.Min(mdlGlobal.count_model, txtBarcodeScan.Text.Length));
                if (mdlGlobal.model_check == mdlGlobal.CurrentModel)
                {
                    
                    if (mdlGlobal.Execute_SP.ToUpper() == "TRUE" || mdlGlobal.Execute_SP.ToUpper() == "FALSE")
                    {
                        if (mdlGlobal.Execute_SP.ToUpper() == "TRUE")
                        {
                            SqlConnection con = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");

                            con.Open();

                            //SqlCommand comm = new SqlCommand("usp_unit_verification", con);
                            SqlCommand comm = new SqlCommand(mdlGlobal.Stored_Procedure, con);

                            comm.CommandType = CommandType.StoredProcedure;

                            comm.Parameters.Add(new SqlParameter("@serial_number", txtBarcodeScan.Text.Trim()));
                            comm.Parameters.Add(new SqlParameter("@node_name", mdlGlobal.node));
                            comm.Parameters.Add(new SqlParameter("@test_type", mdlGlobal.test_type));

                            if (mdlGlobal.Stored_Procedure != "usp_dummy")
                            {
                                string ret = comm.ExecuteScalar().ToString();
                                mdlGlobal.return_flag = ret;
                                string chk_flag = mdlGlobal.return_flag.Substring(0, 1);
                                if (chk_flag != "0") //if (mdlGlobal.return_flag.Substring(0,1) != "0")
                                {
                                    lblResult.Visible = true;
                                    lblResult.BackColor = System.Drawing.Color.Red;
                                    lblResult.Text = mdlGlobal.return_flag; //"Worng Process";
                                    txtResult.Text = mdlGlobal.return_flag;
                                    txtBarcodeScan.Text = "";
                                    txtBarcodeScan.Focus();
                                    con.Close();
                                    return;
                                }
                            }
                            else
                                con.Close();
                        }
                       
                        if (txtscan1.Visible == false && txtscan2.Visible == false && txtscan3.Visible == false && txtscan4.Visible == false && txtscan5.Visible == false && txtscan6.Visible == false)
                        {
                            s1.Text = "";
                            s2.Text = "";
                            s3.Text = "";
                            s4.Text = "";
                            s5.Text = "";
                            s6.Text = "";

                            nComment = M1.Text + " " + txtBarcodeScan.Text + " Linkto = " + s1.Text + txtscan1.Text + "," + s2.Text + txtscan2.Text + "," + s3.Text + txtscan3.Text + "," + s4.Text + txtscan4.Text + "," + s5.Text + txtscan5.Text + "," + s6.Text + txtscan6.Text;
                            //insert serial_numbers
                            SqlConnection conA1 = new SqlConnection(@"Data Source=10.84.57.104;database=CDataDB;uid=sa;password=@sysmanager;");
                            SqlCommand cmdA1 = new SqlCommand("sp_commentadd2_pi3", conA1);
                            cmdA1.CommandType = CommandType.StoredProcedure;
                            cmdA1.Parameters.AddWithValue("@sn", txtBarcodeScan.Text);
                            cmdA1.Parameters.AddWithValue("@comment", nComment);
                            cmdA1.Parameters.AddWithValue("@pass_fail", "1");
                            cmdA1.Parameters.AddWithValue("@node_name", lblNode.Text);


                            cmdA1.Parameters.AddWithValue("@test_type", lblScanType.Text);
                            cmdA1.Parameters.AddWithValue("@operator", lblOper.Text);
                            conA1.Open();
                            cmdA1.ExecuteNonQuery();

                            lblResult.BackColor = System.Drawing.Color.Green;
                            lblResult.ForeColor = Color.MintCream;
                            lblResult.Visible = true;
                            txtResult.Text = "PASS " + "- " + txtBarcodeScan.Text;
                            passMsg("PASS UNIT SCAN");
                            txtBarcodeScan.Text = "";
                            txtBarcodeScan.Focus();

                            conA1.Close();
                            count_update();
                            return;
                        }
                        //joe                    

                        if (txtscan1.Visible != false && txtscan2.Visible == false && txtscan3.Visible == false && txtscan4.Visible == false && txtscan5.Visible == false && txtscan6.Visible == false)
                        {
                            lblResult.Visible = false;
                            txtResult.Text = "";
                            txtscan1.Text = "";
                            txtscan1.Focus();

                        }
                        if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible == false && txtscan4.Visible == false && txtscan5.Visible == false && txtscan6.Visible == false)
                        {
                            lblResult.Visible = false;
                            txtResult.Text = "";
                            txtscan1.Text = "";
                            txtscan2.Text = "";
                            txtscan1.Focus();
                        }
                        if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible != false && txtscan4.Visible == false && txtscan5.Visible == false && txtscan6.Visible == false)
                        {
                            //addition XM ID scan
                            try
                            {


                                string serial_num_ = txtBarcodeScan.Text.ToString();
                                int type_ = 127;
                                string action_ = "GET";
                                var G =  StoreConnect.usp_PCBtest_XMTuner_127selectCheck(serial_num_,type_, action_).ToList();
                                if (G.Count() > 0)
                                {
                                    mdlGlobal.DB_SubPCB = G.FirstOrDefault().sub_pcb.ToString();
                                    mdlGlobal.DB_XMTunerFull = G.FirstOrDefault().XM_Tuner_Full.ToString();
                                    mdlGlobal.DB_XMKey = G.FirstOrDefault().XM_KEY.ToString();
                                }
                                else
                                {
                                    lblResult.Visible = true;
                                    lblResult.BackColor = System.Drawing.Color.Red;
                                    txtResult.Text = "Not found ";
                                    txtResult.Text = "Worng!!  Bacode not correct";
                                    txtBarcodeScan.Text = "";
                                    txtBarcodeScan.Focus();
                                    return;
                                }
                            }
                            catch (Exception ex)
                            {

                            }

                            WindowsFormsApp1.FrmScan frmscan = new WindowsFormsApp1.FrmScan();
                            frmscan.ShowDialog();

                            lblResult.Visible = false;
                            txtResult.Text = "";
                            txtscan1.Text = "";
                            txtscan2.Text = "";
                            txtscan3.Text = "";
                            txtscan1.Focus();
                        }
                        if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible != false && txtscan4.Visible != false && txtscan5.Visible == false && txtscan6.Visible == false)
                        {
                            lblResult.Visible = false;
                            txtResult.Text = "";
                            txtscan1.Text = "";
                            txtscan2.Text = "";
                            txtscan3.Text = "";
                            txtscan4.Text = "";
                            txtscan1.Focus();
                        }
                        if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible != false && txtscan4.Visible != false && txtscan5.Visible != false && txtscan6.Visible == false)
                        {
                            lblResult.Visible = false;
                            txtResult.Text = "";
                            txtscan1.Text = "";
                            txtscan2.Text = "";
                            txtscan3.Text = "";
                            txtscan4.Text = "";
                            txtscan5.Text = "";
                            txtscan1.Focus();
                        }
                        if (txtscan1.Visible != false && txtscan2.Visible != false && txtscan3.Visible != false && txtscan4.Visible != false && txtscan5.Visible != false && txtscan6.Visible != false)
                        {
                            lblResult.Visible = false;
                            txtResult.Text = "";
                            txtscan1.Text = "";
                            txtscan2.Text = "";
                            txtscan3.Text = "";
                            txtscan4.Text = "";
                            txtscan5.Text = "";
                            txtscan6.Text = "";
                            txtscan1.Focus();
                        }
                    }

                }

                else
                {
                    lblResult.Visible = true;
                    lblResult.BackColor = System.Drawing.Color.Red;
                    lblResult.Text = "Worng Model";
                    txtResult.Text = "Worng!! model Bacode not correct";
                    txtBarcodeScan.Text = "";
                    txtBarcodeScan.Focus();
                    return;
                }

            }
        }
    }
    
}

