﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp1
{
    static class Program
    {

        //Add by nee
        //Start
        public static void CallMonitorWaitAndCatchException(object dummy)
        {
            try
            {
                Monitor.Wait(dummy);
            }
            catch (SynchronizationLockException)
            {
                Console.WriteLine("A SynchronizationLockException was thrown, as expected.");
                return;
            }

            Console.WriteLine("A SynchronizationLockException was not thrown, which is not expected.");
        }
        //End

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
            var dummy = new object();
            Monitor.Enter(dummy);
            var thread = new Thread(() => CallMonitorWaitAndCatchException(dummy));
            thread.Start();
            thread.Join();
            Console.WriteLine("About to call Monitor.Exit - on Mono this will throw a SynchronizationLockException, on .NET it won't.");
            Monitor.Exit(dummy);
        }
    }
}
