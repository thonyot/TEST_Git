!#/bin/bash
mono "/home/pi/Desktop/App_MM.exe"