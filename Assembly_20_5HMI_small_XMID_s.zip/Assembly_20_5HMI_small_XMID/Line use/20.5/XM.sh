!#/bin/bash
mono "/home/pi/Desktop/WindowsFormsApp3.exe"