!#/bin/bash
mono "/home/pi/Desktop/App_MMSub.exe"