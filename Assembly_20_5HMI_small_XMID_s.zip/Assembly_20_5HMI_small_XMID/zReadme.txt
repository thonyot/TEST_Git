###############Start################### 
13Dec2019
By Nee
Update code For Verify ICT or Function
###############End#################### 