﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formtest_withNINET
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gboxdev = New System.Windows.Forms.GroupBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.lstIntf2 = New System.Windows.Forms.ComboBox
        Me.lstIntf1 = New System.Windows.Forms.ComboBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtaddr1 = New System.Windows.Forms.TextBox
        Me.txtname2 = New System.Windows.Forms.TextBox
        Me.txtaddr2 = New System.Windows.Forms.TextBox
        Me.txtname1 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.btncreate = New System.Windows.Forms.Button
        Me.gbox1 = New System.Windows.Forms.GroupBox
        Me.txtr1astat = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.btnq1a = New System.Windows.Forms.Button
        Me.btnq1b = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtr1a = New System.Windows.Forms.TextBox
        Me.txtq1a = New System.Windows.Forms.TextBox
        Me.txtr1b = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtq1b = New System.Windows.Forms.TextBox
        Me.gbox2 = New System.Windows.Forms.GroupBox
        Me.txtr2astat = New System.Windows.Forms.TextBox
        Me.btnq2a = New System.Windows.Forms.Button
        Me.btnq2b = New System.Windows.Forms.Button
        Me.txtq2b = New System.Windows.Forms.TextBox
        Me.txtr2b = New System.Windows.Forms.TextBox
        Me.txtq2a = New System.Windows.Forms.TextBox
        Me.txtr2a = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.btndevlist = New System.Windows.Forms.Button
        Me.gboxdev.SuspendLayout()
        Me.gbox1.SuspendLayout()
        Me.gbox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'gboxdev
        '
        Me.gboxdev.Controls.Add(Me.Label18)
        Me.gboxdev.Controls.Add(Me.Label17)
        Me.gboxdev.Controls.Add(Me.lstIntf2)
        Me.gboxdev.Controls.Add(Me.lstIntf1)
        Me.gboxdev.Controls.Add(Me.Label16)
        Me.gboxdev.Controls.Add(Me.Label15)
        Me.gboxdev.Controls.Add(Me.Label4)
        Me.gboxdev.Controls.Add(Me.Label3)
        Me.gboxdev.Controls.Add(Me.txtaddr1)
        Me.gboxdev.Controls.Add(Me.txtname2)
        Me.gboxdev.Controls.Add(Me.txtaddr2)
        Me.gboxdev.Controls.Add(Me.txtname1)
        Me.gboxdev.Controls.Add(Me.Label2)
        Me.gboxdev.Controls.Add(Me.Label1)
        Me.gboxdev.Location = New System.Drawing.Point(1, 1)
        Me.gboxdev.Name = "gboxdev"
        Me.gboxdev.Size = New System.Drawing.Size(534, 130)
        Me.gboxdev.TabIndex = 0
        Me.gboxdev.TabStop = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(308, 92)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(48, 13)
        Me.Label18.TabIndex = 23
        Me.Label18.Text = "interface"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(6, 92)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(48, 13)
        Me.Label17.TabIndex = 22
        Me.Label17.Text = "interface"
        '
        'lstIntf2
        '
        Me.lstIntf2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.lstIntf2.FormattingEnabled = True
        Me.lstIntf2.Location = New System.Drawing.Point(364, 92)
        Me.lstIntf2.Name = "lstIntf2"
        Me.lstIntf2.Size = New System.Drawing.Size(144, 21)
        Me.lstIntf2.TabIndex = 21
        '
        'lstIntf1
        '
        Me.lstIntf1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.lstIntf1.FormattingEnabled = True
        Me.lstIntf1.Location = New System.Drawing.Point(60, 92)
        Me.lstIntf1.Name = "lstIntf1"
        Me.lstIntf1.Size = New System.Drawing.Size(158, 21)
        Me.lstIntf1.TabIndex = 20
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(445, 8)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(48, 13)
        Me.Label16.TabIndex = 19
        Me.Label16.Text = "device 2"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(76, 8)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(51, 13)
        Me.Label15.TabIndex = 11
        Me.Label15.Text = "device 1 "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(300, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "address"
        '
        'txtaddr1
        '
        Me.txtaddr1.Location = New System.Drawing.Point(60, 61)
        Me.txtaddr1.Name = "txtaddr1"
        Me.txtaddr1.Size = New System.Drawing.Size(152, 20)
        Me.txtaddr1.TabIndex = 7
        Me.txtaddr1.Text = "GPIB0::2::INSTR"
        '
        'txtname2
        '
        Me.txtname2.Location = New System.Drawing.Point(364, 29)
        Me.txtname2.Name = "txtname2"
        Me.txtname2.Size = New System.Drawing.Size(144, 20)
        Me.txtname2.TabIndex = 6
        Me.txtname2.Text = "fluke"
        '
        'txtaddr2
        '
        Me.txtaddr2.Location = New System.Drawing.Point(364, 57)
        Me.txtaddr2.Name = "txtaddr2"
        Me.txtaddr2.Size = New System.Drawing.Size(144, 20)
        Me.txtaddr2.TabIndex = 5
        Me.txtaddr2.Text = "20"
        '
        'txtname1
        '
        Me.txtname1.Location = New System.Drawing.Point(60, 26)
        Me.txtname1.Name = "txtname1"
        Me.txtname1.Size = New System.Drawing.Size(152, 20)
        Me.txtname1.TabIndex = 2
        Me.txtname1.Text = "Agilent 34410A"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(308, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "name :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = " name:"
        '
        'btncreate
        '
        Me.btncreate.Location = New System.Drawing.Point(546, 33)
        Me.btncreate.Name = "btncreate"
        Me.btncreate.Size = New System.Drawing.Size(115, 63)
        Me.btncreate.TabIndex = 10
        Me.btncreate.Text = "create devices"
        Me.btncreate.UseVisualStyleBackColor = True
        '
        'gbox1
        '
        Me.gbox1.Controls.Add(Me.txtr1astat)
        Me.gbox1.Controls.Add(Me.Label9)
        Me.gbox1.Controls.Add(Me.Label8)
        Me.gbox1.Controls.Add(Me.btnq1a)
        Me.gbox1.Controls.Add(Me.btnq1b)
        Me.gbox1.Controls.Add(Me.Label7)
        Me.gbox1.Controls.Add(Me.txtr1a)
        Me.gbox1.Controls.Add(Me.txtq1a)
        Me.gbox1.Controls.Add(Me.txtr1b)
        Me.gbox1.Controls.Add(Me.Label6)
        Me.gbox1.Controls.Add(Me.Label5)
        Me.gbox1.Controls.Add(Me.txtq1b)
        Me.gbox1.Enabled = False
        Me.gbox1.Location = New System.Drawing.Point(1, 164)
        Me.gbox1.Name = "gbox1"
        Me.gbox1.Size = New System.Drawing.Size(301, 337)
        Me.gbox1.TabIndex = 1
        Me.gbox1.TabStop = False
        '
        'txtr1astat
        '
        Me.txtr1astat.Location = New System.Drawing.Point(18, 230)
        Me.txtr1astat.Multiline = True
        Me.txtr1astat.Name = "txtr1astat"
        Me.txtr1astat.Size = New System.Drawing.Size(266, 85)
        Me.txtr1astat.TabIndex = 11
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(9, 77)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(50, 13)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "response"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(11, 165)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "command"
        '
        'btnq1a
        '
        Me.btnq1a.Location = New System.Drawing.Point(221, 164)
        Me.btnq1a.Name = "btnq1a"
        Me.btnq1a.Size = New System.Drawing.Size(64, 43)
        Me.btnq1a.TabIndex = 8
        Me.btnq1a.Text = "query async"
        Me.btnq1a.UseVisualStyleBackColor = True
        '
        'btnq1b
        '
        Me.btnq1b.Location = New System.Drawing.Point(221, 48)
        Me.btnq1b.Name = "btnq1b"
        Me.btnq1b.Size = New System.Drawing.Size(64, 46)
        Me.btnq1b.TabIndex = 7
        Me.btnq1b.Text = "query blocking"
        Me.btnq1b.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(9, 194)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(50, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "response"
        '
        'txtr1a
        '
        Me.txtr1a.Location = New System.Drawing.Point(79, 188)
        Me.txtr1a.Name = "txtr1a"
        Me.txtr1a.Size = New System.Drawing.Size(129, 20)
        Me.txtr1a.TabIndex = 5
        '
        'txtq1a
        '
        Me.txtq1a.Location = New System.Drawing.Point(79, 162)
        Me.txtq1a.Name = "txtq1a"
        Me.txtq1a.Size = New System.Drawing.Size(129, 20)
        Me.txtq1a.TabIndex = 4
        Me.txtq1a.Text = "READ?"
        '
        'txtr1b
        '
        Me.txtr1b.Location = New System.Drawing.Point(79, 74)
        Me.txtr1b.Name = "txtr1b"
        Me.txtr1b.Size = New System.Drawing.Size(129, 20)
        Me.txtr1b.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(108, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "device 1 "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "command"
        '
        'txtq1b
        '
        Me.txtq1b.Location = New System.Drawing.Point(79, 48)
        Me.txtq1b.Name = "txtq1b"
        Me.txtq1b.Size = New System.Drawing.Size(129, 20)
        Me.txtq1b.TabIndex = 0
        Me.txtq1b.Text = "READ?"
        '
        'gbox2
        '
        Me.gbox2.Controls.Add(Me.txtr2astat)
        Me.gbox2.Controls.Add(Me.btnq2a)
        Me.gbox2.Controls.Add(Me.btnq2b)
        Me.gbox2.Controls.Add(Me.txtq2b)
        Me.gbox2.Controls.Add(Me.txtr2b)
        Me.gbox2.Controls.Add(Me.txtq2a)
        Me.gbox2.Controls.Add(Me.txtr2a)
        Me.gbox2.Controls.Add(Me.Label14)
        Me.gbox2.Controls.Add(Me.Label13)
        Me.gbox2.Controls.Add(Me.Label12)
        Me.gbox2.Controls.Add(Me.Label11)
        Me.gbox2.Controls.Add(Me.Label10)
        Me.gbox2.Enabled = False
        Me.gbox2.Location = New System.Drawing.Point(317, 163)
        Me.gbox2.Name = "gbox2"
        Me.gbox2.Size = New System.Drawing.Size(344, 338)
        Me.gbox2.TabIndex = 2
        Me.gbox2.TabStop = False
        '
        'txtr2astat
        '
        Me.txtr2astat.Location = New System.Drawing.Point(19, 231)
        Me.txtr2astat.Multiline = True
        Me.txtr2astat.Name = "txtr2astat"
        Me.txtr2astat.Size = New System.Drawing.Size(266, 85)
        Me.txtr2astat.TabIndex = 19
        '
        'btnq2a
        '
        Me.btnq2a.Location = New System.Drawing.Point(253, 158)
        Me.btnq2a.Name = "btnq2a"
        Me.btnq2a.Size = New System.Drawing.Size(64, 43)
        Me.btnq2a.TabIndex = 18
        Me.btnq2a.Text = "query async"
        Me.btnq2a.UseVisualStyleBackColor = True
        '
        'btnq2b
        '
        Me.btnq2b.Location = New System.Drawing.Point(253, 51)
        Me.btnq2b.Name = "btnq2b"
        Me.btnq2b.Size = New System.Drawing.Size(64, 46)
        Me.btnq2b.TabIndex = 17
        Me.btnq2b.Text = "query blocking"
        Me.btnq2b.UseVisualStyleBackColor = True
        '
        'txtq2b
        '
        Me.txtq2b.Location = New System.Drawing.Point(89, 51)
        Me.txtq2b.Name = "txtq2b"
        Me.txtq2b.Size = New System.Drawing.Size(129, 20)
        Me.txtq2b.TabIndex = 16
        Me.txtq2b.Text = "READ?"
        '
        'txtr2b
        '
        Me.txtr2b.Location = New System.Drawing.Point(89, 81)
        Me.txtr2b.Name = "txtr2b"
        Me.txtr2b.Size = New System.Drawing.Size(129, 20)
        Me.txtr2b.TabIndex = 15
        '
        'txtq2a
        '
        Me.txtq2a.Location = New System.Drawing.Point(89, 158)
        Me.txtq2a.Name = "txtq2a"
        Me.txtq2a.Size = New System.Drawing.Size(129, 20)
        Me.txtq2a.TabIndex = 14
        Me.txtq2a.Text = "READ?"
        '
        'txtr2a
        '
        Me.txtr2a.Location = New System.Drawing.Point(89, 184)
        Me.txtr2a.Name = "txtr2a"
        Me.txtr2a.Size = New System.Drawing.Size(129, 20)
        Me.txtr2a.TabIndex = 13
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(16, 188)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(50, 13)
        Me.Label14.TabIndex = 12
        Me.Label14.Text = "response"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(16, 81)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(50, 13)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "response"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(13, 162)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 13)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "command"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(16, 51)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(53, 13)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "command"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(144, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(48, 13)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "device 2"
        '
        'btndevlist
        '
        Me.btndevlist.Enabled = False
        Me.btndevlist.Location = New System.Drawing.Point(199, 137)
        Me.btndevlist.Name = "btndevlist"
        Me.btndevlist.Size = New System.Drawing.Size(184, 24)
        Me.btndevlist.TabIndex = 3
        Me.btndevlist.Text = "show  device list"
        Me.btndevlist.UseVisualStyleBackColor = True
        '
        'Formtest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(673, 513)
        Me.Controls.Add(Me.btncreate)
        Me.Controls.Add(Me.btndevlist)
        Me.Controls.Add(Me.gbox2)
        Me.Controls.Add(Me.gbox1)
        Me.Controls.Add(Me.gboxdev)
        Me.Name = "Formtest"
        Me.Text = "Form1"
        Me.gboxdev.ResumeLayout(False)
        Me.gboxdev.PerformLayout()
        Me.gbox1.ResumeLayout(False)
        Me.gbox1.PerformLayout()
        Me.gbox2.ResumeLayout(False)
        Me.gbox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents gboxdev As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtaddr1 As System.Windows.Forms.TextBox
    Friend WithEvents txtname2 As System.Windows.Forms.TextBox
    Friend WithEvents txtaddr2 As System.Windows.Forms.TextBox
    Friend WithEvents txtname1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents gbox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btncreate As System.Windows.Forms.Button
    Friend WithEvents txtr1a As System.Windows.Forms.TextBox
    Friend WithEvents txtq1a As System.Windows.Forms.TextBox
    Friend WithEvents txtr1b As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtq1b As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnq1a As System.Windows.Forms.Button
    Friend WithEvents btnq1b As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents gbox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnq2a As System.Windows.Forms.Button
    Friend WithEvents btnq2b As System.Windows.Forms.Button
    Friend WithEvents txtq2b As System.Windows.Forms.TextBox
    Friend WithEvents txtr2b As System.Windows.Forms.TextBox
    Friend WithEvents txtq2a As System.Windows.Forms.TextBox
    Friend WithEvents txtr2a As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents btndevlist As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lstIntf1 As System.Windows.Forms.ComboBox
    Friend WithEvents lstIntf2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtr1astat As System.Windows.Forms.TextBox
    Friend WithEvents txtr2astat As System.Windows.Forms.TextBox

End Class
